# Fix Report: Auto Pipeline Execution Bug

## 1. Root cause analysis

`ProjectPage._on_create()` (`app/ui/pages/project.py`) did three things back to back
when the user clicked "Tạo & Chạy Pipeline":

```python
self.app.create_project_and_pipeline(topic, lang)
self.app.navigate("script")
self.app.start_pipeline_stage("script")   # <-- the bug
```

`MainApp.start_pipeline_stage()` (`app/ui/app.py`) looked like it respected the
`stage` argument, but it didn't: it always built a job that called
`VideoPipeline.run(topic=..., language=..., resume=True, ...)` with no stopping
point. `VideoPipeline.run()` (`app/pipelines/orchestrator.py`) unconditionally
executes all seven stages in sequence — script → scene split → prompt gen →
image gen → voice → subtitle → render — skipping only stages that already have
a checkpoint on disk.

Net effect: the instant a project was created, a background thread started
generating a script, images, voice, subtitles, and a rendered video, using
whatever partial values happened to be in memory. The user had no chance to:

- enter/confirm the topic, language, duration, style, or aspect ratio,
- review or edit the generated script,
- decide when (or whether) to spend GPU/CPU time on images or rendering.

There was also no validation layer and no state machine, so even if the auto-call
had been removed, nothing would have stopped a stray direct call to
`pipeline.run(...)` from starting extraction with missing inputs, or stopped
"Generate Video" from running before any images existed.

## 2. Files modified

| File | Why |
|---|---|
| `app/core/exceptions.py` | Added `ValidationError` (input/state problems, carries user-facing messages) and `InvalidStateTransitionError` (action requested in the wrong pipeline state). |
| `app/models/pipeline_state.py` *(new)* | `PipelineState` enum + `PipelineStateMachine` with an explicit transition allow-list. This is the single source of truth for "what can the user click right now" — replaces implicit/no state tracking. |
| `app/core/validation.py` *(new)* | Pure functions that check required inputs/state before Script/Images/Video generation may start, raising `ValidationError` with Vietnamese, user-friendly messages. |
| `app/pipelines/orchestrator.py` | Added `until_stage` parameter to `VideoPipeline.run()`. This is what makes "Generate Script", "Generate Images", and "Generate Video" three genuinely independent operations instead of one all-or-nothing `run()` — each stops right after the stage it's responsible for, while still resuming already-checkpointed stages so nothing is regenerated for free. |
| `app/controllers/pipeline_controller.py` *(new)* | The Controller layer between UI and pipeline. Enforces: validate → check state → publish `*Requested` event → transition to a `*_GENERATING` busy state → submit to the existing `TaskQueue` (worker thread) → on completion/failure, publish a result event and transition state, all reported back through the `EventBus`/`app.after(0, ...)` — never touching widgets from the worker thread. |
| `app/ui/app.py` | `create_project_and_pipeline()` replaced with `create_project()`, which **only** creates folders/metadata and initializes `PipelineState.WAITING_FOR_INPUT` — no pipeline call. `start_pipeline_stage()` (the auto-run entry point) removed entirely. Added `state_machine`, `controller`, a `run_validated()` helper that turns `ValidationError`/`InvalidStateTransitionError` into a dialog instead of a crash, and logging for every pipeline lifecycle event. |
| `app/ui/pages/project.py` | Button relabeled "Tạo Project"; click handler now only calls `create_project()` + `navigate("script")`. No pipeline call, no topic requirement at creation time. |
| `app/ui/pages/script.py` | Added the fields the mission asked for (duration, style, aspect ratio) alongside topic/language. Three explicit actions — Generate Script, Approve & Continue, Generate Images — each routed through `app.controller` and gated by `state_machine.can(...)`. |
| `app/ui/pages/video.py` | Replaced "Run Full Pipeline" / "Render Video Only" (which could be clicked at any time) with a single "Generate Video" button, enabled only when images exist (`IMAGE_READY`/`VIDEO_READY`). Cancel now goes through the controller. |
| `app/ui/base_page.py` | Added an `on_state_changed(state)` hook so pages can refresh their own button states when `MainApp` broadcasts a `PipelineState` change, instead of polling. |

No other files needed changes: DI container, EventBus, TaskQueue, CheckpointManager, and all seven pipeline `Stage` classes were already correctly layered and are reused as-is.

## 3. Required workflow — how it now maps to code

```
Launch App                          MainApp.__init__
New Project → Create Empty Project  ProjectPage._on_create() -> app.create_project()  (folders + metadata only)
Open Script Editor                  app.navigate("script")            [state = WAITING_FOR_INPUT]
User enters topic/lang/duration/... ScriptPage form fields
User clicks "Generate Script"       ScriptPage._generate_script() -> controller.request_generate_script()
  -> validate_script_request()      (rejects empty topic / duration<=0 / no language)
  -> state_machine.require(...)     (rejects if not WAITING_FOR_INPUT/SCRIPT_READY/SCRIPT_APPROVED)
  -> GenerateScriptRequested event, state -> SCRIPT_GENERATING
  -> TaskQueue worker runs pipeline.run(..., until_stage=StageName.SCRIPT)
  -> on completion: ScriptGenerated event, state -> SCRIPT_READY
User reviews/edits script           ScriptPage text widget + Save
User clicks "Approve & Continue"    controller.approve_script() -> state -> SCRIPT_APPROVED
User clicks "Generate Images"       controller.request_generate_images()
  -> validate_images_request()      (requires non-empty script)
  -> pipeline.run(..., until_stage=StageName.IMAGE_GEN)   [scene split + prompts + images; script NOT re-run]
  -> ImagesGenerated event, state -> IMAGE_READY
User clicks "Generate Video"        VideoPage._generate_video() -> controller.request_generate_video()
  -> validate_video_request()       (requires images_ready)
  -> pipeline.run(..., until_stage=None)   [voice + subtitles + render; earlier stages resumed, not redone]
  -> VideoGenerated event, state -> VIDEO_READY
```

At no point does project creation, navigation, or any UI event other than the
three "Generate ..." button clicks reach `pipeline.run(...)`.

## 4. Verification performed

Ran outside the Tk event loop (no display required):

- **State machine**: confirmed `generate_images`/`generate_video` are rejected
  (`InvalidStateTransitionError`) before their prerequisites exist, and that the
  full `EMPTY → ... → VIDEO_READY` path transitions cleanly.
- **Validation**: confirmed empty topic, zero duration, missing script, and
  missing images are all rejected with the expected messages; valid requests
  pass.
- **Orchestrator `until_stage`**: with fake stage doubles, confirmed that
  (a) `until_stage=SCRIPT` runs only the script stage, (b) `until_stage=IMAGE_GEN`
  resumes the script stage from checkpoint (0 extra calls) and runs through
  images, (c) `until_stage=None` resumes every earlier stage from checkpoint and
  only executes voice/subtitle/render. No stage was ever re-run once
  checkpointed, and no stage ran before its explicit trigger.
- `python -m py_compile` across the full `app/` tree.

## 5. Backward compatibility

`examples/run_pipeline.py`, which calls `pipeline.run(topic=..., language=...,
resume=True, ...)` without `until_stage`, is unaffected — it defaults to `None`
and still runs the full pipeline end-to-end for headless/CI use.
