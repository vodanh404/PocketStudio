# Báo cáo: Pipeline Hardening (StageResult + Validation + Edge-TTS + Stop-on-Fail)

## 1. Danh sách file đã sửa / thêm

### Thêm mới
| File | Vai trò |
|------|---------|
| `app/models/stage_result.py` | `StageResult` (success/error/output/metadata/elapsed) |
| `app/pipelines/stage_executor.py` | Wrap `BaseStage.run` → `StageResult` + log Start/End/Stack |
| `app/utils/retry.py` | Exponential backoff retry (1s, 2s, 4s) |
| `app/utils/file_checker.py` | `require_exists` / `require_non_empty` / `ensure_dir` |
| `app/utils/validators.py` | Image/Audio/Subtitle/Video validators + input validators + DependencyChecker |
| `tests/test_pipeline_stages.py` | Regression: Image/Voice/LLM fail, empty data, retry, stop-on-fail |

### Sửa nội bộ (giữ API public)
| File | Thay đổi chính |
|------|----------------|
| `app/pipelines/orchestrator.py` | Mỗi stage qua StageExecutor; `success==False` → raise PipelineError, dừng ngay |
| `app/pipelines/stages/base.py` | `_check_cancelled()` helper |
| `app/pipelines/stages/script_stage.py` | Validate topic/script; retry LLM |
| `app/pipelines/stages/scene_split_stage.py` | Validate script; raise nếu 0 scene |
| `app/pipelines/stages/prompt_gen_stage.py` | Validate scenes; reject empty prompt |
| `app/pipelines/stages/image_gen_stage.py` | Validate prompts; retry generate; PIL verify; thiếu ảnh → fail |
| `app/pipelines/stages/voice_stage.py` | **Fix Edge-TTS triệt để** (xem §3) |
| `app/pipelines/stages/subtitle_stage.py` | Validate audio input; SRT parse; placeholder cue |
| `app/pipelines/stages/render_stage.py` | Pre-flight mọi file input; require ffmpeg/ffprobe; VideoValidator output |
| `app/ui/app.py` | Subscribe `pipeline.stage_failed` → dialog Stage + error + stack rút gọn |
| `app/models/__init__.py` | Export StageResult |

**Không đổi:** Controller API, EventBus, Service Layer public signatures, UI workflow buttons/state machine.

---

## 2. Vì sao lỗi xảy ra

### Edge-TTS "No audio was received"
1. Text rỗng / whitespace đi thẳng vào `edge_tts.Communicate` → Edge từ chối.
2. Sau `save()` không kiểm tra file tồn tại / size / ffprobe → 0-byte file được coi là thành công.
3. Không timeout → hang mạng.
4. Không retry khi lỗi transient (DNS/proxy).
5. Rate/volume không chuẩn hóa (`"+0%"` bắt buộc).

### Pipeline chạy tiếp sau stage fail
- `stage.run()` raise exception nhưng orchestrator chỉ bọc ở TaskQueue level.
- Image stage có thể trả list thiếu ảnh mà vẫn "success".
- Render không kiểm tra tồn tại file image/audio/srt trước FFmpeg.

### Exception bị nuốt
- `except Exception: return max(2.0, ...)` trong voice duration.
- Một số `except: pass` trong image_generator (giữ vì optional feature).

---

## 3. Root Cause

| # | Root Cause | Hậu quả |
|---|------------|---------|
| RC1 | Không có contract `StageResult` thống nhất | Orchestrator không biết stage fail vs partial success |
| RC2 | Không validate input trước khi gọi AI/TTS/FFmpeg | Edge-TTS crash, FFmpeg crash mid-render |
| RC3 | Không validate output sau mỗi stage | Checkpoint lưu file corrupt → resume độc hại |
| RC4 | Edge-TTS không có timeout/retry/post-check | "No audio was received" không được surface rõ |
| RC5 | Render không pre-flight file | FFmpeg lỗi khó đọc, video nửa vời |

---

## 4. Giải pháp

1. **StageResult + StageExecutor**: mọi stage được bọc; fail → log full stack → publish `pipeline.stage_failed` → raise `PipelineError` → orchestrator dừng.
2. **Validators**: input (topic, script, scenes, prompts, TTS text, voice) + output (PIL, ffprobe, SRT parse).
3. **VoiceStage rewrite**: normalize rate/volume, validate text, network probe, asyncio timeout, retry 3 lần, AudioValidator sau save, xóa file partial khi fail.
4. **ImageGenStage**: backend None check, retry, ImageValidator (PIL verify+load), count match prompts.
5. **RenderStage**: DependencyChecker.ffmpeg, require_exists mọi image/audio/srt, VideoValidator output.
6. **UI**: dialog hiển thị tên stage + nguyên nhân + stack rút gọn.

---

## 5–6. Code trước / sau (tóm tắt)

### Voice (trước)
```python
async def _run():
    communicate = edge_tts.Communicate(text=text, voice=voice, rate=self.rate, volume=self.volume)
    await communicate.save(str(output_path))
asyncio.run(_run())
return self._get_audio_duration(output_path)  # except: return fake duration
```

### Voice (sau)
```python
text = validate_tts_text(...)
rate, volume = _normalise_rate/volume(...)
asyncio.run(asyncio.wait_for(_run(), timeout=60))
duration = AudioValidator.validate(output_path)  # raise nếu rỗng/corrupt
# + retry_call 3 lần exponential
```

### Orchestrator (trước)
```python
result = stage.run(...)
self.checkpoint.save(...)
results[...] = result
# tiếp tục stage sau dù có exception bị nuốt ở stage
```

### Orchestrator (sau)
```python
sr = self._run_stage(...)  # StageExecutor → StageResult
if not sr.success:
    raise PipelineError(...)  # dừng, không chạy stage tiếp
self.checkpoint.save(..., sr.output.to_dict())
```

---

## 7. Kiểm thử đã chạy

```
python3 -m unittest tests.test_pipeline_stages -v   # 19/19 OK
python3 -m unittest tests.test_model_pool_race -v   # 4/4 OK
python3 -m py_compile <all changed modules>         # OK
```

Coverage:
- StageResult ok/fail
- StageExecutor success + failure (không raise ra ngoài executor)
- Empty script/topic/tts/scenes/prompt → ValidationFailed
- Image backend None → PipelineError
- Image path missing after generate → PipelineError
- Voice empty scenes/text → fail
- Retry success after 2 fails + exhaust
- Pipeline stop chain khi stage 2 fail (không chạy stage 3)
- ModelPool race (regression cũ vẫn pass)

---

## 8. Lỗi tiềm ẩn còn lại

| Mức | Mô tả |
|-----|-------|
| Medium | `image_generator.py` vẫn có vài `except: pass` quanh optional xformers/TF32 – an toàn nhưng nên log debug rõ hơn |
| Medium | Edge-TTS cần internet; offline hoàn toàn sẽ fail sau 3 retry (đúng behavior, có thể thêm offline TTS sau) |
| Low | Render KenBurns filter có thể chậm trên CPU-only với nhiều scene dài |
| Low | Whisper silent audio → placeholder cue "..." (tránh fail cứng; UX có thể cải thiện) |
| Low | `asyncio.run` trong worker thread OK khi không có loop; nếu tương lai nhúng vào async app cần `nest_asyncio` hoặc loop riêng |

---

## 9. Đề xuất tối ưu hiệu năng

1. Batch voice synthesize (nhiều Communicate song song với semaphore 2–3) – hiện sequential.
2. Giữ SD model acquire một lần cho cả ImageGenStage (đã an toàn nhờ ModelPool BUSY).
3. Cache TTS theo hash(text+voice+rate) giống image cache.
4. Render: dùng filter_complex concat thay vì nhiều temp clip khi scene > 30.
5. Prefetch ffprobe path 1 lần ở DependencyChecker startup.

---

## 10. Đánh giá độ ổn định pipeline

| Tiêu chí | Trạng thái |
|----------|------------|
| Không tạo video nếu chưa có ảnh | ✓ (Render pre-flight + ImageGen count check) |
| Không tạo video nếu chưa có âm thanh | ✓ |
| Không tạo video nếu subtitle lỗi | ✓ |
| Không tạo video nếu Image Stage fail | ✓ (StageResult stop) |
| Không tạo video nếu Voice Stage fail | ✓ |
| Mọi lỗi ghi log đầy đủ | ✓ ([Stage]/[Image]/[TTS]/[Subtitle]/[Video]/[Pipeline]) |
| UI hiện đúng nguyên nhân | ✓ (pipeline.stage_failed dialog) |
| Không nuốt ngoại lệ stage | ✓ (StageExecutor log + fail) |
| Pipeline khôi phục sau lỗi | ✓ (checkpoint resume; corrupt existing re-gen) |
| Output xác thực trước stage tiếp | ✓ (validators sau mỗi stage) |

**Kết luận:** Pipeline đạt các tiêu chí cứng. Kiến trúc Controller / EventBus / Service / UI workflow được bảo toàn; chỉ refactor nội bộ stages + orchestrator + utility layer.
