# Fix Report: "Expected all tensors to be on the same device, cpu and cuda:0"

## 1. Root cause

This was **not** a device-placement bug in the classic sense (nobody
forgot a `.to(device)`). It was a **thread-safety bug**: `ModelPool`
tracked `ref_count` but never *enforced* it.

Sequence that produced the crash:

1. `TaskWorker-0` calls `SDXLTurboBackend.generate()` → `model_pool.acquire("sdxl-turbo")`
   → `pipe(...)` starts running on the GPU (mid-forward-pass, activations live on `cuda:0`).
2. Independently, the `MemoryMonitor` background thread (in `app/utils/memory.py`)
   samples RAM/VRAM every 5s. If usage crosses `ram_critical`/`vram` thresholds it calls
   `MemoryManager.force_cleanup()`, which runs every registered unload callback.
3. `ModelPool.__init__` had registered **`force_unload_all`** as that callback.
   `force_unload_all` unloaded every model unconditionally — it only *logged a warning*
   when `ref_count > 0`, it never actually waited or skipped.
4. `force_unload_all` → `_unload()` calls `handle.instance.to("cpu")` on the **same pipe
   object** `TaskWorker-0` is in the middle of using, while its forward pass is still
   executing on the GPU.
5. The next `Linear()` inside `UNet.time_embedding` reads weights that were just moved to
   CPU while its input activation tensor is still on `cuda:0` → `RuntimeError: Expected
   all tensors to be on the same device, but found at least two devices, cpu and cuda:0`.

This matches the reported log sequence exactly: `Critical memory → Force cleanup →
Unloaded model → All models unloaded → Pipeline vẫn tiếp tục chạy → Crash`.

Two threads racing on one shared, mutable pipeline object with no lock held across the
compute call — that's the actual defect. Adding `pipe.to(device)` or
`torch.cuda.empty_cache()` calls would not have fixed it; the race is architectural.

## 2. Architectural errors found (checklist from the request)

| # | Check | Finding |
|---|---|---|
| 1 | `pipe.to(cuda)` called after `enable_model_cpu_offload()`? | **Not violated** — `image_generator.py` already used an `if/else` (offload *or* `.to(device)`, never both). Hardened anyway with a named `use_offload` flag, a comment, and a runtime hook-presence check (`device_check.py`) so a future regression fails loudly instead of silently. |
| 2 | `pipe.unet.to(cpu)` / `vae.to(cpu)` / `text_encoder.to(cpu)` anywhere? | Not called on submodules directly, but `ModelPool._unload()` called `.to("cpu")` on the **whole pipe** — dangerous specifically when the pipe was loaded with `enable_model_cpu_offload()`, because that pipe's submodules are already managed by accelerate forward-hooks; manually calling `.to()` on it fights those hooks. **Fixed**: unload no longer calls `.to()` at all on offload-managed instances — it just drops the reference (see `_release_pipeline`). |
| 3 | Does MemoryManager unload while the pipeline is running? | **Yes — this was the root cause.** Fixed by routing MemoryManager's cleanup through `ModelPool.request_cleanup()`, which is busy-aware (see §3). |
| 4 | Race condition in TaskQueue (worker generating vs. another thread cleaning up)? | **Yes.** `MemoryMonitor` (own thread) and `TaskWorker-0` (own thread) both touched the same `ModelHandle.instance` with no synchronization spanning the actual `pipe(...)` call. Fixed with a full lock/condition-variable protocol in `ModelPool` (see §3). |
| 5 | Does `ModelPool` keep a stale reference after unload? | It removed the dict entry (`del self._models[name]`), so no stale reference existed there — but nothing stopped a second unload from racing a concurrent load. Now `ModelHandle` objects persist (state `UNLOADED`) and `instance` is explicitly set to `None` on unload, all under the same lock used by `acquire()`. |
| 6 | Is the pipeline fully recreated after unload, or is the object reused? | Fully recreated: `acquire()` on an `UNLOADED` handle always calls the registered loader again (`AutoPipelineForText2Image.from_pretrained(...)`), producing a brand-new object. Verified in `tests/test_model_pool_race.py::test_unload_recreates_a_fresh_instance_next_acquire`. |
| 7 | Any place mixing `cpu`/`cuda` devices across the project? | No other `.to(...)` call sites touch the SDXL/LLM/Whisper models besides the ones already covered above. Added `app/utils/device_check.py` as a standing guard, called right before every `pipe(...)`. |

## 3. New architecture

### `ModelHandle` state machine (`app/services/model_pool.py`)

```
UNLOADED --acquire()--> LOADING --loader() ok--> BUSY <--acquire()/release()--> READY
   ^                       |
   |                    loader() raises
   |                       v
   +<------------------ ERROR
READY --idle timeout / memory pressure, ref_count==0 ONLY--> UNLOADING --> UNLOADED
```

Enforced by a single `threading.RLock` + `threading.Condition`:

- `acquire(name)` blocks (does not busy-wait) while another thread is `LOADING` or
  `UNLOADING` the same model, then marks it `BUSY` and returns the instance.
  The actual (slow) `loader()` call happens **outside** the lock so it doesn't stall
  other models or the janitor — only the state transition is protected.
- `release(name)` decrements `ref_count`; the handle only becomes `READY` (eligible for
  unload) once `ref_count == 0`.
- **Every** unload path — `force_unload`, `force_unload_all`, `request_cleanup`, and the
  idle janitor — funnels through one gatekeeper, `_try_begin_unload()`, which refuses to
  proceed unless `state == READY and ref_count == 0`. There is no second code path that
  can unload a `BUSY` model. This is the actual fix.

### MemoryManager integration

`MemoryManager.force_cleanup()` (`app/utils/memory.py`) is **unchanged** — it still just
invokes whatever's registered via `register_unload_callback`. The only change is *what*
`ModelPool` registers: `request_cleanup` instead of `force_unload_all`.

```
RAM cao → MemoryManager.force_cleanup() → ModelPool.request_cleanup()
              → model đang BUSY? → log "Cleanup delayed", wait up to `wait_timeout` (default 5s)
                  → still busy after timeout → log "Cleanup skipped", leave it alone
                     (janitor / next monitor tick @5s will retry)
                  → became READY in time → unload it
              → model already READY, ref_count==0 → unload immediately
```

This is a bounded wait, not an indefinite block: the `MemoryMonitor` thread will resume
its 5s polling loop even if a model stayed busy the whole time.

### "Unload All" UI button

`app/ui/pages/model_manager.py` calls `model_pool.force_unload_all()` directly on the
Tkinter UI thread — signature unchanged (per the "no API changes" constraint), but the
semantics are now safe: busy models are skipped (logged), not corrupted, and the call
returns quickly either way — no UI freeze.

### Device validation (`app/utils/device_check.py`, new file)

Called immediately before every `pipe(...)` in `image_generator.py`:

- If the pipe uses `enable_model_cpu_offload()`: confirms accelerate's hooks
  (`_hf_hook`/`_diffusers_hook`) are actually attached to `unet`. Checking "all
  components on the same device" would be a **false positive** here — offloaded
  pipelines intentionally keep most weights on CPU between calls by design.
- Otherwise: asserts `unet`/`vae`/`text_encoder`/`text_encoder_2`/`controlnet` (whichever
  exist) all report the exact same `torch.device`, raising a clear `RuntimeError` naming
  the mismatched components if not.

This is defense-in-depth for a *coding* mistake, not the primary fix — the primary fix is
that unload can no longer race a live `pipe(...)` call at all.

### Logging added

`Model registered`, `Loading model: X ...`, `Model loaded: X (Ns)`, `Model acquired: X
(busy_count=N)`, `Model released: X (busy_count=N)`, `Cleanup delayed for X — busy,
waiting up to Ns`, `Cleanup skipped for X (state=…, busy_count=…)`, `Model unloaded: X`,
`Idle timeout → unload X`, and (in `orchestrator.py`) `Pipeline finished (stages
completed this run: […])` at every return point of `VideoPipeline.run()`. Current
device/dtype are logged once at pipeline load time in `image_generator.py`.

## 4. Files changed

| File | Change |
|---|---|
| `app/services/model_pool.py` | Rewritten: `ModelState` enum, lock+condition-based `acquire`/`release`, `request_cleanup` (busy-aware), `_try_begin_unload` gatekeeper used by every unload path, safe `_release_pipeline` that skips `.to()` for offload-managed instances. **Public API unchanged**: `register`, `acquire`, `release`, `force_unload`, `force_unload_all`, `start_janitor`, `stop`, `status` all still exist with the same call signatures. |
| `app/services/image_generator.py` | Tags loaded pipe with `_pocketstudio_cpu_offload`; logs device/dtype at load time; calls `validate_pipeline_devices()` right before every `pipe(...)`. |
| `app/utils/device_check.py` | **New.** Device/hook consistency guard described above. |
| `app/pipelines/orchestrator.py` | Added `_finish()` helper; every `return results` in `VideoPipeline.run()` now routes through it to log `Pipeline finished`. No signature or control-flow change otherwise. |
| `app/utils/memory.py` | **Unchanged.** (`register_unload_callback`/`force_cleanup` already had the right shape — only what `ModelPool` registers needed to change, which lives in `model_pool.py`.) |
| `tests/test_model_pool_race.py` | **New.** Reproduces the original race with a fake pipe + two hammering threads (worker vs. simulated MemoryManager pressure) and asserts the pipe is never mutated while `in_use`; also covers "Unload All" skipping a busy model, full-recreation after unload, and the janitor's busy-guard. |

No UI, Controller, or Pipeline-facing APIs changed. `PipelineController`, `VideoPipeline.run()`'s
signature, `TaskQueue`, and all seven `Stage` classes are untouched except for the
`_finish()` logging wrapper in the orchestrator.

## 5. Verification

```
$ python3 -m py_compile <every .py file in app/>          # OK, no syntax errors
$ python3 -m unittest tests.test_model_pool_race -v        # 4/4 pass, run 3x to rule out flakiness
```

`test_unload_never_happens_while_busy` runs a worker thread doing 20 acquire→"generate"
(10ms sleep)→release cycles concurrently with two threads hammering
`request_cleanup(wait_timeout=0.05)` as fast as possible — the adversarial version of what
`MemoryMonitor` does under real memory pressure. The fake pipe records `corrupted = True`
if `.to()` is ever called while `in_use`. Across three runs, zero corruptions, confirming
the specific failure mode ("cpu and cuda:0" from a mid-flight unload) is now structurally
impossible, not just less likely.

## 6. Scope note (what was intentionally left alone)

The request's suggested lifecycle diagram implies stage-level acquire/release ("mỗi stage
phải acquire model... release sau khi stage hoàn thành"). `ImageGenStage` currently
acquires/releases per-image (once per scene) rather than once for the whole stage. This
was left as-is: with the `BUSY` state now enforced, per-image granularity is exactly as
safe as stage-level granularity — the model is never touched by anything else while any
single `pipe(...)` call is in flight, whether that call is 1 of 1 or 1 of 20. Changing the
granularity would only reduce state-transition churn, not fix a correctness gap, and
touching all 7 `Stage` classes was out of scope for "ưu tiên sửa bên trong Service, không
đổi API".
