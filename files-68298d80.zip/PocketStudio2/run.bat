@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Project: %CD%
if not exist "app\models\llm.py" (
  echo [ERROR] app\models\llm.py missing. Project incomplete.
  echo Re-extract PocketStudio2 zip into this folder.
  pause
  exit /b 1
)
python -c "import sys; sys.path.insert(0,'.'); from app.models.llm import LLMConfig; print('Import OK')" || (
  echo [ERROR] Import failed. Check Python version and files.
  pause
  exit /b 1
)
python -m app.main
