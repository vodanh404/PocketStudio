#!/usr/bin/env python3
"""Verify PocketStudio2 package layout. Run: python scripts/check_install.py"""
from __future__ import annotations
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
required = [
    "app/__init__.py",
    "app/main.py",
    "app/models/__init__.py",
    "app/models/llm.py",
    "app/models/pipeline.py",
    "app/models/pipeline_state.py",
    "app/services/__init__.py",
    "app/services/llm_service.py",
    "app/services/image_generator.py",
    "app/services/model_pool.py",
    "app/core/app_context.py",
]

print(f"Project root: {ROOT}")
missing = []
for rel in required:
    path = ROOT / rel
    ok = path.is_file()
    print(f"  {'OK' if ok else 'MISSING':7} {rel}")
    if not ok:
        missing.append(rel)

if missing:
    print("\nFAILED – missing files. Re-extract the project zip.")
    sys.exit(1)

sys.path.insert(0, str(ROOT))
try:
    from app.models.llm import LLMConfig
    from app.services.model_pool import ModelPool
    print("\nImport check: OK")
except Exception as e:
    print(f"\nImport check FAILED: {e}")
    sys.exit(1)

print("Layout looks good. Start with: python -m app.main")
