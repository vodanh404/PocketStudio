"""Regression tests for pipeline stage failure gating, validators, retry."""
from __future__ import annotations

import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.exceptions import PipelineError
from app.models.pipeline import (
    Scene, SceneSplitResult, ScenePrompt, PromptGenResult,
    SceneImage, ImageGenResult, SceneVoice, VoiceResult,
    SceneSubtitle, SubtitleResult, ScriptResult, StageName,
)
from app.models.stage_result import StageResult
from app.pipelines.stage_executor import StageExecutor
from app.pipelines.stages.base import BaseStage
from app.pipelines.stages.scene_split_stage import SceneSplitStage
from app.pipelines.stages.prompt_gen_stage import PromptGenStage
from app.pipelines.stages.image_gen_stage import ImageGenStage
from app.pipelines.stages.voice_stage import VoiceStage
from app.utils.retry import retry_call
from app.utils.validators import (
    ValidationFailed, validate_script_text, validate_topic,
    validate_tts_text, validate_scenes, validate_prompts,
    ImageValidator, SubtitleValidator,
)


class FakeFailStage(BaseStage):
    name = "fake_fail"

    def run(self, input_data, progress=None, **kwargs):
        raise RuntimeError("intentional failure")


class FakeOkStage(BaseStage):
    name = "fake_ok"

    def run(self, input_data, progress=None, **kwargs):
        return {"ok": True, "input": input_data}


class StageResultTest(unittest.TestCase):
    def test_ok_factory(self):
        r = StageResult.ok({"a": 1}, stage_name="s", elapsed_time=0.5)
        self.assertTrue(r.success)
        self.assertEqual(r.output["a"], 1)

    def test_fail_factory(self):
        r = StageResult.fail("boom", stage_name="s")
        self.assertFalse(r.success)
        self.assertIn("boom", r.error_message)


class StageExecutorTest(unittest.TestCase):
    def test_success(self):
        ex = StageExecutor(FakeOkStage())
        r = ex.execute("hello")
        self.assertTrue(r.success)
        self.assertEqual(r.output["input"], "hello")

    def test_failure_does_not_raise(self):
        ex = StageExecutor(FakeFailStage())
        r = ex.execute(None)
        self.assertFalse(r.success)
        self.assertIn("intentional", r.error_message)
        self.assertIn("traceback", r.metadata)


class ValidatorTest(unittest.TestCase):
    def test_empty_script(self):
        with self.assertRaises(ValidationFailed):
            validate_script_text("")
        with self.assertRaises(ValidationFailed):
            validate_script_text(None)

    def test_empty_topic(self):
        with self.assertRaises(ValidationFailed):
            validate_topic("  ")

    def test_empty_tts_text(self):
        with self.assertRaises(ValidationFailed):
            validate_tts_text("")

    def test_empty_scenes(self):
        with self.assertRaises(ValidationFailed):
            validate_scenes([])

    def test_empty_prompt(self):
        with self.assertRaises(ValidationFailed):
            validate_prompts([ScenePrompt(scene_index=0, prompt="")])


class SceneSplitFailTest(unittest.TestCase):
    def test_empty_script_raises(self):
        stage = SceneSplitStage()
        with self.assertRaises((PipelineError, ValidationFailed)):
            stage.run(ScriptResult(topic="t", full_script=""))


class PromptGenFailTest(unittest.TestCase):
    def test_empty_scenes_raises(self):
        stage = PromptGenStage(llm_service=None)
        with self.assertRaises((PipelineError, ValidationFailed)):
            stage.run(SceneSplitResult(scenes=[]))


class ImageGenFailTest(unittest.TestCase):
    def test_backend_none_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            stage = ImageGenStage(image_backend=None, output_dir=Path(tmp))
            prompts = PromptGenResult(prompts=[
                ScenePrompt(scene_index=0, prompt="a cat"),
            ])
            with self.assertRaises(PipelineError):
                stage.run(prompts)

    def test_missing_image_after_generate_raises(self):
        backend = MagicMock()
        backend.generate.return_value = Path("/nonexistent/nope.png")
        with tempfile.TemporaryDirectory() as tmp:
            stage = ImageGenStage(image_backend=backend, output_dir=Path(tmp), max_retries=1)
            prompts = PromptGenResult(prompts=[
                ScenePrompt(scene_index=0, prompt="a cat"),
            ])
            with self.assertRaises(PipelineError):
                stage.run(prompts)


class VoiceFailTest(unittest.TestCase):
    def test_empty_scenes_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            stage = VoiceStage(output_dir=Path(tmp), max_retries=1)
            with self.assertRaises((PipelineError, ValidationFailed)):
                stage.run(SceneSplitResult(scenes=[]))

    def test_empty_scene_text_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            stage = VoiceStage(output_dir=Path(tmp), max_retries=1)
            scenes = SceneSplitResult(scenes=[Scene(index=0, text="   ")])
            with self.assertRaises((PipelineError, ValidationFailed)):
                stage.run(scenes)


class RetryTest(unittest.TestCase):
    def test_retry_eventually_succeeds(self):
        calls = {"n": 0}

        def flaky():
            calls["n"] += 1
            if calls["n"] < 3:
                raise RuntimeError("transient")
            return "ok"

        result = retry_call(flaky, attempts=3, base_delay=0.01, label="flaky")
        self.assertEqual(result, "ok")
        self.assertEqual(calls["n"], 3)

    def test_retry_exhausts(self):
        def always_fail():
            raise RuntimeError("permanent")

        with self.assertRaises(RuntimeError):
            retry_call(always_fail, attempts=2, base_delay=0.01, label="always")


class ImageValidatorTest(unittest.TestCase):
    def test_missing_file(self):
        with self.assertRaises(Exception):
            ImageValidator.validate(Path("/tmp/does_not_exist_xyz.png"))


class PipelineStopOnFailureTest(unittest.TestCase):
    """Orchestrator must not continue past a failed stage."""

    def test_executor_failure_stops_chain(self):
        results = []
        stages = [FakeOkStage(), FakeFailStage(), FakeOkStage()]
        for s in stages:
            r = StageExecutor(s).execute("x")
            results.append(r)
            if not r.success:
                break
        self.assertEqual(len(results), 2)
        self.assertTrue(results[0].success)
        self.assertFalse(results[1].success)


if __name__ == "__main__":
    unittest.main()
