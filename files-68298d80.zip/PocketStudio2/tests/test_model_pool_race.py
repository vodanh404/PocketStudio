"""Reproduces the original race (worker thread mid-generate vs a
MemoryManager-style cleanup thread hammering unload) and proves the new
ModelPool state machine makes the "unloaded while busy" outcome
impossible -- this is the exact precondition for the reported
'cpu and cuda:0' crash.
"""
import sys
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.services.model_pool import ModelPool, ModelState  # noqa: E402


class FakePipe:
    """Stands in for a diffusers pipeline. Records whether it was ever
    unloaded (`.to('cpu')` + del) while `in_use` was True."""

    def __init__(self):
        self.in_use = False
        self.corrupted = False

    def to(self, device):
        if self.in_use:
            self.corrupted = True
        return self


class ModelPoolRaceTest(unittest.TestCase):
    def _make_pool(self, idle_timeout=999):
        pool = ModelPool(idle_timeout=idle_timeout)
        self.fake_pipe = FakePipe()
        pool.register("sdxl-turbo", lambda: self.fake_pipe)
        return pool

    def test_unload_never_happens_while_busy(self):
        pool = self._make_pool()
        errors = []

        def worker():
            for _ in range(20):
                pipe = pool.acquire("sdxl-turbo")
                pipe.in_use = True
                try:
                    # simulate an in-flight forward pass
                    time.sleep(0.01)
                    if pipe.corrupted:
                        errors.append("pipe was mutated mid-use")
                finally:
                    pipe.in_use = False
                    pool.release("sdxl-turbo")

        def memory_pressure():
            for _ in range(40):
                pool.request_cleanup(wait_timeout=0.05)
                time.sleep(0.005)

        threads = [
            threading.Thread(target=worker),
            threading.Thread(target=memory_pressure),
            threading.Thread(target=memory_pressure),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        self.assertEqual(errors, [], "Model was unloaded/mutated while a worker had it BUSY")
        self.assertFalse(self.fake_pipe.corrupted)

    def test_force_unload_all_skips_busy_model(self):
        pool = self._make_pool()
        pipe = pool.acquire("sdxl-turbo")
        pipe.in_use = True
        pool.force_unload_all()  # simulates the "Unload All" UI button
        status = pool.status()
        self.assertEqual(status["sdxl-turbo"]["state"], ModelState.BUSY.value)
        self.assertFalse(pipe.corrupted)
        pipe.in_use = False
        pool.release("sdxl-turbo")

    def test_unload_recreates_a_fresh_instance_next_acquire(self):
        pool = self._make_pool()
        first = pool.acquire("sdxl-turbo")
        pool.release("sdxl-turbo")
        pool.force_unload("sdxl-turbo")
        self.assertIsNone(pool._models["sdxl-turbo"].instance)

        # loader creates a brand new object, not a reused reference
        new_obj = FakePipe()
        pool._loaders["sdxl-turbo"] = lambda: new_obj
        second = pool.acquire("sdxl-turbo")
        self.assertIsNot(first, second)
        self.assertIs(second, new_obj)
        pool.release("sdxl-turbo")

    def test_idle_janitor_only_unloads_when_ref_count_zero(self):
        pool = self._make_pool(idle_timeout=0)
        pipe = pool.acquire("sdxl-turbo")
        handle = pool._models["sdxl-turbo"]
        handle.last_used = time.time() - 999  # force "idle" even though busy

        # Directly exercise the same guard the janitor thread uses.
        with pool._lock:
            began = pool._try_begin_unload(handle)
        self.assertFalse(began, "must not begin unload while ref_count > 0")
        pool.release("sdxl-turbo")


if __name__ == "__main__":
    unittest.main()
