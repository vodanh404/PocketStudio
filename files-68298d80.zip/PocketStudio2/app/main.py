"""Entry point for MoneyPrinter Desktop.

Recommended:
    cd D:\\PocketStudio2
    python -m app.main
"""
from __future__ import annotations

import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_APP_DIR = Path(__file__).resolve().parent

# Force project root to the front of sys.path.
_root = str(_ROOT)
if sys.path and Path(sys.path[0]).resolve() == _APP_DIR.resolve():
    sys.path[0] = _root
elif _root not in sys.path:
    sys.path.insert(0, _root)
else:
    # Move existing root entry to front.
    try:
        sys.path.remove(_root)
    except ValueError:
        pass
    sys.path.insert(0, _root)


def _diagnose_and_exit(exc: BaseException) -> None:
    """Print actionable diagnostics when package imports fail."""
    print("=" * 60, file=sys.stderr)
    print("PocketStudio2 bootstrap FAILED", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print(f"Error : {type(exc).__name__}: {exc}", file=sys.stderr)
    print(f"Root  : {_ROOT}", file=sys.stderr)
    print(f"App   : {_APP_DIR}", file=sys.stderr)
    print(f"CWD   : {Path.cwd()}", file=sys.stderr)
    print(f"Python: {sys.version}", file=sys.stderr)
    print("sys.path (first 5):", file=sys.stderr)
    for p in sys.path[:5]:
        print(f"  - {p}", file=sys.stderr)

    models_dir = _APP_DIR / "models"
    print(f"\nExpected package: {models_dir}", file=sys.stderr)
    if not models_dir.is_dir():
        print("  [MISSING] app/models/ directory does not exist!", file=sys.stderr)
        print("  Fix: restore app/models/ with __init__.py, llm.py, pipeline.py, pipeline_state.py", file=sys.stderr)
    else:
        print("  Contents:", file=sys.stderr)
        for f in sorted(models_dir.iterdir()):
            print(f"    - {f.name}", file=sys.stderr)
        required = ["__init__.py", "llm.py", "pipeline.py", "pipeline_state.py"]
        missing = [r for r in required if not (models_dir / r).is_file()]
        if missing:
            print(f"  [MISSING FILES] {missing}", file=sys.stderr)

    print("\nRun from project root:", file=sys.stderr)
    print(f"  cd /d {_ROOT}", file=sys.stderr)
    print("  python -m app.main", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    raise SystemExit(1) from exc


def main() -> None:
    try:
        from app.core.logging_setup import setup_logging
        from app.core.app_context import AppContext
        from app.pipelines.factory import PipelineFactory
        from app.ui.app import MainApp
    except ModuleNotFoundError as e:
        _diagnose_and_exit(e)

    setup_logging()
    ctx = AppContext.create()
    pipeline_factory = PipelineFactory(ctx)
    app = MainApp()
    app.set_context(ctx, pipeline_factory)
    try:
        app.run()
    finally:
        ctx.shutdown()


if __name__ == "__main__":
    main()
