"""Pipeline state machine.

This is the source of truth for "what is the user allowed to do right now".
UI pages must consult this (via MainApp.state_machine) before enabling any
Generate button, instead of assuming an action is always available.

State flow (see MISSION doc):

    EMPTY -> PROJECT_CREATED -> WAITING_FOR_INPUT
          -> SCRIPT_GENERATING -> SCRIPT_READY -> SCRIPT_APPROVED
          -> IMAGE_GENERATING -> IMAGE_READY
          -> VIDEO_GENERATING -> VIDEO_READY -> EXPORT_READY

*_GENERATING states are transient "busy" states entered right before a
background task is submitted, so the UI can disable buttons and show a
spinner while work is running, then move forward (success) or backward
(failure) once the worker thread reports back through the EventBus.
"""
from __future__ import annotations

import logging
from enum import Enum
from typing import Callable, Dict, List, Optional, Set

from app.core.events import event_bus
from app.core.exceptions import InvalidStateTransitionError

logger = logging.getLogger(__name__)


class PipelineState(str, Enum):
    EMPTY = "empty"
    PROJECT_CREATED = "project_created"
    WAITING_FOR_INPUT = "waiting_for_input"
    SCRIPT_GENERATING = "script_generating"
    SCRIPT_READY = "script_ready"
    SCRIPT_APPROVED = "script_approved"
    IMAGE_GENERATING = "image_generating"
    IMAGE_READY = "image_ready"
    VIDEO_GENERATING = "video_generating"
    VIDEO_READY = "video_ready"
    EXPORT_READY = "export_ready"


# Explicit allow-list of transitions. Anything not listed here is rejected,
# which is what stops the pipeline from ever "jumping ahead" on its own.
_TRANSITIONS: Dict[PipelineState, Set[PipelineState]] = {
    PipelineState.EMPTY: {PipelineState.PROJECT_CREATED},
    PipelineState.PROJECT_CREATED: {PipelineState.WAITING_FOR_INPUT},
    PipelineState.WAITING_FOR_INPUT: {PipelineState.SCRIPT_GENERATING},
    PipelineState.SCRIPT_GENERATING: {
        PipelineState.SCRIPT_READY,
        PipelineState.WAITING_FOR_INPUT,  # generation failed / cancelled
    },
    PipelineState.SCRIPT_READY: {
        PipelineState.SCRIPT_GENERATING,  # regenerate
        PipelineState.SCRIPT_APPROVED,    # user approves / edits & continues
    },
    PipelineState.SCRIPT_APPROVED: {
        PipelineState.SCRIPT_GENERATING,  # regenerate after approval
        PipelineState.IMAGE_GENERATING,
    },
    PipelineState.IMAGE_GENERATING: {
        PipelineState.IMAGE_READY,
        PipelineState.SCRIPT_APPROVED,    # generation failed / cancelled
    },
    PipelineState.IMAGE_READY: {
        PipelineState.IMAGE_GENERATING,   # regenerate
        PipelineState.VIDEO_GENERATING,
    },
    PipelineState.VIDEO_GENERATING: {
        PipelineState.VIDEO_READY,
        PipelineState.IMAGE_READY,        # generation failed / cancelled
    },
    PipelineState.VIDEO_READY: {
        PipelineState.VIDEO_GENERATING,   # regenerate
        PipelineState.EXPORT_READY,
    },
    PipelineState.EXPORT_READY: {
        PipelineState.VIDEO_GENERATING,
    },
}

# Which state must currently be active for a given user action to be allowed.
_ACTION_REQUIRES: Dict[str, Set[PipelineState]] = {
    "generate_script": {
        PipelineState.WAITING_FOR_INPUT,
        PipelineState.SCRIPT_READY,
        PipelineState.SCRIPT_APPROVED,
    },
    "approve_script": {PipelineState.SCRIPT_READY},
    "generate_images": {PipelineState.SCRIPT_APPROVED, PipelineState.IMAGE_READY},
    "generate_video": {PipelineState.IMAGE_READY, PipelineState.VIDEO_READY},
}


class PipelineStateMachine:
    """Per-project state machine. One instance lives on MainApp and is
    reset every time a new project is created."""

    def __init__(self, initial: PipelineState = PipelineState.EMPTY) -> None:
        self._state = initial
        self._listeners: List[Callable[[PipelineState], None]] = []

    @property
    def state(self) -> PipelineState:
        return self._state

    def on_change(self, listener: Callable[[PipelineState], None]) -> None:
        self._listeners.append(listener)

    def can(self, action: str) -> bool:
        allowed = _ACTION_REQUIRES.get(action)
        if allowed is None:
            logger.warning("Unknown pipeline action queried: %s", action)
            return False
        return self._state in allowed

    def require(self, action: str) -> None:
        """Raise InvalidStateTransitionError if `action` is not allowed
        in the current state. Controllers call this before doing any work,
        as a last line of defense even if the UI incorrectly enabled a
        button."""
        if not self.can(action):
            raise InvalidStateTransitionError(
                f"Action '{action}' is not allowed in state '{self._state.value}'"
            )

    def transition(self, new_state: PipelineState, *, force: bool = False) -> None:
        if not force and new_state not in _TRANSITIONS.get(self._state, set()):
            raise InvalidStateTransitionError(
                f"Cannot transition from '{self._state.value}' to '{new_state.value}'"
            )
        old = self._state
        self._state = new_state
        logger.info("Pipeline state: %s -> %s", old.value, new_state.value)
        event_bus.publish("pipeline.state_changed", {"old": old.value, "new": new_state.value})
        for listener in list(self._listeners):
            try:
                listener(new_state)
            except Exception:
                logger.exception("State-change listener failed")

    def reset(self) -> None:
        self.transition(PipelineState.EMPTY, force=True)
