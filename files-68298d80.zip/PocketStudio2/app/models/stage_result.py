"""Canonical result type for every pipeline stage.

Pipeline only advances to the next stage when ``success is True``.
On failure the orchestrator logs, publishes a failure event, and stops.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class StageResult:
    """Uniform envelope returned by StageExecutor / inspected by the orchestrator."""

    success: bool
    output: Any = None
    error: Optional[BaseException] = None
    error_message: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    elapsed_time: float = 0.0
    stage_name: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "stage_name": self.stage_name,
            "error_message": self.error_message,
            "elapsed_time": self.elapsed_time,
            "metadata": self.metadata,
            "has_output": self.output is not None,
        }

    @classmethod
    def ok(
        cls,
        output: Any,
        *,
        stage_name: str = "",
        elapsed_time: float = 0.0,
        metadata: Optional[dict[str, Any]] = None,
    ) -> "StageResult":
        return cls(
            success=True,
            output=output,
            stage_name=stage_name,
            elapsed_time=elapsed_time,
            metadata=metadata or {},
        )

    @classmethod
    def fail(
        cls,
        error: BaseException | str,
        *,
        stage_name: str = "",
        elapsed_time: float = 0.0,
        metadata: Optional[dict[str, Any]] = None,
        output: Any = None,
    ) -> "StageResult":
        if isinstance(error, BaseException):
            err = error
            msg = str(error) or type(error).__name__
        else:
            err = RuntimeError(error)
            msg = str(error)
        return cls(
            success=False,
            output=output,
            error=err,
            error_message=msg,
            stage_name=stage_name,
            elapsed_time=elapsed_time,
            metadata=metadata or {},
        )
