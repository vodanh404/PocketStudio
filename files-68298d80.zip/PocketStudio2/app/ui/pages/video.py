from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage


class VideoPage(BasePage):
    title = "Video"

    def _build(self) -> None:
        ttk.Label(self, text="Video Preview & Render", style="Title.TLabel").pack(pady=(20, 5), padx=30, anchor=W)
        info = ttk.Labelframe(self, text="Trạng thái Pipeline", padding=15)
        info.pack(fill=X, padx=30, pady=10)
        self.lbl_status = ttk.Label(info, text="Chưa chạy pipeline", font=("Segoe UI", 11))
        self.lbl_status.pack(anchor=W)
        self.lbl_detail = ttk.Label(info, text="", style="Subtitle.TLabel")
        self.lbl_detail.pack(anchor=W, pady=5)
        self.progress = ttk.Progressbar(info, mode="determinate", bootstyle="success-striped")
        self.progress.pack(fill=X, pady=10)
        actions = ttk.Frame(self)
        actions.pack(fill=X, padx=30, pady=15)
        self.btn_generate_video = ttk.Button(actions, text="🎬 Generate Video", bootstyle="success", width=20,
                                              command=self._generate_video)
        self.btn_generate_video.pack(side=LEFT, padx=(0, 8))
        self.btn_cancel = ttk.Button(actions, text="⏹ Cancel", bootstyle="danger-outline", width=12,
                                      command=self._cancel)
        self.btn_cancel.pack(side=LEFT, padx=8)
        preview = ttk.Labelframe(self, text="Preview (sau khi render)", padding=10)
        preview.pack(fill=BOTH, expand=True, padx=30, pady=10)
        self.lbl_preview = ttk.Label(
            preview, text="Video sẽ hiển thị tại đây sau khi render xong.\n(Mở file bằng player mặc định)",
            style="Subtitle.TLabel", justify=CENTER,
        )
        self.lbl_preview.pack(expand=True)
        ttk.Button(preview, text="📂 Mở thư mục Output", bootstyle="info-outline",
                   command=self._open_output).pack(pady=10)

        self._refresh_buttons()

    def on_show(self) -> None:
        self._refresh_buttons()

    def on_state_changed(self, state) -> None:
        self._refresh_buttons()

    def _refresh_buttons(self) -> None:
        sm = self.app.state_machine
        self.btn_generate_video.configure(state=(NORMAL if sm.can("generate_video") else DISABLED))

    def _generate_video(self) -> None:
        def _do():
            self.app.controller.request_generate_video()
        self.app.run_validated("Generate Video", _do)

    def _cancel(self) -> None:
        self.app.controller.cancel()

    def update_progress(self, stage: str, percent: float, message: str) -> None:
        self.lbl_status.configure(text=f"Stage: {stage}")
        self.lbl_detail.configure(text=message)
        self.progress["value"] = percent * 100

    def _open_output(self) -> None:
        project = getattr(self.app, "current_project", None)
        if project:
            import os
            try:
                os.startfile(str(project.dir))
            except Exception:
                pass
