from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage


class ScriptPage(BasePage):
    title = "Script"

    def _build(self) -> None:
        ttk.Label(self, text="Script Editor", style="Title.TLabel").pack(pady=(20, 5), padx=30, anchor=W)
        ttk.Label(self, text="Nhập thông tin video, sau đó bấm Generate Script. Không có gì chạy tự động.",
                  style="Subtitle.TLabel").pack(padx=30, anchor=W)

        form = ttk.Labelframe(self, text="Thông tin video", padding=15)
        form.pack(fill=X, padx=30, pady=10)

        ttk.Label(form, text="Chủ đề / Prompt:").grid(row=0, column=0, sticky=W, pady=5)
        self.entry_topic = ttk.Entry(form, width=50)
        self.entry_topic.grid(row=0, column=1, sticky=EW, padx=10, pady=5)

        ttk.Label(form, text="Ngôn ngữ:").grid(row=1, column=0, sticky=W, pady=5)
        self.combo_lang = ttk.Combobox(form, values=["vi", "en"], width=10, state="readonly")
        self.combo_lang.set("vi")
        self.combo_lang.grid(row=1, column=1, sticky=W, padx=10, pady=5)

        ttk.Label(form, text="Thời lượng (giây):").grid(row=2, column=0, sticky=W, pady=5)
        self.entry_duration = ttk.Entry(form, width=10)
        self.entry_duration.insert(0, "60")
        self.entry_duration.grid(row=2, column=1, sticky=W, padx=10, pady=5)

        ttk.Label(form, text="Phong cách (style):").grid(row=3, column=0, sticky=W, pady=5)
        self.combo_style = ttk.Combobox(
            form, values=["cinematic", "anime", "realistic", "cartoon", "minimal"], width=20,
        )
        self.combo_style.set("cinematic")
        self.combo_style.grid(row=3, column=1, sticky=W, padx=10, pady=5)

        ttk.Label(form, text="Tỉ lệ khung hình:").grid(row=4, column=0, sticky=W, pady=5)
        self.combo_aspect = ttk.Combobox(form, values=["9:16", "16:9", "1:1"], width=10, state="readonly")
        self.combo_aspect.set("9:16")
        self.combo_aspect.grid(row=4, column=1, sticky=W, padx=10, pady=5)
        form.columnconfigure(1, weight=1)

        toolbar = ttk.Frame(self)
        toolbar.pack(fill=X, padx=30, pady=10)
        self.btn_generate = ttk.Button(toolbar, text="↻ Generate Script", bootstyle="success",
                                        command=self._generate_script)
        self.btn_generate.pack(side=LEFT)
        self.btn_save = ttk.Button(toolbar, text="💾 Save", bootstyle="info-outline",
                                    command=self._save_script)
        self.btn_save.pack(side=LEFT, padx=8)
        self.btn_approve = ttk.Button(toolbar, text="✔ Approve & Continue", bootstyle="primary",
                                       command=self._approve_script)
        self.btn_approve.pack(side=LEFT, padx=8)
        self.btn_generate_images = ttk.Button(toolbar, text="➡ Generate Images", bootstyle="warning",
                                               command=self._generate_images)
        self.btn_generate_images.pack(side=RIGHT)

        self.text = ttk.Text(self, height=20, wrap=WORD, font=("Segoe UI", 11))
        self.text.pack(fill=BOTH, expand=True, padx=30, pady=(0, 20))
        scroll = ttk.Scrollbar(self.text, command=self.text.yview)
        scroll.pack(side=RIGHT, fill=Y)
        self.text.configure(yscrollcommand=scroll.set)

        self._refresh_buttons()

    def on_show(self) -> None:
        project = getattr(self.app, "current_project", None)
        if project:
            self.entry_topic.delete(0, END)
            self.entry_topic.insert(0, getattr(project, "topic", "") or "")
            if getattr(project, "script", None):
                self.text.delete("1.0", END)
                self.text.insert("1.0", project.script or "")
        self._refresh_buttons()

    def on_state_changed(self, state) -> None:
        self._refresh_buttons()

    def _refresh_buttons(self) -> None:
        sm = self.app.state_machine
        self.btn_generate.configure(state=(NORMAL if sm.can("generate_script") else DISABLED))
        self.btn_approve.configure(state=(NORMAL if sm.can("approve_script") else DISABLED))
        self.btn_generate_images.configure(state=(NORMAL if sm.can("generate_images") else DISABLED))

    # ------------------------------------------------------------------
    def _generate_script(self) -> None:
        topic = self.entry_topic.get().strip()
        language = self.combo_lang.get()
        style = self.combo_style.get().strip()
        aspect_ratio = self.combo_aspect.get().strip()
        try:
            duration = float(self.entry_duration.get().strip())
        except (TypeError, ValueError):
            duration = 0

        def _do():
            self.app.controller.request_generate_script(
                topic=topic, language=language, duration=duration,
                style=style, aspect_ratio=aspect_ratio,
            )
        self.app.run_validated("Generate Script", _do)

    def _save_script(self) -> None:
        content = self.text.get("1.0", END).strip()
        if getattr(self.app, "current_project", None):
            self.app.current_project.script = content
            self.app.status_bar.set_status("Đã lưu script")

    def _approve_script(self) -> None:
        content = self.text.get("1.0", END).strip()

        def _do():
            self.app.controller.approve_script(content)
            self.app.status_bar.set_status("Đã duyệt script. Có thể Generate Images.")
        self.app.run_validated("Approve Script", _do)

    def _generate_images(self) -> None:
        def _do():
            self.app.controller.request_generate_images()
            self.app.navigate("assets")
        self.app.run_validated("Generate Images", _do)
