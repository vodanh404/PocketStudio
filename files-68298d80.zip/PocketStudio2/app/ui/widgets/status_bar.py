from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *


class StatusBar(ttk.Frame):
    def __init__(self, master, **kwargs) -> None:
        super().__init__(master, bootstyle="dark", **kwargs)
        self._build()

    def _build(self) -> None:
        self.lbl_status = ttk.Label(self, text="Sẵn sàng", bootstyle="inverse-dark")
        self.lbl_status.pack(side=LEFT, padx=10, pady=4)
        self.lbl_cpu = ttk.Label(self, text="CPU: --", bootstyle="inverse-dark")
        self.lbl_cpu.pack(side=RIGHT, padx=6)
        self.lbl_gpu = ttk.Label(self, text="GPU: --", bootstyle="inverse-dark")
        self.lbl_gpu.pack(side=RIGHT, padx=6)
        self.lbl_ram = ttk.Label(self, text="RAM: --", bootstyle="inverse-dark")
        self.lbl_ram.pack(side=RIGHT, padx=6)
        self.lbl_vram = ttk.Label(self, text="VRAM: --", bootstyle="inverse-dark")
        self.lbl_vram.pack(side=RIGHT, padx=6)
        self.progress = ttk.Progressbar(self, mode="determinate", length=160, bootstyle="success-striped")
        self.progress.pack(side=RIGHT, padx=10, pady=4)

    def set_status(self, text: str) -> None:
        self.lbl_status.configure(text=text)

    def set_progress(self, value: float) -> None:
        self.progress["value"] = max(0, min(100, value * 100))

    def set_memory(self, ram: str, vram: str, gpu: str = "--", cpu: str = "--") -> None:
        self.lbl_ram.configure(text=f"RAM: {ram}")
        self.lbl_vram.configure(text=f"VRAM: {vram}")
        self.lbl_gpu.configure(text=f"GPU: {gpu}")
        self.lbl_cpu.configure(text=f"CPU: {cpu}")
