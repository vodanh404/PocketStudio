"""Main application window."""
from __future__ import annotations

import logging
import time
from pathlib import Path
from tkinter import messagebox
from typing import Dict, Optional, Type, TYPE_CHECKING

import ttkbootstrap as ttk
from ttkbootstrap.constants import *

from app.ui.theme import apply_app_style
from app.ui.base_page import BasePage
from app.ui.widgets.sidebar import Sidebar
from app.ui.widgets.status_bar import StatusBar
from app.ui.pages.home import HomePage
from app.ui.pages.project import ProjectPage
from app.ui.pages.script import ScriptPage
from app.ui.pages.assets import AssetsPage
from app.ui.pages.video import VideoPage
from app.ui.pages.export import ExportPage
from app.ui.pages.logs import LogsPage
from app.ui.pages.settings import SettingsPage
from app.ui.pages.model_manager import ModelManagerPage
from app.core.events import event_bus
from app.core.exceptions import ValidationError, InvalidStateTransitionError
from app.models.pipeline_state import PipelineState, PipelineStateMachine
from app.controllers.pipeline_controller import PipelineController

if TYPE_CHECKING:
    from app.core.app_context import AppContext
    from app.pipelines.factory import PipelineFactory

logger = logging.getLogger(__name__)


class MainApp(ttk.Window):
    def __init__(self, **kwargs) -> None:
        super().__init__(title="MoneyPrinter Desktop", themename="darkly",
                         size=(1280, 800), minsize=(1024, 640), **kwargs)
        apply_app_style(self)
        self.pages: Dict[str, BasePage] = {}
        self.current_page: Optional[str] = None
        self.ctx = None
        self.pipeline_factory = None
        self.task_queue = None
        self.memory_manager = None
        self.model_pool = None
        self.pipeline = None
        self.current_project = None
        self.current_topic = None
        self.current_language = "vi"
        self.current_duration = None
        self.current_style = ""
        self.current_aspect_ratio = "9:16"
        self.current_task_id = None
        self.state_machine = PipelineStateMachine()
        self.controller = PipelineController(self)
        self.state_machine.on_change(self._on_state_changed)
        self._build_layout()
        self._register_pages()
        self._bind_events()
        self.navigate("home")
        self.after(3000, self._poll_memory)

    def _on_state_changed(self, state: PipelineState) -> None:
        # Runs from whatever thread called transition(); worker threads only
        # ever go through EventBus/here, never touching widgets directly.
        def _update() -> None:
            for page in self.pages.values():
                on_state_changed = getattr(page, "on_state_changed", None)
                if callable(on_state_changed):
                    on_state_changed(state)
        self.after(0, _update)

    def _build_layout(self) -> None:
        self.sidebar = Sidebar(self, on_navigate=self.navigate)
        self.sidebar.pack(side=LEFT, fill=Y)
        right = ttk.Frame(self, style="Content.TFrame")
        right.pack(side=LEFT, fill=BOTH, expand=True)
        self.content = ttk.Frame(right, style="Content.TFrame")
        self.content.pack(fill=BOTH, expand=True)
        self.status_bar = StatusBar(right)
        self.status_bar.pack(side=BOTTOM, fill=X)

    def _register_pages(self) -> None:
        page_classes: Dict[str, Type[BasePage]] = {
            "home": HomePage, "project": ProjectPage, "script": ScriptPage,
            "assets": AssetsPage, "video": VideoPage, "export": ExportPage,
            "logs": LogsPage, "settings": SettingsPage, "models": ModelManagerPage,
        }
        for key, cls in page_classes.items():
            page = cls(self.content, app=self)
            self.pages[key] = page
            page.place(relx=0, rely=0, relwidth=1, relheight=1)
            page.lower()

    def navigate(self, key: str) -> None:
        if key not in self.pages:
            logger.warning("Page not found: %s", key)
            return
        if self.current_page:
            self.pages[self.current_page].on_hide()
            self.pages[self.current_page].lower()
        self.current_page = key
        page = self.pages[key]
        page.lift()
        page.on_show()
        self.sidebar.set_active(key)
        self.status_bar.set_status(f"Page: {page.title}")

    def set_context(self, ctx: "AppContext", pipeline_factory: "PipelineFactory") -> None:
        self.ctx = ctx
        self.pipeline_factory = pipeline_factory
        self.task_queue = ctx.task_queue
        self.memory_manager = ctx.memory_manager
        self.model_pool = ctx.model_pool

    def create_project(self, topic: str = "", language: str = "vi") -> None:
        """Create an empty project: folders + metadata only.

        This deliberately does NOT touch the pipeline, the task queue, or
        any AI service. `topic`/`language` here are just an optional
        starting point for the Script page's form - the user can still
        change them before clicking "Generate Script". No AI generation
        happens until that explicit click.
        """
        name = f"proj_{int(time.time())}"
        projects_dir = Path(self.ctx.config.projects_dir) if self.ctx else Path("projects")
        project_dir = projects_dir / name
        project_dir.mkdir(parents=True, exist_ok=True)
        pipeline = self.pipeline_factory.create(project_dir) if self.pipeline_factory else None
        self.current_topic = topic
        self.current_language = language
        self.current_duration = None
        self.current_style = ""
        self.current_aspect_ratio = "9:16"
        self.current_project = type("Project", (), {
            "dir": project_dir, "name": name, "topic": topic, "script": "",
        })()
        self.pipeline = pipeline
        self.current_task_id = None
        self.status_bar.set_status(f"Project sẵn sàng: {name}")
        logger.info("Project created (empty, no pipeline run): %s", name)
        self.state_machine.transition(PipelineState.PROJECT_CREATED, force=True)
        self.state_machine.transition(PipelineState.WAITING_FOR_INPUT)

    def run_validated(self, action_label: str, fn) -> None:
        """Small helper for UI pages: run a controller call and translate
        ValidationError / InvalidStateTransitionError / any unexpected
        exception into a status-bar message + dialog instead of letting
        an exception reach Tk and kill the mainloop."""
        try:
            fn()
        except ValidationError as e:
            messagebox.showwarning(action_label, "\n".join(e.errors))
            self.status_bar.set_status(f"{action_label}: thiếu thông tin")
        except InvalidStateTransitionError as e:
            messagebox.showwarning(action_label, str(e))
            self.status_bar.set_status(f"{action_label}: chưa thể thực hiện lúc này")
        except Exception as e:  # noqa: BLE001 - last-resort UI safety net
            logger.exception("%s raised unexpected error", action_label)
            messagebox.showerror(action_label, f"Lỗi không mong đợi:\n{e}")
            self.status_bar.set_status(f"{action_label}: lỗi")

    def cancel_pipeline(self) -> None:
        if self.pipeline:
            self.pipeline.cancel()
        if self.current_task_id and self.task_queue:
            self.task_queue.cancel(self.current_task_id)
        self.status_bar.set_status("Đã gửi lệnh Cancel")

    def _pipeline_progress(self, stage: str, percent: float, message: str) -> None:
        def _update():
            self.status_bar.set_progress(percent)
            self.status_bar.set_status(f"[{stage}] {message}")
            if "video" in self.pages and hasattr(self.pages["video"], "update_progress"):
                self.pages["video"].update_progress(stage, percent, message)
            if "logs" in self.pages:
                self.pages["logs"].append(f"[{stage}] {percent*100:.0f}% - {message}")
        self.after(0, _update)

    def _bind_events(self) -> None:
        # Capture event payload into default-args so deferred after()
        # callbacks never close over a free variable that may be gone.
        event_bus.subscribe(
            "task.started",
            lambda d: self.after(
                0, lambda name=d.get("name", ""): self.status_bar.set_status(f"Running: {name}")
            ),
        )
        event_bus.subscribe(
            "task.finished",
            lambda d: self.after(
                0, lambda: (self.status_bar.set_status("Hoàn tất task"), self.status_bar.set_progress(0))
            ),
        )
        event_bus.subscribe(
            "task.failed",
            lambda d: self.after(
                0,
                lambda err=str(d.get("error", ""))[:60]: self.status_bar.set_status(f"Lỗi: {err}"),
            ),
        )

        def _on_pipeline_failed(title: str, data: dict) -> None:
            err = str((data or {}).get("error") or "Unknown error")
            logger.error("%s: %s", title, err)
            self.after(0, lambda t=title, e=err: (
                messagebox.showerror(t, e),
                self.status_bar.set_status(f"{t}: {e[:60]}"),
            ))

        event_bus.subscribe("ScriptGenerationFailed", lambda d: _on_pipeline_failed("Generate Script", d))
        event_bus.subscribe("ImageGenerationFailed", lambda d: _on_pipeline_failed("Generate Images", d))
        event_bus.subscribe("VideoGenerationFailed", lambda d: _on_pipeline_failed("Generate Video", d))
        def _on_stage_failed(data):
            data = data or {}
            stage = data.get("stage", "?")
            err = str(data.get("error") or "Unknown error")
            tb = str(data.get("traceback") or "")[-800:]
            msg = f"Stage: {stage}\n\n{err}"
            if tb:
                msg += f"\n\n--- Stack (rut gon) ---\n{tb}"
            logger.error("[UI] Stage failed %s: %s", stage, err)
            self.after(0, lambda m=msg, s=stage: (
                messagebox.showerror(f"Loi Stage: {s}", m),
                self.status_bar.set_status(f"[{s}] {err[:60]}"),
            ))
        event_bus.subscribe("pipeline.stage_failed", _on_stage_failed)


        for event_name in (
            "GenerateScriptRequested", "ScriptGenerated", "ScriptApproved",
            "GenerateImagesRequested", "ImagesGenerated",
            "GenerateVideoRequested", "VideoGenerated",
        ):
            event_bus.subscribe(event_name, lambda d, name=event_name: logger.info("[pipeline-event] %s: %s", name, d))

    def _poll_memory(self) -> None:
        if self.memory_manager:
            try:
                snap = self.memory_manager.get_snapshot()
                ram = f"{snap.ram_used_gb:.1f}G ({snap.ram_used_percent:.0f}%)"
                if snap.vram_total_gb > 0:
                    vram = f"{snap.vram_used_gb:.1f}/{snap.vram_total_gb:.1f}G ({snap.vram_used_percent:.0f}%)"
                else:
                    vram = f"{snap.vram_used_gb:.1f}G"
                if snap.torch_allocated_gb > 0:
                    vram += f" alloc={snap.torch_allocated_gb:.1f}G"
                gpu = f"{snap.gpu_util_percent:.0f}%"
                cpu = f"{snap.cpu_percent:.0f}%"
                self.status_bar.set_memory(ram, vram, gpu=gpu, cpu=cpu)
            except Exception:
                pass
        self.after(3000, self._poll_memory)

    def run(self) -> None:
        self.mainloop()
