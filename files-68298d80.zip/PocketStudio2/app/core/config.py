"""Configuration system with Performance Profiles."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from functools import lru_cache
from pathlib import Path
from typing import Any


class PerformanceMode(str, Enum):
    WEAK = "weak"
    BALANCED = "balanced"
    QUALITY = "quality"
    ULTRA = "ultra"


@dataclass
class AppConfig:
    base_dir: Path = field(default_factory=lambda: Path.cwd())
    projects_dir: Path = field(default_factory=lambda: Path("projects"))
    cache_dir: Path = field(default_factory=lambda: Path("cache"))
    models_dir: Path = field(default_factory=lambda: Path("models"))
    logs_dir: Path = field(default_factory=lambda: Path("logs"))

    mode: PerformanceMode = PerformanceMode.WEAK

    resolution: tuple[int, int] = (720, 1280)
    fps: int = 24
    batch_size: int = 1
    steps: int = 4
    guidance_scale: float = 0.0
    precision: str = "fp16"
    enable_attention_slicing: bool = True
    enable_vae_slicing: bool = True
    enable_cpu_offload: bool = True
    enable_xformers: bool = True

    image_model_priority: list[str] = field(default_factory=lambda: [
        "sdxl-turbo", "sdxl-lightning", "flux-schnell", "sd1.5",
    ])
    default_image_model: str = "sdxl-turbo"

    llm_model_priority: list[str] = field(default_factory=lambda: [
        "Qwen/Qwen2.5-0.5B-Instruct", "SmolLM2-360M", "TinyLlama-1.1B",
    ])
    default_llm_model: str = "Qwen/Qwen2.5-0.5B-Instruct"

    tts_engine: str = "edge"
    whisper_model: str = "tiny"
    default_voice: str = "vi-VN-HoaiMyNeural"

    # --- Scene / duration planning -----------------------------------
    # How many seconds of screen time one scene/image/clip covers.
    # scene_count = ceil(requested_duration_seconds / scene_duration_seconds)
    # This is the ONLY place that ratio should be configured - every
    # stage (script, scene split, image gen, render) reads it from here
    # (via app.core.duration.calculate_scene_count) instead of hardcoding
    # its own scene/image/clip limit.
    scene_duration_seconds: float = 8.0
    # Per-scene duration is clamped to this range when estimated from
    # sentence length (scene_split_stage) or used as a fallback when no
    # narration audio is available yet (render_stage).
    min_scene_duration: float = 2.0
    max_scene_duration: float = 12.0
    # Reserved for future crossfade/transition support in the renderer.
    transition_seconds: float = 0.5
    # Allowed user-facing video length range, in minutes.
    min_duration_minutes: float = 1.0
    max_duration_minutes: float = 20.0

    ram_warning_percent: float = 70.0
    ram_critical_percent: float = 85.0
    vram_warning_percent: float = 75.0
    model_idle_unload_seconds: int = 120

    enable_prompt_cache: bool = True
    enable_image_cache: bool = True
    max_cache_size_gb: float = 8.0

    theme: str = "darkly"
    language: str = "vi"

    def apply_mode(self, mode: PerformanceMode) -> None:
        self.mode = mode
        if mode == PerformanceMode.WEAK:
            # 512x768 is the practical ceiling for SD1.5/SDXL-Turbo on 4GB VRAM.
            # Higher requests are still clamped at generate-time, but starting
            # from the right default avoids wasted OOM recovery attempts.
            self.resolution = (512, 768)
            self.fps = 24
            self.batch_size = 1
            self.steps = 4
            self.precision = "fp16"
            self.enable_attention_slicing = True
            self.enable_vae_slicing = True
            self.enable_cpu_offload = True
            # Auto-selected at runtime by SDXLTurboBackend based on VRAM;
            # this is only the preferred hint for ≥6GB cards.
            self.default_image_model = "sdxl-turbo"
            self.whisper_model = "tiny"
        elif mode == PerformanceMode.BALANCED:
            self.resolution = (720, 1280)
            self.fps = 30
            self.batch_size = 1
            self.steps = 6
            self.enable_cpu_offload = True
        elif mode == PerformanceMode.QUALITY:
            self.resolution = (1080, 1920)
            self.fps = 30
            self.batch_size = 1
            self.steps = 8
            self.enable_cpu_offload = False
        elif mode == PerformanceMode.ULTRA:
            self.resolution = (1080, 1920)
            self.fps = 30
            self.batch_size = 2
            self.steps = 12
            self.enable_cpu_offload = False

    def scene_count_for(self, duration_seconds: float) -> int:
        """Number of scenes needed to cover `duration_seconds`, using
        this config's `scene_duration_seconds`. See app.core.duration
        for the underlying (uncapped) formula."""
        from app.core.duration import calculate_scene_count
        return calculate_scene_count(duration_seconds, self.scene_duration_seconds)

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode.value,
            "resolution": list(self.resolution),
            "fps": self.fps,
            "batch_size": self.batch_size,
            "steps": self.steps,
            "precision": self.precision,
            "default_image_model": self.default_image_model,
            "default_llm_model": self.default_llm_model,
            "tts_engine": self.tts_engine,
            "whisper_model": self.whisper_model,
            "theme": self.theme,
            "scene_duration_seconds": self.scene_duration_seconds,
            "min_scene_duration": self.min_scene_duration,
            "max_scene_duration": self.max_scene_duration,
            "transition_seconds": self.transition_seconds,
            "min_duration_minutes": self.min_duration_minutes,
            "max_duration_minutes": self.max_duration_minutes,
        }


@lru_cache(maxsize=1)
def get_config() -> AppConfig:
    return AppConfig()
