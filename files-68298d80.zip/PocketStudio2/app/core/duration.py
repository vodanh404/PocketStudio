"""Single source of truth for turning a target video duration into a
scene count (and vice-versa).

Every stage that used to compute (or hardcode) a scene/image/clip
count independently now calls into this module instead, so the
formula can never drift out of sync between the controller, the
script generator, the scene planner and the renderer.

Formula (see docs/AUTO_PIPELINE_FIX_REPORT.md for the bug this replaces):

    scene_count = ceil(duration_seconds / scene_duration_seconds)

No upper bound is applied here. Rejecting genuinely impossible
durations (e.g. 0 or 10000 minutes) is the job of
`app.core.validation.validate_script_request`, which runs *before*
this is ever called.
"""
from __future__ import annotations

import math

#: Default number of seconds of screen time a single scene/image/clip
#: covers when nothing more specific is configured. Overridable via
#: AppConfig.scene_duration_seconds.
DEFAULT_SCENE_DURATION_SECONDS = 8.0

#: Base token budget reserved for system/style instructions, independent
#: of how many scenes are requested.
_BASE_SCRIPT_TOKENS = 64

#: Rough token cost of one generated scene sentence. Deliberately
#: generous - truncation (not a few wasted tokens) is what silently caps
#: scene count, so this errs on the side of "more budget".
_TOKENS_PER_SCENE = 24


def calculate_scene_count(
    duration_seconds: float,
    scene_duration_seconds: float = DEFAULT_SCENE_DURATION_SECONDS,
) -> int:
    """Return how many scenes are needed to cover `duration_seconds`.

    Examples (at the default 8s/scene):
        60s   (1 min)  -> 8
        300s  (5 min)  -> 38
        600s  (10 min) -> 75
        1200s (20 min) -> 150
    """
    if not duration_seconds or duration_seconds <= 0:
        return 1
    if not scene_duration_seconds or scene_duration_seconds <= 0:
        scene_duration_seconds = DEFAULT_SCENE_DURATION_SECONDS
    return max(1, math.ceil(duration_seconds / scene_duration_seconds))


def estimate_max_new_tokens(
    max_scenes: int,
    tokens_per_scene: int = _TOKENS_PER_SCENE,
    base_tokens: int = _BASE_SCRIPT_TOKENS,
) -> int:
    """Scale the LLM generation token budget with the requested scene count.

    A fixed token budget (the original bug used a hardcoded 400)
    silently truncates the script once the model runs out of room,
    which is exactly what made a 20-minute request top out at ~17
    scenes instead of ~150. The budget must grow with `max_scenes` or
    every downstream stage inherits the shortfall.
    """
    max_scenes = max(1, int(max_scenes or 1))
    return base_tokens + max_scenes * tokens_per_scene


def duration_deviation_pct(actual_seconds: float, target_seconds: float) -> float:
    """Return how far `actual_seconds` is from `target_seconds`, as a
    percentage (e.g. 4.2 means 4.2% off). Used for the ±3% accuracy
    check/log in the render stage; never raises."""
    if not target_seconds:
        return 0.0
    return abs(actual_seconds - target_seconds) / target_seconds * 100.0
