"""Custom exceptions."""
from __future__ import annotations


class AppError(Exception):
    """Base application error."""


class PipelineError(AppError):
    """Pipeline execution error."""


class ModelLoadError(AppError):
    """Model loading failed."""


class RenderError(AppError):
    """FFmpeg render error."""


class CancelledError(AppError):
    """Task was cancelled."""


class ValidationError(AppError):
    """Raised when user input / project state fails validation before a
    pipeline stage is allowed to run. Carries a list of user-friendly
    messages that the UI can show directly (e.g. in a dialog)."""

    def __init__(self, errors: "list[str] | str") -> None:
        self.errors: list[str] = [errors] if isinstance(errors, str) else list(errors)
        super().__init__("; ".join(self.errors))


class InvalidStateTransitionError(AppError):
    """Raised when a pipeline action is requested while the project's
    PipelineState does not permit it (e.g. clicking 'Generate Video'
    before images exist)."""
