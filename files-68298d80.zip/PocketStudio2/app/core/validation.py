"""Pre-flight validation for each pipeline stage.

These functions NEVER touch the pipeline, the task queue, or any AI
service. They only decide "is it safe to start this stage right now",
and raise ValidationError with user-friendly (Vietnamese) messages if not.

The Controller calls these before submitting any background job. The UI
may also call them proactively (e.g. to decide whether to enable a
button), but the Controller check is the one that actually guards
execution - never trust the UI state alone.
"""
from __future__ import annotations

from typing import Any, Optional

from app.core.exceptions import ValidationError

# Allowed video length range. The UI field is in seconds, so these are
# expressed in seconds too (1~20 minutes). Kept here as the validator's
# own constants (rather than importing AppConfig) so validation never
# depends on the service layer - only reject durations that are
# genuinely impossible, nothing more.
MIN_DURATION_SECONDS = 60.0    # 1 minute
MAX_DURATION_SECONDS = 1200.0  # 20 minutes


def validate_script_request(
    topic: str,
    language: Optional[str],
    duration: Optional[float],
) -> None:
    errors: list[str] = []
    if not topic or not topic.strip():
        errors.append("Vui lòng nhập chủ đề / mô tả video.")
    if not language or not str(language).strip():
        errors.append("Vui lòng chọn ngôn ngữ.")
    if duration is None or duration <= 0:
        errors.append("Vui lòng nhập thời lượng mong muốn (phải lớn hơn 0).")
    elif duration < MIN_DURATION_SECONDS or duration > MAX_DURATION_SECONDS:
        errors.append(
            "Thời lượng video phải trong khoảng 1-20 phút "
            f"({MIN_DURATION_SECONDS:.0f}-{MAX_DURATION_SECONDS:.0f} giây)."
        )
    if errors:
        raise ValidationError(errors)


def validate_images_request(project: Any) -> None:
    errors: list[str] = []
    script = getattr(project, "script", None) if project else None
    if project is None:
        errors.append("Chưa có project. Hãy tạo project trước.")
    elif not script or not str(script).strip():
        errors.append("Hãy tạo kịch bản (Generate Script) trước khi tạo hình ảnh.")
    if errors:
        raise ValidationError(errors)


def validate_video_request(project: Any, images_ready: bool) -> None:
    errors: list[str] = []
    if project is None:
        errors.append("Chưa có project. Hãy tạo project trước.")
    elif not images_ready:
        errors.append("Chưa có hình ảnh. Hãy tạo hình ảnh (Generate Images) trước khi tạo video.")
    if errors:
        raise ValidationError(errors)
