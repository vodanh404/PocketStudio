"""Voice generation via Edge-TTS with validation + retry.

Root cause of "No audio was received. Please verify that your parameters
are correct." was a combination of:

1. Empty / whitespace-only text reaching Communicate (Edge rejects it).
2. No post-save validation – a 0-byte file looked like success.
3. asyncio.run() without timeout – hung connections never failed cleanly.
4. No retry on transient network errors.
5. Rate/volume not normalised (Edge is picky about the exact "+0%" form).
"""
from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path
from typing import Any, Optional

from app.core.exceptions import PipelineError
from app.models.pipeline import SceneVoice, VoiceResult, SceneSplitResult
from app.pipelines.stages.base import BaseStage, ProgressCallback
from app.utils.file_checker import ensure_dir
from app.utils.retry import retry_call
from app.utils.validators import (
    AudioValidator,
    DependencyChecker,
    ValidationFailed,
    validate_scenes,
    validate_tts_text,
    validate_voice_name,
)

logger = logging.getLogger(__name__)

# Edge-TTS rate/volume must match e.g. "+0%", "-10%", "+15%"
_RATE_RE = re.compile(r"^[+-]\d+%$")
_VOLUME_RE = re.compile(r"^[+-]\d+%$")


def _normalise_rate(rate: str) -> str:
    rate = (rate or "+0%").strip()
    if not _RATE_RE.match(rate):
        logger.warning("[TTS] rate %r invalid → +0%%", rate)
        return "+0%"
    return rate


def _normalise_volume(volume: str) -> str:
    volume = (volume or "+0%").strip()
    if not _VOLUME_RE.match(volume):
        logger.warning("[TTS] volume %r invalid → +0%%", volume)
        return "+0%"
    return volume


class VoiceStage(BaseStage):
    name = "voice"

    def __init__(
        self,
        output_dir: Path,
        default_voice: str = "vi-VN-HoaiMyNeural",
        rate: str = "+0%",
        volume: str = "+0%",
        cache: Any = None,
        max_retries: int = 3,
        synthesize_timeout: float = 60.0,
    ) -> None:
        super().__init__()
        self.output_dir = ensure_dir(output_dir)
        self.default_voice = default_voice
        self.rate = _normalise_rate(rate)
        self.volume = _normalise_volume(volume)
        self.cache = cache
        self.max_retries = max_retries
        self.synthesize_timeout = synthesize_timeout

    def run(
        self,
        input_data: SceneSplitResult,
        progress: Optional[ProgressCallback] = None,
        existing: Optional[VoiceResult] = None,
        **kwargs: Any,
    ) -> VoiceResult:
        logger.info("[TTS] VoiceStage START")
        scenes = validate_scenes(getattr(input_data, "scenes", None))
        voice = validate_voice_name(kwargs.get("voice", self.default_voice))
        rate = _normalise_rate(kwargs.get("rate", self.rate))
        volume = _normalise_volume(kwargs.get("volume", self.volume))

        if not DependencyChecker.check_network_for_tts(timeout=5.0):
            logger.warning(
                "[TTS] Network probe failed – Edge-TTS may still work if "
                "cached DNS / proxy is available; continuing with retries."
            )

        existing_map = {v.scene_index: v for v in (existing.voices if existing else [])}
        voices: list[SceneVoice] = []
        total = len(scenes)

        for i, scene in enumerate(scenes):
            self._check_cancelled()
            if scene.index in existing_map:
                existing_voice = existing_map[scene.index]
                # Re-validate cached audio so a corrupt checkpoint cannot
                # poison the rest of the pipeline.
                try:
                    AudioValidator.validate(Path(existing_voice.audio_path))
                    voices.append(existing_voice)
                    if progress:
                        progress((i + 1) / total, f"Bỏ qua voice cảnh {scene.index}")
                    continue
                except Exception as e:
                    logger.warning(
                        "[TTS] Existing voice scene %s invalid (%s) – regenerating",
                        scene.index, e,
                    )

            if progress:
                progress(i / max(total, 1), f"Tạo voice cảnh {scene.index + 1}/{total}")

            text = validate_tts_text(getattr(scene, "text", None))
            audio_path = self.output_dir / f"scene_{scene.index:03d}.mp3"
            try:
                duration = self._synthesize_with_retry(text, audio_path, voice, rate, volume)
            except Exception as e:
                raise PipelineError(
                    f"[TTS] Scene {scene.index} failed: {e}"
                ) from e

            voices.append(SceneVoice(
                scene_index=scene.index,
                audio_path=str(audio_path),
                duration=duration,
                voice=voice,
            ))

        if not voices:
            raise PipelineError("[TTS] Không tạo được file audio nào.")

        # Hard gate: every scene must have a corresponding audio file.
        if len(voices) != len(scenes):
            raise PipelineError(
                f"[TTS] Thiếu audio: có {len(voices)}/{len(scenes)} scene."
            )

        total_duration = sum(v.duration for v in voices)
        if progress:
            progress(1.0, f"Voice xong – tổng {total_duration:.1f}s")
        logger.info(
            "[TTS] VoiceStage END – %d files, total %.1fs",
            len(voices), total_duration,
        )
        return VoiceResult(voices=voices, total_duration=total_duration)

    def _synthesize_with_retry(
        self,
        text: str,
        output_path: Path,
        voice: str,
        rate: str,
        volume: str,
    ) -> float:
        def _once() -> float:
            return self._synthesize_once(text, output_path, voice, rate, volume)

        return retry_call(
            _once,
            attempts=self.max_retries,
            base_delay=1.0,
            label=f"TTS[{output_path.name}]",
            exceptions=(Exception,),
        )

    def _synthesize_once(
        self,
        text: str,
        output_path: Path,
        voice: str,
        rate: str,
        volume: str,
    ) -> float:
        try:
            import edge_tts
        except ImportError as e:
            raise PipelineError(
                "Thiếu package edge-tts. Cài: pip install edge-tts"
            ) from e

        # Remove stale file so a partial write from a previous attempt cannot
        # be mistaken for success.
        if output_path.exists():
            output_path.unlink(missing_ok=True)

        logger.info(
            "[TTS] synthesize voice=%s rate=%s volume=%s text_len=%d → %s",
            voice, rate, volume, len(text), output_path.name,
        )

        async def _run() -> None:
            communicate = edge_tts.Communicate(
                text=text,
                voice=voice,
                rate=rate,
                volume=volume,
            )
            await communicate.save(str(output_path))

        try:
            asyncio.run(asyncio.wait_for(_run(), timeout=self.synthesize_timeout))
        except asyncio.TimeoutError as e:
            raise PipelineError(
                f"[TTS] Timeout sau {self.synthesize_timeout:.0f}s "
                f"(voice={voice}). Kiểm tra mạng."
            ) from e
        except Exception as e:
            # edge-tts raises NoAudioReceived / generic Exception with the
            # message the user reported. Surface it cleanly.
            msg = str(e) or type(e).__name__
            if "No audio was received" in msg or "NoAudioReceived" in type(e).__name__:
                raise PipelineError(
                    f"[TTS] No audio was received (voice={voice}, rate={rate}, "
                    f"volume={volume}, text_len={len(text)}). "
                    "Kiểm tra: text không rỗng, voice hợp lệ, có internet."
                ) from e
            raise PipelineError(f"[TTS] Edge-TTS error: {msg}") from e

        # Post-save hard validation – never return success on empty/corrupt file.
        try:
            duration = AudioValidator.validate(output_path)
        except ValidationFailed as e:
            # Ensure partial file is not kept as a false checkpoint.
            output_path.unlink(missing_ok=True)
            raise PipelineError(str(e)) from e

        return duration
