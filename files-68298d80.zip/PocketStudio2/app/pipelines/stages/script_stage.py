from __future__ import annotations

import logging
from typing import Any, Optional

from app.core.exceptions import PipelineError
from app.models.pipeline import ScriptResult
from app.pipelines.stages.base import BaseStage, ProgressCallback
from app.utils.retry import retry_call
from app.utils.script_expansion import build_fallback_script
from app.utils.validators import validate_script_text, validate_topic

logger = logging.getLogger(__name__)

_DEFAULT_MAX_SCENES_FALLBACK = 6


class ScriptStage(BaseStage):
    name = "script"

    def __init__(self, llm_service: Any = None, max_retries: int = 3) -> None:
        super().__init__()
        self.llm = llm_service
        self.max_retries = max_retries

    def run(
        self,
        input_data: dict[str, Any],
        progress: Optional[ProgressCallback] = None,
        **kwargs: Any,
    ) -> ScriptResult:
        logger.info("[Stage] ScriptStage START")
        topic = validate_topic(input_data.get("topic"))
        language = input_data.get("language", "vi") or "vi"
        max_scenes = int(
            input_data.get("max_scenes", _DEFAULT_MAX_SCENES_FALLBACK)
            or _DEFAULT_MAX_SCENES_FALLBACK
        )
        max_scenes = max(1, max_scenes)

        if progress:
            progress(0.1, "Đang tạo kịch bản...")
        self._check_cancelled()

        if self.llm:
            try:
                script = retry_call(
                    lambda: self.llm.generate_script(
                        topic, language=language, max_scenes=max_scenes,
                    ),
                    attempts=self.max_retries,
                    base_delay=1.0,
                    label="LLM.generate_script",
                )
            except Exception as e:
                logger.warning("[Stage] LLM script failed (%s) → fallback", e)
                script = self._fallback_script(topic, language, max_scenes)
        else:
            script = self._fallback_script(topic, language, max_scenes)

        script = validate_script_text(script)
        if progress:
            progress(1.0, "Kịch bản hoàn tất")
        logger.info("[Stage] ScriptStage END – %d chars", len(script))
        return ScriptResult(topic=topic, full_script=script, language=language)

    def _fallback_script(self, topic: str, language: str, max_scenes: int) -> str:
        return build_fallback_script(topic, language, max_scenes)
