from __future__ import annotations

import logging
from typing import Any, Optional

from app.core.exceptions import PipelineError
from app.models.pipeline import ScenePrompt, PromptGenResult, SceneSplitResult
from app.pipelines.stages.base import BaseStage, ProgressCallback
from app.utils.retry import retry_call
from app.utils.validators import validate_scenes

logger = logging.getLogger(__name__)


class PromptGenStage(BaseStage):
    name = "prompt_gen"

    def __init__(self, llm_service: Any = None, max_retries: int = 2) -> None:
        super().__init__()
        self.llm = llm_service
        self.max_retries = max_retries

    def run(
        self,
        input_data: SceneSplitResult,
        progress: Optional[ProgressCallback] = None,
        **kwargs: Any,
    ) -> PromptGenResult:
        logger.info("[Stage] PromptGenStage START")
        scenes = validate_scenes(getattr(input_data, "scenes", None))
        style = kwargs.get("style", "cinematic, highly detailed, 8k, dramatic lighting")
        prompts: list[ScenePrompt] = []
        total = len(scenes)

        for i, scene in enumerate(scenes):
            self._check_cancelled()
            text = (getattr(scene, "text", None) or "").strip()
            if not text:
                raise PipelineError(f"[Prompt] Scene {scene.index} text rỗng.")

            if progress:
                progress(i / max(total, 1), f"Tạo prompt cảnh {i + 1}/{total}")

            if self.llm:
                try:
                    prompt_text = retry_call(
                        lambda t=text: self.llm.generate_image_prompt(t, style=style),
                        attempts=self.max_retries,
                        base_delay=1.0,
                        label=f"LLM.image_prompt[{scene.index}]",
                    )
                except Exception as e:
                    logger.warning(
                        "[Prompt] LLM failed for scene %s (%s) → fallback",
                        scene.index, e,
                    )
                    prompt_text = self._fallback_prompt(scene, style)
            else:
                prompt_text = self._fallback_prompt(scene, style)

            prompt_text = (prompt_text or "").strip()
            if not prompt_text:
                raise PipelineError(
                    f"[Prompt] Prompt cảnh {scene.index} rỗng sau generate."
                )

            prompts.append(ScenePrompt(
                scene_index=scene.index,
                prompt=prompt_text,
                negative_prompt=(
                    "blurry, low quality, distorted, text, watermark, ugly, deformed"
                ),
                seed=kwargs.get("base_seed", 42) + scene.index,
            ))

        if not prompts:
            raise PipelineError("[Prompt] Không tạo được prompt nào.")
        if progress:
            progress(1.0, "Prompt generation hoàn tất")
        logger.info("[Stage] PromptGenStage END – %d prompts", len(prompts))
        return PromptGenResult(prompts=prompts)

    def _fallback_prompt(self, scene, style: str) -> str:
        keywords = ", ".join(scene.keywords) if scene.keywords else scene.text[:60]
        return f"{keywords}, {style}, vertical composition, high quality"
