from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from app.core.exceptions import PipelineError
from app.models.pipeline import SubtitleResult, SceneSubtitle, SubtitleCue, VoiceResult
from app.pipelines.stages.base import BaseStage, ProgressCallback
from app.utils.file_checker import ensure_dir, require_non_empty
from app.utils.validators import SubtitleValidator, ValidationFailed

logger = logging.getLogger(__name__)


class SubtitleStage(BaseStage):
    name = "subtitle"
    MODEL_NAME = "whisper-tiny"

    def __init__(
        self,
        model_pool: Any,
        output_dir: Path,
        device: str = "cpu",
        compute_type: str = "int8",
    ) -> None:
        super().__init__()
        self.model_pool = model_pool
        self.output_dir = ensure_dir(output_dir)
        self.device = device
        self.compute_type = compute_type
        self.model_pool.register(self.MODEL_NAME, self._load_model)

    def _load_model(self):
        from faster_whisper import WhisperModel
        logger.info(
            "[Subtitle] Loading Faster-Whisper tiny (%s, %s)...",
            self.device, self.compute_type,
        )
        return WhisperModel("tiny", device=self.device, compute_type=self.compute_type)

    def run(
        self,
        input_data: VoiceResult,
        progress: Optional[ProgressCallback] = None,
        existing: Optional[SubtitleResult] = None,
        language: str = "vi",
        **kwargs: Any,
    ) -> SubtitleResult:
        logger.info("[Subtitle] SubtitleStage START")
        voices = getattr(input_data, "voices", None) or []
        if not voices:
            raise PipelineError("[Subtitle] Không có voice audio – không thể tạo subtitle.")

        existing_map = {
            s.scene_index: s for s in (existing.subtitles if existing else [])
        }
        subtitles: list[SceneSubtitle] = []
        total = len(voices)
        model = self.model_pool.acquire(self.MODEL_NAME)
        try:
            for i, voice in enumerate(voices):
                self._check_cancelled()
                if voice.scene_index in existing_map:
                    existing_sub = existing_map[voice.scene_index]
                    try:
                        SubtitleValidator.validate(Path(existing_sub.srt_path))
                        subtitles.append(existing_sub)
                        if progress:
                            progress(
                                (i + 1) / total,
                                f"Bỏ qua subtitle cảnh {voice.scene_index}",
                            )
                        continue
                    except Exception as e:
                        logger.warning(
                            "[Subtitle] Existing SRT scene %s invalid (%s) – regenerating",
                            voice.scene_index, e,
                        )

                audio_path = Path(voice.audio_path)
                try:
                    require_non_empty(audio_path, label=f"audio scene {voice.scene_index}")
                except Exception as e:
                    raise PipelineError(
                        f"[Subtitle] Audio đầu vào thiếu/corrupt cho scene "
                        f"{voice.scene_index}: {e}"
                    ) from e

                if progress:
                    progress(i / max(total, 1), f"Whisper cảnh {voice.scene_index + 1}/{total}")

                try:
                    cues = self._transcribe(model, str(audio_path), language)
                    srt_path = self.output_dir / f"scene_{voice.scene_index:03d}.srt"
                    self._write_srt(cues, srt_path)
                    SubtitleValidator.validate(srt_path)
                except Exception as e:
                    raise PipelineError(
                        f"[Subtitle] Scene {voice.scene_index} failed: {e}"
                    ) from e

                subtitles.append(SceneSubtitle(
                    scene_index=voice.scene_index,
                    srt_path=str(srt_path),
                    cues=cues,
                ))
        finally:
            self.model_pool.release(self.MODEL_NAME)

        if not subtitles:
            raise PipelineError("[Subtitle] Không tạo được subtitle nào.")
        if len(subtitles) != len(voices):
            raise PipelineError(
                f"[Subtitle] Thiếu SRT: có {len(subtitles)}/{len(voices)} scene."
            )

        if progress:
            progress(1.0, "Subtitle hoàn tất")
        logger.info("[Subtitle] SubtitleStage END – %d files", len(subtitles))
        return SubtitleResult(subtitles=subtitles)

    def _transcribe(self, model, audio_path: str, language: str) -> list[SubtitleCue]:
        segments, _ = model.transcribe(
            audio_path,
            language=language,
            beam_size=1,
            vad_filter=True,
            word_timestamps=False,
        )
        cues: list[SubtitleCue] = []
        for idx, seg in enumerate(segments):
            text = (seg.text or "").strip()
            if not text:
                continue
            cues.append(SubtitleCue(
                index=idx, start=float(seg.start), end=float(seg.end), text=text,
            ))
        # Even if Whisper returns nothing (silent / noise), produce a
        # single placeholder cue so downstream SRT parsing does not fail.
        if not cues:
            logger.warning(
                "[Subtitle] Whisper returned 0 segments for %s – placeholder cue",
                audio_path,
            )
            cues.append(SubtitleCue(index=0, start=0.0, end=1.0, text="..."))
        return cues

    @staticmethod
    def _write_srt(cues: list[SubtitleCue], path: Path) -> None:
        def fmt(t: float) -> str:
            h = int(t // 3600)
            m = int((t % 3600) // 60)
            s = int(t % 60)
            ms = int((t % 1) * 1000)
            return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

        lines: list[str] = []
        for i, cue in enumerate(cues, 1):
            lines.append(str(i))
            lines.append(f"{fmt(cue.start)} --> {fmt(cue.end)}")
            lines.append(cue.text)
            lines.append("")
        path.write_text("\n".join(lines), encoding="utf-8")
