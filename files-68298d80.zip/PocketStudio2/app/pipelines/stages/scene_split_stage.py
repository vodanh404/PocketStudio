from __future__ import annotations

import logging
import re
from typing import Any, Optional

from app.core.exceptions import PipelineError
from app.models.pipeline import Scene, SceneSplitResult
from app.pipelines.stages.base import BaseStage, ProgressCallback
from app.utils.validators import validate_script_text

logger = logging.getLogger(__name__)


class SceneSplitStage(BaseStage):
    name = "scene_split"

    def __init__(
        self,
        min_scene_duration: float = 2.0,
        max_scene_duration: float = 6.0,
    ) -> None:
        super().__init__()
        self.min_scene_duration = min_scene_duration
        self.max_scene_duration = max_scene_duration

    def run(
        self,
        input_data: Any,
        progress: Optional[ProgressCallback] = None,
        **kwargs: Any,
    ) -> SceneSplitResult:
        logger.info("[Stage] SceneSplitStage START")
        script = validate_script_text(getattr(input_data, "full_script", None))
        if progress:
            progress(0.1, "Đang tách cảnh...")

        raw_sentences = re.split(r"(?<=[.!?…\n])\s+", script.strip())
        sentences = [s.strip() for s in raw_sentences if s.strip()]
        if not sentences:
            raise PipelineError("[Scene] Script không tách được câu nào.")

        target_scenes = kwargs.get("max_scenes")
        if target_scenes is not None:
            target = max(1, int(target_scenes))
            if len(sentences) > target:
                logger.info(
                    "[Scene] Script has %d sentences, capping to max_scenes=%d",
                    len(sentences), target,
                )
                sentences = sentences[:target]
            elif len(sentences) < target:
                logger.info(
                    "[Scene] Script has %d sentences < max_scenes=%d – "
                    "using actual sentence count (no padding).",
                    len(sentences), target,
                )

        scenes: list[Scene] = []
        for idx, text in enumerate(sentences):
            self._check_cancelled()
            if not text.strip():
                continue
            word_count = len(text.split())
            duration = max(
                self.min_scene_duration,
                min(self.max_scene_duration, word_count * 0.35),
            )
            keywords = self._extract_keywords(text)
            scenes.append(
                Scene(index=idx, text=text, duration_hint=duration, keywords=keywords)
            )
            if progress:
                progress(
                    0.1 + 0.8 * (idx + 1) / max(len(sentences), 1),
                    f"Cảnh {idx + 1}",
                )

        if not scenes:
            raise PipelineError("[Scene] Không tạo được scene nào từ script.")

        total = sum(s.duration_hint for s in scenes)
        if progress:
            progress(1.0, f"Tách xong {len(scenes)} cảnh")
        logger.info("[Stage] SceneSplitStage END – %d scenes", len(scenes))
        return SceneSplitResult(scenes=scenes, total_duration_estimate=total)

    def _extract_keywords(self, text: str) -> list[str]:
        words = re.findall(r"\b\w{4,}\b", text.lower())
        return list(dict.fromkeys(words))[:5]
