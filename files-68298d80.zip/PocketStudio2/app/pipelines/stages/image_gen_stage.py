"""Image generation stage with full input/output validation.

If any scene image is missing or corrupt the stage raises – the
orchestrator must not advance to voice/subtitle/render.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from app.core.exceptions import PipelineError
from app.models.pipeline import ImageGenResult, PromptGenResult, SceneImage
from app.pipelines.stages.base import BaseStage, ProgressCallback
from app.utils.file_checker import ensure_dir
from app.utils.retry import retry_call
from app.utils.validators import ImageValidator, validate_prompts

logger = logging.getLogger(__name__)


class ImageGenStage(BaseStage):
    name = "image_gen"

    def __init__(
        self,
        image_backend: Any,
        output_dir: Path,
        max_retries: int = 3,
    ) -> None:
        super().__init__()
        self.backend = image_backend
        self.output_dir = ensure_dir(output_dir)
        self.max_retries = max_retries

    def run(
        self,
        input_data: PromptGenResult,
        progress: Optional[ProgressCallback] = None,
        existing: Optional[ImageGenResult] = None,
        **kwargs: Any,
    ) -> ImageGenResult:
        logger.info("[Image] ImageGenStage START")
        if self.backend is None:
            raise PipelineError("[Image] image_backend chưa được inject.")

        prompts = validate_prompts(getattr(input_data, "prompts", None))
        width = int(kwargs.get("width", 512))
        height = int(kwargs.get("height", 768))
        steps = int(kwargs.get("steps", 4))
        guidance = float(kwargs.get("guidance_scale", 0.0))

        existing_map = {img.scene_index: img for img in (existing.images if existing else [])}
        images: list[SceneImage] = []
        total = len(prompts)

        for i, sp in enumerate(prompts):
            self._check_cancelled()
            prompt_text = (getattr(sp, "prompt", None) or "").strip()
            if not prompt_text:
                raise PipelineError(f"[Image] Prompt cảnh {sp.scene_index} rỗng.")

            if sp.scene_index in existing_map:
                existing_img = existing_map[sp.scene_index]
                try:
                    ImageValidator.validate(Path(existing_img.image_path))
                    images.append(existing_img)
                    if progress:
                        progress((i + 1) / total, f"Bỏ qua cảnh {sp.scene_index} (đã có)")
                    continue
                except Exception as e:
                    logger.warning(
                        "[Image] Existing image scene %s invalid (%s) – regenerating",
                        sp.scene_index, e,
                    )

            if progress:
                progress(i / max(total, 1), f"Generating cảnh {sp.scene_index + 1}/{total}")

            try:
                path = self._generate_with_retry(
                    prompt=prompt_text,
                    negative_prompt=getattr(sp, "negative_prompt", "") or "",
                    width=width,
                    height=height,
                    steps=steps,
                    guidance=guidance,
                    seed=getattr(sp, "seed", None),
                    scene_index=sp.scene_index,
                )
                ImageValidator.validate(path)
            except Exception as e:
                raise PipelineError(
                    f"[Image] Scene {sp.scene_index} failed: {e}"
                ) from e

            images.append(SceneImage(
                scene_index=sp.scene_index,
                image_path=str(path),
                width=width,
                height=height,
                seed=getattr(sp, "seed", None),
            ))
            if progress:
                progress((i + 1) / total, f"Đã xong cảnh {sp.scene_index + 1}")

        if not images:
            raise PipelineError("[Image] Không tạo được ảnh nào.")
        if len(images) != len(prompts):
            raise PipelineError(
                f"[Image] Thiếu ảnh: có {len(images)}/{len(prompts)} scene. "
                "Không được render video khi thiếu ảnh."
            )

        logger.info("[Image] ImageGenStage END – %d images", len(images))
        return ImageGenResult(images=images)

    def _generate_with_retry(
        self,
        *,
        prompt: str,
        negative_prompt: str,
        width: int,
        height: int,
        steps: int,
        guidance: float,
        seed: Optional[int],
        scene_index: int,
    ) -> Path:
        def _once() -> Path:
            path = self.backend.generate(
                prompt=prompt,
                negative_prompt=negative_prompt,
                width=width,
                height=height,
                num_inference_steps=steps,
                guidance_scale=guidance,
                seed=seed,
                output_dir=self.output_dir,
            )
            if path is None:
                raise PipelineError(f"[Image] backend.generate returned None (scene {scene_index})")
            return Path(path)

        return retry_call(
            _once,
            attempts=self.max_retries,
            base_delay=1.0,
            label=f"Image[scene={scene_index}]",
            exceptions=(Exception,),
        )
