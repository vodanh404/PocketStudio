from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Callable, Optional
import threading

logger = logging.getLogger(__name__)
ProgressCallback = Callable[[float, str], None]


class BaseStage(ABC):
    name: str = "base"

    def __init__(self) -> None:
        self.cancel_event: Optional[threading.Event] = None

    def is_cancelled(self) -> bool:
        return self.cancel_event is not None and self.cancel_event.is_set()

    def _check_cancelled(self) -> None:
        if self.is_cancelled():
            raise RuntimeError(f"Stage '{self.name}' cancelled")

    @abstractmethod
    def run(self, input_data: Any, progress: Optional[ProgressCallback] = None, **kwargs: Any) -> Any:
        """Execute stage domain logic.

        Must raise on failure (never return a partial success that the
        orchestrator would treat as OK). StageExecutor wraps this into
        StageResult.
        """
        ...
