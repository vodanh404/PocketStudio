"""Pipeline Orchestrator with checkpoint + resume + StageResult gating.

A stage only runs if every previous stage in this invocation succeeded.
On StageResult.success == False the pipeline stops immediately: no further
stages are started, the failure is logged, and a PipelineError is raised so
the controller / TaskQueue surface a clear error to the UI.
"""
from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Any, Callable, Optional

from app.core.events import event_bus
from app.core.exceptions import PipelineError
from app.models.pipeline import (
    StageName, ScriptResult, SceneSplitResult, PromptGenResult,
    ImageGenResult, VoiceResult, SubtitleResult, RenderResult,
)
from app.models.stage_result import StageResult
from app.pipelines.checkpoint import CheckpointManager
from app.pipelines.stage_executor import StageExecutor
from app.pipelines.stages.script_stage import ScriptStage
from app.pipelines.stages.scene_split_stage import SceneSplitStage
from app.pipelines.stages.prompt_gen_stage import PromptGenStage
from app.pipelines.stages.image_gen_stage import ImageGenStage
from app.pipelines.stages.voice_stage import VoiceStage
from app.pipelines.stages.subtitle_stage import SubtitleStage
from app.pipelines.stages.render_stage import RenderStage

logger = logging.getLogger(__name__)
ProgressCallback = Callable[[str, float, str], None]


class VideoPipeline:
    def __init__(
        self,
        project_dir: Path,
        script_stage: ScriptStage,
        scene_stage: SceneSplitStage,
        prompt_stage: PromptGenStage,
        image_stage: ImageGenStage,
        voice_stage: VoiceStage,
        subtitle_stage: SubtitleStage,
        render_stage: RenderStage,
    ) -> None:
        self.project_dir = Path(project_dir)
        self.checkpoint = CheckpointManager(self.project_dir)
        self.stages = {
            StageName.SCRIPT: script_stage,
            StageName.SCENE_SPLIT: scene_stage,
            StageName.PROMPT_GEN: prompt_stage,
            StageName.IMAGE_GEN: image_stage,
            StageName.VOICE: voice_stage,
            StageName.SUBTITLE: subtitle_stage,
            StageName.RENDER: render_stage,
        }
        self.cancel_event = threading.Event()

    def _finish(self, results: dict[str, Any]) -> dict[str, Any]:
        logger.info(
            "[Pipeline] finished (stages completed this run: %s)",
            list(results.keys()),
        )
        return results

    def cancel(self) -> None:
        self.cancel_event.set()
        for stage in self.stages.values():
            stage.cancel_event = self.cancel_event

    def _run_stage(
        self,
        stage_name: StageName,
        input_data: Any,
        *,
        progress: Optional[ProgressCallback],
        progress_label: str,
        **kwargs: Any,
    ) -> StageResult:
        stage = self.stages[stage_name]
        stage.cancel_event = self.cancel_event
        if progress:
            progress(stage_name.value, 0.0, progress_label)

        def _stage_progress(p: float, m: str) -> None:
            if progress:
                progress(stage_name.value, p, m)

        executor = StageExecutor(stage)
        result = executor.execute(input_data, progress=_stage_progress, **kwargs)

        event_bus.publish(
            "pipeline.stage_finished",
            {
                "stage": stage_name.value,
                "success": result.success,
                "elapsed": result.elapsed_time,
                "error": result.error_message,
            },
        )

        if not result.success:
            event_bus.publish(
                "pipeline.stage_failed",
                {
                    "stage": stage_name.value,
                    "error": result.error_message,
                    "traceback": (result.metadata or {}).get("traceback", ""),
                },
            )
            raise PipelineError(
                f"Stage '{stage_name.value}' failed: {result.error_message}"
            )
        return result

    def run(
        self,
        topic: str,
        language: str = "vi",
        resume: bool = True,
        progress: Optional[ProgressCallback] = None,
        until_stage: Optional[StageName] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run pipeline stages in order.

        Stops after ``until_stage`` (inclusive) when given. Stops immediately
        and raises ``PipelineError`` if any stage returns failure.
        """
        self.cancel_event.clear()
        results: dict[str, Any] = {}
        logger.info(
            "[Pipeline] START topic=%r language=%s until=%s resume=%s",
            topic, language, until_stage, resume,
        )

        def _reached(stage: StageName) -> bool:
            return until_stage is not None and stage == until_stage

        # 1. SCRIPT
        if resume and self.checkpoint.exists(StageName.SCRIPT.value):
            data = self.checkpoint.load(StageName.SCRIPT.value)
            results[StageName.SCRIPT.value] = ScriptResult.from_dict(data)
            logger.info("[Pipeline] Resumed SCRIPT")
        else:
            script_input: dict[str, Any] = {"topic": topic, "language": language}
            if "max_scenes" in kwargs:
                script_input["max_scenes"] = kwargs["max_scenes"]
            if "target_duration_seconds" in kwargs:
                script_input["target_duration_seconds"] = kwargs["target_duration_seconds"]
            sr = self._run_stage(
                StageName.SCRIPT, script_input,
                progress=progress, progress_label="Bắt đầu tạo kịch bản",
            )
            self.checkpoint.save(StageName.SCRIPT.value, sr.output.to_dict())
            results[StageName.SCRIPT.value] = sr.output
        if self.cancel_event.is_set() or _reached(StageName.SCRIPT):
            return self._finish(results)

        # 2. SCENE SPLIT
        if resume and self.checkpoint.exists(StageName.SCENE_SPLIT.value):
            data = self.checkpoint.load(StageName.SCENE_SPLIT.value)
            results[StageName.SCENE_SPLIT.value] = SceneSplitResult.from_dict(data)
            logger.info("[Pipeline] Resumed SCENE_SPLIT")
        else:
            sr = self._run_stage(
                StageName.SCENE_SPLIT,
                results[StageName.SCRIPT.value],
                progress=progress, progress_label="Tách cảnh",
                **kwargs,
            )
            self.checkpoint.save(StageName.SCENE_SPLIT.value, sr.output.to_dict())
            results[StageName.SCENE_SPLIT.value] = sr.output
        if self.cancel_event.is_set() or _reached(StageName.SCENE_SPLIT):
            return self._finish(results)

        # 3. PROMPT GEN
        if resume and self.checkpoint.exists(StageName.PROMPT_GEN.value):
            data = self.checkpoint.load(StageName.PROMPT_GEN.value)
            results[StageName.PROMPT_GEN.value] = PromptGenResult.from_dict(data)
            logger.info("[Pipeline] Resumed PROMPT_GEN")
        else:
            sr = self._run_stage(
                StageName.PROMPT_GEN,
                results[StageName.SCENE_SPLIT.value],
                progress=progress, progress_label="Tạo prompt",
                **kwargs,
            )
            self.checkpoint.save(StageName.PROMPT_GEN.value, sr.output.to_dict())
            results[StageName.PROMPT_GEN.value] = sr.output
        if self.cancel_event.is_set() or _reached(StageName.PROMPT_GEN):
            return self._finish(results)

        # 4. IMAGE GEN (always re-enters to allow partial resume inside stage)
        existing_images = None
        if resume and self.checkpoint.exists(StageName.IMAGE_GEN.value):
            data = self.checkpoint.load(StageName.IMAGE_GEN.value)
            existing_images = ImageGenResult.from_dict(data)
            logger.info("[Pipeline] Resumed IMAGE_GEN (partial)")
        sr = self._run_stage(
            StageName.IMAGE_GEN,
            results[StageName.PROMPT_GEN.value],
            progress=progress, progress_label="Generating images",
            existing=existing_images,
            **kwargs,
        )
        self.checkpoint.save(StageName.IMAGE_GEN.value, sr.output.to_dict())
        results[StageName.IMAGE_GEN.value] = sr.output
        if self.cancel_event.is_set() or _reached(StageName.IMAGE_GEN):
            return self._finish(results)

        # 5. VOICE
        existing_voice = None
        if resume and self.checkpoint.exists(StageName.VOICE.value):
            data = self.checkpoint.load(StageName.VOICE.value)
            existing_voice = VoiceResult.from_dict(data)
            logger.info("[Pipeline] Resumed VOICE (partial)")
        sr = self._run_stage(
            StageName.VOICE,
            results[StageName.SCENE_SPLIT.value],
            progress=progress, progress_label="Tạo giọng nói",
            existing=existing_voice,
            **kwargs,
        )
        self.checkpoint.save(StageName.VOICE.value, sr.output.to_dict())
        results[StageName.VOICE.value] = sr.output
        if self.cancel_event.is_set():
            return self._finish(results)

        # 6. SUBTITLE
        existing_sub = None
        if resume and self.checkpoint.exists(StageName.SUBTITLE.value):
            data = self.checkpoint.load(StageName.SUBTITLE.value)
            existing_sub = SubtitleResult.from_dict(data)
            logger.info("[Pipeline] Resumed SUBTITLE (partial)")
        sr = self._run_stage(
            StageName.SUBTITLE,
            results[StageName.VOICE.value],
            progress=progress, progress_label="Tạo phụ đề",
            existing=existing_sub,
            language=language,
            **kwargs,
        )
        self.checkpoint.save(StageName.SUBTITLE.value, sr.output.to_dict())
        results[StageName.SUBTITLE.value] = sr.output
        if self.cancel_event.is_set():
            return self._finish(results)

        # 7. RENDER
        if resume and self.checkpoint.exists(StageName.RENDER.value):
            data = self.checkpoint.load(StageName.RENDER.value)
            results[StageName.RENDER.value] = RenderResult.from_dict(data)
            logger.info("[Pipeline] Resumed RENDER")
        else:
            stage = self.stages[StageName.RENDER]
            stage.cancel_event = self.cancel_event
            if progress:
                progress(StageName.RENDER.value, 0.0, "Bắt đầu render video")

            def _rp(p: float, m: str) -> None:
                if progress:
                    progress(StageName.RENDER.value, p, m)

            from app.pipelines.stage_executor import StageExecutor
            executor = StageExecutor(stage)
            sr = executor.execute(
                use_kwargs_only=True,
                progress=_rp,
                images=results[StageName.IMAGE_GEN.value],
                voices=results[StageName.VOICE.value],
                subtitles=results[StageName.SUBTITLE.value],
                width=kwargs.get("width", 720),
                height=kwargs.get("height", 1280),
                output_name="final.mp4",
                **{k: v for k, v in kwargs.items() if k not in ("width", "height")},
            )
            if not sr.success:
                from app.core.events import event_bus
                event_bus.publish(
                    "pipeline.stage_failed",
                    {
                        "stage": StageName.RENDER.value,
                        "error": sr.error_message,
                        "traceback": (sr.metadata or {}).get("traceback", ""),
                    },
                )
                raise PipelineError(
                    f"Stage '{StageName.RENDER.value}' failed: {sr.error_message}"
                )
            self.checkpoint.save(StageName.RENDER.value, sr.output.to_dict())
            results[StageName.RENDER.value] = sr.output

        return self._finish(results)
