"""StageExecutor – wraps any BaseStage.run() into a StageResult with timing + logging.

Keeps stage implementations focused on domain logic; the executor owns the
uniform success/failure contract the orchestrator depends on.
"""
from __future__ import annotations

import logging
import time
import traceback
from typing import Any, Optional

from app.core.exceptions import PipelineError
from app.models.stage_result import StageResult
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class StageExecutor:
    def __init__(self, stage: BaseStage) -> None:
        self.stage = stage

    def execute(
        self,
        input_data: Any = None,
        *,
        progress: Optional[ProgressCallback] = None,
        use_kwargs_only: bool = False,
        **kwargs: Any,
    ) -> StageResult:
        name = getattr(self.stage, "name", self.stage.__class__.__name__)
        logger.info("[Stage] START %s", name)
        t0 = time.perf_counter()
        try:
            if self.stage.is_cancelled():
                raise PipelineError(f"Stage '{name}' cancelled before start")
            if use_kwargs_only:
                output = self.stage.run(progress=progress, **kwargs)
            else:
                output = self.stage.run(input_data, progress=progress, **kwargs)
            elapsed = time.perf_counter() - t0
            result = StageResult.ok(
                output,
                stage_name=name,
                elapsed_time=elapsed,
                metadata={"cancelled": self.stage.is_cancelled()},
            )
            logger.info("[Stage] END %s OK (%.2fs)", name, elapsed)
            return result
        except Exception as e:
            elapsed = time.perf_counter() - t0
            tb = traceback.format_exc()
            logger.error(
                "[Stage] END %s FAILED (%.2fs)\n%s: %s\n%s",
                name, elapsed, type(e).__name__, e, tb,
            )
            return StageResult.fail(
                e,
                stage_name=name,
                elapsed_time=elapsed,
                metadata={"traceback": tb[-2000:]},
            )
