"""Controller layer between the UI and the pipeline/service layer.

Flow enforced here (see MISSION doc):

    UI -> dispatch event -> Controller -> Service/Pipeline -> Worker Thread
       -> EventBus -> UI Update

UI pages never call `pipeline.run(...)` or `task_queue.submit(...)`
directly. They call one of the `request_*` methods below. Each one:

  1. Validates required inputs / project state (app.core.validation).
  2. Confirms the PipelineStateMachine currently allows the action.
  3. Publishes a `*Requested` event on the EventBus (for logging/audit -
     see "Logging" section of the MISSION doc).
  4. Transitions the state machine into a "*_GENERATING" busy state.
  5. Submits the actual work to the TaskQueue, which runs it on a
     background worker thread. Progress and completion are reported
     back exclusively through the EventBus / progress callback, never
     via direct widget access from the worker thread.

If validation or the state check fails, a ValidationError /
InvalidStateTransitionError is raised synchronously (on the UI thread,
before anything is queued) so the caller can show a dialog. No pipeline
work is ever started in that case.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from app.core.duration import DEFAULT_SCENE_DURATION_SECONDS, calculate_scene_count
from app.core.events import event_bus
from app.core.exceptions import ValidationError
from app.core.validation import (
    validate_images_request,
    validate_script_request,
    validate_video_request,
)
from app.models.pipeline import StageName
from app.models.pipeline_state import PipelineState, PipelineStateMachine

logger = logging.getLogger(__name__)


class PipelineController:
    def __init__(self, app: Any) -> None:
        # `app` is the MainApp instance. It gives us the current project,
        # the current pipeline object, the task queue, and app-level config
        # -- i.e. everything that was previously being poked at directly
        # from UI pages. Centralizing that access here is what makes the
        # pages themselves "dumb": they only ever call request_* methods.
        self.app = app
        self.state: PipelineStateMachine = app.state_machine

    # ------------------------------------------------------------------
    # Script
    # ------------------------------------------------------------------
    def request_generate_script(
        self,
        topic: str,
        language: str,
        duration: float,
        style: str = "",
        aspect_ratio: str = "9:16",
    ) -> str:
        validate_script_request(topic, language, duration)
        self.state.require("generate_script")

        project = self.app.current_project
        event_bus.publish("GenerateScriptRequested", {
            "topic": topic, "language": language, "duration": duration,
            "style": style, "aspect_ratio": aspect_ratio,
        })
        logger.info("Generate Script requested (topic=%r, duration=%s)", topic, duration)

        self.app.current_topic = topic
        self.app.current_language = language
        self.app.current_duration = duration
        self.app.current_style = style
        self.app.current_aspect_ratio = aspect_ratio
        self.state.transition(PipelineState.SCRIPT_GENERATING)

        # Scene count is driven entirely by the requested duration - no
        # hardcoded ceiling. See app.core.duration.calculate_scene_count
        # for the formula (ceil(duration / scene_duration_seconds)).
        max_scenes = calculate_scene_count(duration, self._scene_duration_seconds())
        # Remembered so request_generate_images / request_generate_video
        # (which don't re-run the script stage) can still pass the same
        # value through to every later stage - no stage silently drops it.
        self.app.current_max_scenes = max_scenes

        def _job(**_worker_kwargs: Any) -> dict:
            return self.app.pipeline.run(
                topic=topic,
                language=language,
                resume=True,
                progress=self.app._pipeline_progress,
                until_stage=StageName.SCRIPT,
                max_scenes=max_scenes,
                target_duration_seconds=duration,
                width=self._img_width(), height=self._img_height(), steps=self._steps(),
            )

        return self._submit("pipeline_script", _job, on_done=self._on_script_done)

    def _scene_duration_seconds(self) -> float:
        return getattr(self.app.ctx.config, "scene_duration_seconds", DEFAULT_SCENE_DURATION_SECONDS) if self.app.ctx else DEFAULT_SCENE_DURATION_SECONDS

    def _on_script_done(self, success: bool, results: Optional[dict], error: Optional[str]) -> None:
        if success and results is not None:
            script_result = results.get(StageName.SCRIPT.value)
            full_script = getattr(script_result, "full_script", "") if script_result else ""
            if self.app.current_project is not None:
                self.app.current_project.script = full_script
            self.state.transition(PipelineState.SCRIPT_READY)
            event_bus.publish("ScriptGenerated", {"length": len(full_script)})
            logger.info("Script generated (%d chars)", len(full_script))
        else:
            self.state.transition(PipelineState.WAITING_FOR_INPUT)
            event_bus.publish("ScriptGenerationFailed", {"error": error})
            logger.error("Script generation failed: %s", error)

    def approve_script(self, edited_script: str) -> None:
        """User clicked 'Approve' after reviewing/editing the script.
        No AI work happens here - this only unlocks image generation."""
        self.state.require("approve_script")
        if self.app.current_project is not None:
            self.app.current_project.script = edited_script
        self.state.transition(PipelineState.SCRIPT_APPROVED)
        event_bus.publish("ScriptApproved", {"length": len(edited_script)})
        logger.info("Script approved by user (%d chars)", len(edited_script))

    # ------------------------------------------------------------------
    # Images
    # ------------------------------------------------------------------
    def request_generate_images(self) -> str:
        project = self.app.current_project
        validate_images_request(project)
        self.state.require("generate_images")

        event_bus.publish("GenerateImagesRequested", {})
        logger.info("Generate Images requested")
        self.state.transition(PipelineState.IMAGE_GENERATING)

        def _job(**_worker_kwargs: Any) -> dict:
            return self.app.pipeline.run(
                topic=self.app.current_topic,
                language=self.app.current_language,
                resume=True,
                progress=self.app._pipeline_progress,
                until_stage=StageName.IMAGE_GEN,
                max_scenes=getattr(self.app, "current_max_scenes", None),
                target_duration_seconds=getattr(self.app, "current_duration", None),
                width=self._img_width(), height=self._img_height(), steps=self._steps(),
            )

        return self._submit("pipeline_images", _job, on_done=self._on_images_done)

    def _on_images_done(self, success: bool, results: Optional[dict], error: Optional[str]) -> None:
        if success and results is not None:
            image_result = results.get(StageName.IMAGE_GEN.value)
            count = len(getattr(image_result, "images", []) or [])
            self.state.transition(PipelineState.IMAGE_READY)
            event_bus.publish("ImagesGenerated", {"count": count})
            logger.info("Images generated: %d", count)
        else:
            self.state.transition(PipelineState.SCRIPT_APPROVED)
            event_bus.publish("ImageGenerationFailed", {"error": error})
            logger.error("Image generation failed: %s", error)

    # ------------------------------------------------------------------
    # Video
    # ------------------------------------------------------------------
    def request_generate_video(self) -> str:
        images_ready = self.state.state in (PipelineState.IMAGE_READY, PipelineState.VIDEO_READY)
        validate_video_request(self.app.current_project, images_ready)
        self.state.require("generate_video")

        event_bus.publish("GenerateVideoRequested", {})
        logger.info("Generate Video requested")
        self.state.transition(PipelineState.VIDEO_GENERATING)

        def _job(**_worker_kwargs: Any) -> dict:
            return self.app.pipeline.run(
                topic=self.app.current_topic,
                language=self.app.current_language,
                resume=True,
                progress=self.app._pipeline_progress,
                until_stage=None,  # run through RENDER, the final stage
                max_scenes=getattr(self.app, "current_max_scenes", None),
                target_duration_seconds=getattr(self.app, "current_duration", None),
                width=self._img_width(), height=self._img_height(), steps=self._steps(),
            )

        return self._submit("pipeline_video", _job, on_done=self._on_video_done)

    def _on_video_done(self, success: bool, results: Optional[dict], error: Optional[str]) -> None:
        if success and results is not None:
            render_result = results.get(StageName.RENDER.value)
            path = getattr(render_result, "video_path", None) if render_result else None
            self.state.transition(PipelineState.VIDEO_READY)
            event_bus.publish("VideoGenerated", {"path": path})
            logger.info("Video generated: %s", path)
        else:
            self.state.transition(PipelineState.IMAGE_READY)
            event_bus.publish("VideoGenerationFailed", {"error": error})
            logger.error("Video generation failed: %s", error)

    # ------------------------------------------------------------------
    # Shared plumbing
    # ------------------------------------------------------------------
    def cancel(self) -> None:
        self.app.cancel_pipeline()

    def _submit(self, name: str, job, on_done) -> str:
        def _wrapped() -> dict:
            try:
                result = job()
                # Capture result by default-arg so the lambda does not
                # close over a free variable that may be rebound later.
                self.app.after(0, lambda r=result: on_done(True, r, None))
                return result
            except Exception as e:  # noqa: BLE001 - reported through EventBus, not raised on worker
                logger.exception("%s failed", name)
                # CRITICAL: bind str(e) into a local *before* the lambda.
                # Closing over `e` directly causes NameError
                # ("cannot access free variable 'e'") because the except
                # block tears the exception binding down when it exits.
                err = str(e)
                self.app.after(0, lambda err=err: on_done(False, None, err))
                # Do NOT re-raise: the TaskQueue already publishes
                # task.failed. Re-raising only adds noise and can race
                # with the after() callback that resets pipeline state.
                return {}

        task_id = self.app.task_queue.submit(name, _wrapped, priority=5)
        self.app.current_task_id = task_id
        return task_id

    # Base aspect resolutions. SDXLTurboBackend further clamps these
    # at generate-time when VRAM < 6GB (→ max edge 512) or < 8GB
    # (→ max edge 640), so 4GB cards never attempt a full 720x1280
    # forward pass.
    # Base aspect resolutions. SDXLTurboBackend further clamps these at
    # generate-time based on detected VRAM (≤4GB → max edge 512 for SD1.5,
    # ≤6GB → max edge 512 for SDXL). Starting lower on the common 9:16 path
    # reduces OOM recovery churn on GTX 1650 class cards.
    _ASPECT_RESOLUTIONS = {
        "9:16": (512, 768),
        "16:9": (768, 512),
        "1:1": (512, 512),
    }

    def _resolution(self) -> tuple[int, int]:
        aspect_ratio = getattr(self.app, "current_aspect_ratio", None)
        if aspect_ratio in self._ASPECT_RESOLUTIONS:
            return self._ASPECT_RESOLUTIONS[aspect_ratio]
        return getattr(self.app.ctx.config, "resolution", (720, 1280)) if self.app.ctx else (512, 768)

    def _img_width(self) -> int:
        return self._resolution()[0]

    def _img_height(self) -> int:
        return self._resolution()[1]

    def _steps(self) -> int:
        return getattr(self.app.ctx.config, "steps", 4) if self.app.ctx else 4
