"""Deterministic, fully-offline script fallback.

Used whenever no LLM is available (or the LLM call failed) to produce a
script. Previously this logic was duplicated in two places
(`LightweightLLMService._fallback_script` and
`ScriptStage._fallback_script`), and BOTH copies hardcoded a fixed
6-line script - so no matter how many scenes the requested duration
needed, the fallback path silently capped things at 6. This module is
now the single implementation both call into, and it always returns
exactly `max_scenes` lines by cycling through a small template bank
(never fewer, regardless of how large `max_scenes` is).
"""
from __future__ import annotations

_VI_TEMPLATE = [
    "Hôm nay chúng ta cùng khám phá chủ đề: {topic}.",
    "Đây là một chủ đề rất đáng để tìm hiểu sâu hơn.",
    "Hãy bắt đầu với những điểm quan trọng nhất.",
    "Mỗi khía cạnh sẽ mang đến góc nhìn thú vị.",
    "Có rất nhiều điều thú vị đang chờ được khám phá.",
    "Hãy cùng xem xét kỹ hơn về vấn đề này.",
    "Điều này ảnh hưởng đến chúng ta theo nhiều cách khác nhau.",
    "Chúng ta sẽ tiếp tục tìm hiểu thêm những chi tiết khác.",
    "Cuối cùng chúng ta rút ra bài học thực tế.",
    "Cảm ơn bạn đã theo dõi đến cuối video.",
]

_EN_TEMPLATE = [
    "Today we explore the topic: {topic}.",
    "This is a subject worth understanding more deeply.",
    "Let's start with the most important points.",
    "Each aspect offers a fresh perspective.",
    "There is a lot more worth discovering here.",
    "Let's take a closer look at this topic.",
    "This affects us in a number of different ways.",
    "We'll keep exploring a few more details.",
    "Finally we extract practical takeaways.",
    "Thank you for watching until the end.",
]


def build_fallback_script(topic: str, language: str, max_scenes: int) -> str:
    """Return a script with exactly `max_scenes` lines (minimum 1).

    Cycles through the template bank rather than stopping once it runs
    out, so a long requested duration still gets enough scenes even
    when no LLM is available. Repeats past the first cycle get a small
    suffix so downstream scene-splitting never sees byte-identical
    duplicate lines.
    """
    template = _VI_TEMPLATE if str(language).lower().startswith("vi") else _EN_TEMPLATE
    max_scenes = max(1, int(max_scenes or 1))

    lines: list[str] = []
    for i in range(max_scenes):
        line = template[i % len(template)].format(topic=topic)
        cycle = i // len(template)
        if cycle > 0:
            # Strip trailing sentence punctuation before adding the cycle
            # marker and re-terminating - appending "(2)" *after* an
            # existing "." would leave "...test. (2)" which downstream
            # sentence-splitting (scene_split_stage) reads as a period
            # followed by whitespace, i.e. an extra, spurious sentence
            # boundary. Keeping exactly one trailing terminator avoids
            # inflating the scene count by one per repeat.
            line = f"{line.rstrip('.!?…')} ({cycle + 1})."
        lines.append(line)
    return "\n".join(lines)
