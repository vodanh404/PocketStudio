"""Exponential-backoff retry helper for Image / Voice / LLM / HTTP calls."""
from __future__ import annotations

import logging
import time
from typing import Callable, Optional, Tuple, Type, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")

DEFAULT_ATTEMPTS = 3
DEFAULT_BASE_DELAY = 1.0  # seconds → 1s, 2s, 4s


def retry_call(
    func: Callable[[], T],
    *,
    attempts: int = DEFAULT_ATTEMPTS,
    base_delay: float = DEFAULT_BASE_DELAY,
    exceptions: Tuple[Type[BaseException], ...] = (Exception,),
    label: str = "operation",
    on_retry: Optional[Callable[[int, BaseException], None]] = None,
) -> T:
    """Call ``func`` up to ``attempts`` times with exponential backoff.

    Raises the last exception if every attempt fails.
    Does **not** catch ``KeyboardInterrupt`` / ``SystemExit``.
    """
    last: Optional[BaseException] = None
    for attempt in range(1, max(1, attempts) + 1):
        try:
            return func()
        except exceptions as e:
            last = e
            if attempt >= attempts:
                logger.error(
                    "[Retry] %s failed after %d attempt(s): %s",
                    label, attempts, e,
                )
                raise
            delay = base_delay * (2 ** (attempt - 1))
            logger.warning(
                "[Retry] %s attempt %d/%d failed (%s) – retry in %.1fs",
                label, attempt, attempts, e, delay,
            )
            if on_retry is not None:
                try:
                    on_retry(attempt, e)
                except Exception:
                    logger.exception("[Retry] on_retry callback failed")
            time.sleep(delay)
    # Unreachable, but keeps type-checkers happy.
    assert last is not None
    raise last
