"""Filesystem existence / non-empty checks used by every stage."""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Iterable, List, Sequence, Union

logger = logging.getLogger(__name__)

PathLike = Union[str, Path]


def require_exists(path: PathLike, *, label: str = "file") -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"{label} không tồn tại: {p}")
    return p


def require_non_empty(path: PathLike, *, label: str = "file", min_bytes: int = 1) -> Path:
    p = require_exists(path, label=label)
    size = p.stat().st_size
    if size < min_bytes:
        raise ValueError(f"{label} rỗng hoặc quá nhỏ ({size} bytes): {p}")
    return p


def require_all_exist(paths: Sequence[PathLike], *, label: str = "input") -> List[Path]:
    missing: List[str] = []
    resolved: List[Path] = []
    for raw in paths:
        p = Path(raw)
        if not p.exists():
            missing.append(str(p))
        else:
            resolved.append(p)
    if missing:
        raise FileNotFoundError(
            f"{label}: thiếu {len(missing)} file:\n  - " + "\n  - ".join(missing[:20])
        )
    return resolved


def ensure_dir(path: PathLike) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
