"""Device-consistency guard for diffusers pipelines.

Call `validate_pipeline_devices(pipe, expect_cpu_offload)` immediately
before every `pipe(...)` inference call. This is a defense-in-depth
check, not the primary fix -- the primary fix is that `ModelPool` (see
app/services/model_pool.py) now makes it structurally impossible for a
model to be unloaded while it is BUSY. This module instead guards
against the *other* class of "cpu and cuda:0" bug: a coding mistake
that leaves the pipeline itself in a half-moved state (e.g. calling
`pipe.to(cuda)` after `enable_model_cpu_offload()`, or manually moving
one submodule and not another).

Two distinct checks are needed depending on load mode:

- `enable_model_cpu_offload()` pipelines intentionally keep most
  submodules on CPU between calls; accelerate's forward hooks move each
  submodule to GPU just-in-time and back. Checking "all components on
  the same device" would be a false positive here by design -- instead
  we confirm the offload hooks are actually attached.
- A plain pipeline (no offload) must have every core component on
  exactly the same `torch.device`. If it doesn't, something moved part
  of it without moving the rest, and we refuse to run rather than
  crash mid-forward-pass inside `UNet.time_embedding`.
"""
from __future__ import annotations

from typing import Any

_CORE_COMPONENTS = ("unet", "vae", "text_encoder", "text_encoder_2", "controlnet")


def validate_pipeline_devices(pipe: Any, expect_cpu_offload: bool) -> None:
    if expect_cpu_offload:
        _validate_offload_hooks(pipe)
        return
    _validate_uniform_device(pipe)


def _validate_uniform_device(pipe: Any) -> None:
    devices: dict[str, str] = {}
    for name in _CORE_COMPONENTS:
        component = getattr(pipe, name, None)
        if component is None or not hasattr(component, "parameters"):
            continue
        try:
            device = next(component.parameters()).device
        except StopIteration:
            continue
        devices[name] = str(device)

    if not devices:
        return
    distinct = set(devices.values())
    if len(distinct) > 1:
        detail = ", ".join(f"{n}={d}" for n, d in devices.items())
        raise RuntimeError(
            "Device mismatch detected before generate(): pipeline components "
            f"are on different devices ({detail}). Part of the pipeline was "
            "moved (e.g. `.to('cpu')`) while another part stayed on GPU. "
            "Refusing to run inference to avoid a mid-forward crash."
        )


def _validate_offload_hooks(pipe: Any) -> None:
    unet = getattr(pipe, "unet", None)
    if unet is None:
        return
    has_hook = hasattr(unet, "_hf_hook") or hasattr(unet, "_diffusers_hook")
    if not has_hook:
        raise RuntimeError(
            "Pipeline was loaded with cpu_offload enabled but its accelerate "
            "offload hooks are missing. This means the pipeline was manually "
            "moved with `.to(device)` after `enable_model_cpu_offload()` was "
            "called (see audit check #1), or the offload hooks were torn "
            "down mid-flight. Refusing to run inference on a pipeline in an "
            "inconsistent state."
        )
