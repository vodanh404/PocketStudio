"""Memory & VRAM monitor + automatic cleanup.

VRAM reading priority:
  1. NVML (pynvml) – process-agnostic, matches nvidia-smi
  2. torch.cuda.mem_get_info / memory_stats – always available when CUDA works
  3. zeros (CPU-only box)

Previously only NVML was used; if pynvml failed to init (common on fresh
Windows installs without the NVIDIA management library bound correctly)
the UI permanently showed VRAM 0% while torch still allocated 4GB and
OOM'd – exactly the symptom reported.
"""
from __future__ import annotations

import gc
import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional

import psutil

logger = logging.getLogger(__name__)

_NVML_AVAILABLE = False
try:
    import pynvml
    pynvml.nvmlInit()
    _NVML_AVAILABLE = True
    logger.info("NVML initialised – VRAM stats will use nvidia driver")
except Exception as e:
    logger.info("NVML unavailable (%s) – VRAM stats will fall back to torch.cuda", e)


@dataclass
class MemorySnapshot:
    ram_used_percent: float
    ram_used_gb: float
    ram_total_gb: float
    vram_used_percent: float
    vram_used_gb: float
    vram_total_gb: float
    timestamp: float
    # Extra fields for richer status bar / logging (optional consumers).
    gpu_util_percent: float = 0.0
    cpu_percent: float = 0.0
    torch_allocated_gb: float = 0.0
    torch_reserved_gb: float = 0.0


def _read_vram_nvml() -> tuple[float, float, float, float]:
    """Return (used_gb, total_gb, percent, gpu_util_percent) via NVML."""
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    info = pynvml.nvmlDeviceGetMemoryInfo(handle)
    used = info.used / (1024 ** 3)
    total = info.total / (1024 ** 3)
    percent = (info.used / info.total) * 100.0 if info.total else 0.0
    util = 0.0
    try:
        rates = pynvml.nvmlDeviceGetUtilizationRates(handle)
        util = float(rates.gpu)
    except Exception:
        pass
    return used, total, percent, util


def _read_vram_torch() -> tuple[float, float, float, float, float]:
    """Return (used_gb, total_gb, percent, allocated_gb, reserved_gb) via torch.cuda."""
    import torch
    if not torch.cuda.is_available():
        return 0.0, 0.0, 0.0, 0.0, 0.0
    free_b, total_b = torch.cuda.mem_get_info(0)
    total = total_b / (1024 ** 3)
    used = (total_b - free_b) / (1024 ** 3)
    percent = (used / total) * 100.0 if total else 0.0
    allocated = torch.cuda.memory_allocated(0) / (1024 ** 3)
    reserved = torch.cuda.memory_reserved(0) / (1024 ** 3)
    return used, total, percent, allocated, reserved


class MemoryManager:
    def __init__(
        self,
        ram_warning: float = 70.0,
        ram_critical: float = 85.0,
        vram_warning: float = 75.0,
        check_interval: float = 5.0,
    ) -> None:
        self.ram_warning = ram_warning
        self.ram_critical = ram_critical
        self.vram_warning = vram_warning
        self.check_interval = check_interval
        self._unload_callbacks: list[Callable[[], None]] = []
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()

    def register_unload_callback(self, callback: Callable[[], None]) -> None:
        with self._lock:
            self._unload_callbacks.append(callback)

    def get_snapshot(self) -> MemorySnapshot:
        mem = psutil.virtual_memory()
        ram_used_gb = mem.used / (1024 ** 3)
        ram_total_gb = mem.total / (1024 ** 3)
        try:
            cpu_percent = float(psutil.cpu_percent(interval=None))
        except Exception:
            cpu_percent = 0.0

        vram_used = 0.0
        vram_total = 0.0
        vram_percent = 0.0
        gpu_util = 0.0
        torch_allocated = 0.0
        torch_reserved = 0.0

        nvml_ok = False
        if _NVML_AVAILABLE:
            try:
                vram_used, vram_total, vram_percent, gpu_util = _read_vram_nvml()
                nvml_ok = True
            except Exception as e:
                logger.debug("NVML read failed: %s", e)

        # Always try torch for allocated/reserved detail; also as primary
        # source when NVML is missing so the UI never shows permanent 0%.
        try:
            t_used, t_total, t_percent, torch_allocated, torch_reserved = _read_vram_torch()
            if not nvml_ok:
                vram_used, vram_total, vram_percent = t_used, t_total, t_percent
        except Exception as e:
            logger.debug("torch.cuda VRAM read failed: %s", e)

        return MemorySnapshot(
            ram_used_percent=mem.percent,
            ram_used_gb=ram_used_gb,
            ram_total_gb=ram_total_gb,
            vram_used_percent=vram_percent,
            vram_used_gb=vram_used,
            vram_total_gb=vram_total,
            timestamp=time.time(),
            gpu_util_percent=gpu_util,
            cpu_percent=cpu_percent,
            torch_allocated_gb=torch_allocated,
            torch_reserved_gb=torch_reserved,
        )

    def force_cleanup(self) -> None:
        logger.info("Force memory cleanup triggered")
        with self._lock:
            for cb in self._unload_callbacks:
                try:
                    cb()
                except Exception as e:
                    logger.exception("Unload callback failed: %s", e)
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
        except Exception:
            pass

    def _monitor_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                snap = self.get_snapshot()
                if snap.ram_used_percent >= self.ram_critical or snap.vram_used_percent >= 90.0:
                    logger.warning(
                        "Critical memory: RAM %.1f%% | VRAM %.1f%% (torch alloc %.2fG / reserved %.2fG) "
                        "| GPU util %.0f%% → force cleanup",
                        snap.ram_used_percent, snap.vram_used_percent,
                        snap.torch_allocated_gb, snap.torch_reserved_gb,
                        snap.gpu_util_percent,
                    )
                    self.force_cleanup()
                elif snap.ram_used_percent >= self.ram_warning or snap.vram_used_percent >= self.vram_warning:
                    logger.info(
                        "Memory warning: RAM %.1f%% | VRAM %.1f%% | GPU %.0f%% | "
                        "torch alloc=%.2fG reserved=%.2fG",
                        snap.ram_used_percent, snap.vram_used_percent,
                        snap.gpu_util_percent,
                        snap.torch_allocated_gb, snap.torch_reserved_gb,
                    )
            except Exception as e:
                logger.exception("Memory monitor error: %s", e)
            self._stop_event.wait(self.check_interval)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._monitor_loop, name="MemoryMonitor", daemon=True
        )
        self._thread.start()
        logger.info("MemoryManager started")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3.0)
