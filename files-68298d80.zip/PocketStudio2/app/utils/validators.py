"""Output / input validators for pipeline stages.

Each validator raises a clear exception on failure so the stage / orchestrator
can wrap it into a StageResult(success=False) and stop the pipeline.
"""
from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import Any, Optional

from app.utils.file_checker import require_exists, require_non_empty

logger = logging.getLogger(__name__)


class ValidationFailed(ValueError):
    """Raised when stage input or output fails validation."""


# ---------------------------------------------------------------------------
# Input validators
# ---------------------------------------------------------------------------

def validate_script_text(script: Optional[str]) -> str:
    if script is None or not str(script).strip():
        raise ValidationFailed("Script rỗng – không thể tiếp tục pipeline.")
    return str(script).strip()


def validate_topic(topic: Optional[str]) -> str:
    if topic is None or not str(topic).strip():
        raise ValidationFailed("Topic/prompt rỗng – không thể gọi LLM.")
    return str(topic).strip()


def validate_duration(duration: Optional[float]) -> float:
    if duration is None or float(duration) <= 0:
        raise ValidationFailed(f"Duration không hợp lệ: {duration!r} (phải > 0).")
    return float(duration)


def validate_scenes(scenes: Any) -> list:
    if scenes is None:
        raise ValidationFailed("Danh sách scene rỗng (None).")
    try:
        items = list(scenes)
    except TypeError as e:
        raise ValidationFailed(f"Scenes không iterable: {e}") from e
    if not items:
        raise ValidationFailed("Danh sách scene rỗng – không thể tạo ảnh/voice.")
    return items


def validate_prompts(prompts: Any) -> list:
    items = validate_scenes(prompts)  # same non-empty list check
    for i, p in enumerate(items):
        text = getattr(p, "prompt", None) or (p if isinstance(p, str) else None)
        if not text or not str(text).strip():
            raise ValidationFailed(f"Prompt cảnh {i} rỗng.")
    return items


def validate_tts_text(text: Optional[str]) -> str:
    cleaned = (text or "").strip()
    if not cleaned:
        raise ValidationFailed("Text TTS rỗng – Edge-TTS sẽ trả 'No audio was received'.")
    # Edge-TTS rejects extremely long single requests; keep a hard ceiling.
    if len(cleaned) > 5000:
        logger.warning("[TTS] Text dài %d chars – cắt còn 5000", len(cleaned))
        cleaned = cleaned[:5000]
    return cleaned


def validate_voice_name(voice: Optional[str]) -> str:
    if not voice or not str(voice).strip():
        raise ValidationFailed("Voice name rỗng.")
    return str(voice).strip()


# ---------------------------------------------------------------------------
# Output validators
# ---------------------------------------------------------------------------

class ImageValidator:
    @staticmethod
    def validate(path: Path, *, min_bytes: int = 64) -> Path:
        p = require_non_empty(path, label="image", min_bytes=min_bytes)
        try:
            from PIL import Image
            with Image.open(p) as im:
                im.verify()
            # verify() closes the file; reopen for load check
            with Image.open(p) as im:
                im.load()
                w, h = im.size
            if w < 8 or h < 8:
                raise ValidationFailed(f"Ảnh quá nhỏ ({w}x{h}): {p}")
        except ValidationFailed:
            raise
        except Exception as e:
            raise ValidationFailed(f"Ảnh corrupt / PIL không mở được: {p} ({e})") from e
        logger.debug("[ImageValidator] OK %s (%dx%d)", p.name, w, h)
        return p


class AudioValidator:
    @staticmethod
    def validate(path: Path, *, min_bytes: int = 100) -> float:
        """Return duration in seconds. Raises ValidationFailed on bad audio."""
        p = require_non_empty(path, label="audio", min_bytes=min_bytes)
        duration = AudioValidator.probe_duration(p)
        if duration <= 0:
            raise ValidationFailed(f"Audio duration <= 0 (ffprobe): {p}")
        logger.debug("[AudioValidator] OK %s (%.2fs)", p.name, duration)
        return duration

    @staticmethod
    def probe_duration(path: Path) -> float:
        try:
            r = subprocess.run(
                [
                    "ffprobe", "-v", "error",
                    "-show_entries", "format=duration",
                    "-of", "default=noprint_wrappers=1:nokey=1",
                    str(path),
                ],
                capture_output=True, text=True, check=True, timeout=30,
            )
            return float(r.stdout.strip())
        except FileNotFoundError as e:
            raise ValidationFailed(
                "ffprobe không tìm thấy trong PATH – cài FFmpeg trước."
            ) from e
        except subprocess.CalledProcessError as e:
            raise ValidationFailed(
                f"ffprobe không đọc được audio: {path}\n{(e.stderr or '')[-500:]}"
            ) from e
        except Exception as e:
            raise ValidationFailed(f"Không probe được audio {path}: {e}") from e


class SubtitleValidator:
    _TIME_RE = re.compile(
        r"(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)"
    )

    @staticmethod
    def validate(path: Path, *, min_bytes: int = 10) -> int:
        """Return number of cues. Raises on unparseable SRT."""
        p = require_non_empty(path, label="subtitle", min_bytes=min_bytes)
        content = p.read_text(encoding="utf-8", errors="replace")
        if not content.strip():
            raise ValidationFailed(f"Subtitle rỗng: {p}")
        cues = 0
        for block in re.split(r"\n\s*\n", content.strip()):
            parts = block.strip().split("\n")
            if len(parts) < 2:
                continue
            # parts[0] may be index; timing is the line that matches TIME_RE
            timing_line = parts[1] if SubtitleValidator._TIME_RE.search(parts[1]) else parts[0]
            if SubtitleValidator._TIME_RE.search(timing_line):
                cues += 1
        if cues == 0:
            raise ValidationFailed(f"Subtitle không parse được cue nào: {p}")
        logger.debug("[SubtitleValidator] OK %s (%d cues)", p.name, cues)
        return cues


class VideoValidator:
    @staticmethod
    def validate(path: Path, *, min_bytes: int = 1024) -> float:
        """Return duration in seconds."""
        p = require_non_empty(path, label="video", min_bytes=min_bytes)
        try:
            r = subprocess.run(
                [
                    "ffprobe", "-v", "error",
                    "-show_entries", "format=duration",
                    "-of", "default=noprint_wrappers=1:nokey=1",
                    str(path),
                ],
                capture_output=True, text=True, check=True, timeout=60,
            )
            duration = float(r.stdout.strip())
        except FileNotFoundError as e:
            raise ValidationFailed("ffprobe không tìm thấy trong PATH.") from e
        except Exception as e:
            raise ValidationFailed(f"Video corrupt / ffprobe fail: {path} ({e})") from e
        if duration <= 0:
            raise ValidationFailed(f"Video duration <= 0: {p}")
        logger.debug("[VideoValidator] OK %s (%.2fs)", p.name, duration)
        return duration


class DependencyChecker:
    """One-shot checks for external binaries the pipeline needs."""

    @staticmethod
    def require_ffmpeg() -> None:
        for binary in ("ffmpeg", "ffprobe"):
            try:
                subprocess.run(
                    [binary, "-version"],
                    capture_output=True, text=True, check=True, timeout=10,
                )
            except FileNotFoundError as e:
                raise ValidationFailed(
                    f"'{binary}' không có trong PATH. Cài FFmpeg rồi thử lại."
                ) from e
            except Exception as e:
                raise ValidationFailed(f"Không chạy được {binary}: {e}") from e

    @staticmethod
    def check_network_for_tts(timeout: float = 5.0) -> bool:
        """Best-effort connectivity probe for Edge-TTS (Microsoft endpoint)."""
        try:
            import urllib.request
            urllib.request.urlopen(
                "https://www.bing.com", timeout=timeout,
            )
            return True
        except Exception as e:
            logger.warning("[DependencyChecker] Network probe failed: %s", e)
            return False
