"""Service layer.

Imports are intentionally NOT eager. Import concrete classes from their
modules (e.g. `from app.services.model_pool import ModelPool`) to avoid
circular / partial package loads during application bootstrap.
"""
from __future__ import annotations

__all__ = [
    "ModelPool",
    "SDXLTurboBackend",
    "LightweightLLMService",
]


def __getattr__(name: str):
    if name == "ModelPool":
        from app.services.model_pool import ModelPool
        return ModelPool
    if name == "SDXLTurboBackend":
        from app.services.image_generator import SDXLTurboBackend
        return SDXLTurboBackend
    if name == "LightweightLLMService":
        from app.services.llm_service import LightweightLLMService
        return LightweightLLMService
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
