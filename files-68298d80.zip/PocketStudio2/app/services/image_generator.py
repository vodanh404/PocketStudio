"""Image Generation Backend – adaptive model selection + OOM recovery for ≤4GB VRAM.

Design goals for weak hardware (GTX 1650 / RTX 2050, 4GB):
  - Never load SDXL on ≤4GB cards (peak UNet activation alone exceeds 4GB at 512x768).
  - Prefer SD 1.5 (fp16) which fits fully on GPU → high util, no PCIe thrashing.
  - On 6GB+ use SDXL Turbo with model_cpu_offload only when necessary.
  - Adaptive resolution ladder on CUDA OOM instead of hard-failing the stage.
  - Strict acquire/release via ModelPool so MemoryManager never unloads mid-forward.
"""
from __future__ import annotations

import gc
import logging
import time
from pathlib import Path
from typing import Any, List, Optional, Tuple

from PIL import Image

from app.utils.hash_cache import HashCache
from app.utils.device_check import validate_pipeline_devices

logger = logging.getLogger(__name__)


def _detect_vram_gb() -> float:
    """Return total VRAM of GPU 0 in GB, or 0.0 if CUDA is unavailable."""
    try:
        import torch
        if not torch.cuda.is_available():
            return 0.0
        props = torch.cuda.get_device_properties(0)
        return props.total_memory / (1024 ** 3)
    except Exception:
        return 0.0


def _free_cuda() -> None:
    """Best-effort CUDA memory release."""
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
    except Exception:
        pass


def _round8(n: int) -> int:
    """VAE requires multiples of 8."""
    return max(64, (n // 8) * 8)


_OOM_LADDER_PORTRAIT: List[Tuple[int, int]] = [
    (512, 768),
    (448, 672),
    (384, 576),
    (320, 512),
    (256, 384),
]

_OOM_LADDER_LANDSCAPE: List[Tuple[int, int]] = [
    (768, 512),
    (672, 448),
    (576, 384),
    (512, 320),
    (384, 256),
]

_OOM_LADDER_SQUARE: List[Tuple[int, int]] = [
    (512, 512),
    (448, 448),
    (384, 384),
    (320, 320),
    (256, 256),
]


def _resolution_ladder(width: int, height: int) -> List[Tuple[int, int]]:
    """Build a descending resolution ladder starting at (or below) the request."""
    portrait = height >= width * 1.1
    landscape = width >= height * 1.1
    if portrait:
        base = _OOM_LADDER_PORTRAIT
    elif landscape:
        base = _OOM_LADDER_LANDSCAPE
    else:
        base = _OOM_LADDER_SQUARE

    area = width * height
    ladder = [(w, h) for w, h in base if w * h <= area]
    req = (_round8(width), _round8(height))
    if not ladder or ladder[0] != req:
        ladder = [req] + ladder
    seen = set()
    out: List[Tuple[int, int]] = []
    for pair in ladder:
        if pair not in seen:
            seen.add(pair)
            out.append(pair)
    return out


_MODEL_CATALOGUE = {
    "sdxl-turbo": {
        "model_id": "stabilityai/sdxl-turbo",
        "kind": "sdxl",
        "min_vram_gb": 5.5,
        "default_steps": 4,
        "guidance_scale": 0.0,
        "variant": "fp16",
    },
    "sd15": {
        "model_id": "runwayml/stable-diffusion-v1-5",
        "kind": "sd15",
        "min_vram_gb": 0.0,
        "default_steps": 20,
        "guidance_scale": 7.0,
        "variant": None,
    },
}


def _select_model_for_vram(vram_gb: float, preferred: Optional[str] = None) -> str:
    """Pick the heaviest model that still fits the detected VRAM budget.

    ≤4.5 GB  → sd15   (full GPU residency, high util, no PCIe thrash)
    ≥5.5 GB  → sdxl-turbo
    """
    if preferred and preferred in _MODEL_CATALOGUE:
        entry = _MODEL_CATALOGUE[preferred]
        if vram_gb <= 0 or vram_gb >= entry["min_vram_gb"]:
            return preferred
        logger.warning(
            "Preferred model %s needs ≥%.1fGB VRAM (have %.1fGB) → auto-fallback",
            preferred, entry["min_vram_gb"], vram_gb,
        )

    if vram_gb <= 0 or vram_gb < 5.5:
        return "sd15"
    return "sdxl-turbo"


def _clamp_resolution_for_model(
    width: int,
    height: int,
    vram_gb: float,
    model_key: str,
) -> Tuple[int, int]:
    """Cap resolution so the chosen model fits with headroom for activations."""
    width, height = _round8(width), _round8(height)
    portrait = height >= width
    square = abs(width - height) < 16

    if model_key == "sd15":
        max_edge = 768 if vram_gb >= 6.0 else 512
    else:
        if vram_gb < 6.0:
            max_edge = 512
        elif vram_gb < 8.0:
            max_edge = 768
        else:
            max_edge = 1024

    if max(width, height) <= max_edge:
        return width, height

    if square:
        return max_edge, max_edge
    if portrait:
        scale = max_edge / height
        return _round8(int(width * scale)), max_edge
    scale = max_edge / width
    return max_edge, _round8(int(height * scale))


class SDXLTurboBackend:
    """Name kept for DI compatibility; actually selects SD1.5 or SDXL Turbo
    automatically based on detected VRAM."""

    def __init__(
        self,
        model_pool: Any,
        cache: Any,
        device: str = "cuda",
        dtype: str = "fp16",
        enable_cpu_offload: bool = True,
        enable_attention_slicing: bool = True,
        enable_vae_slicing: bool = True,
        enable_vae_tiling: bool = True,
        preferred_model: Optional[str] = None,
    ) -> None:
        self.model_pool = model_pool
        self.cache = cache
        self.device = device
        self.dtype = dtype
        self.enable_cpu_offload = enable_cpu_offload
        self.enable_attention_slicing = enable_attention_slicing
        self.enable_vae_slicing = enable_vae_slicing
        self.enable_vae_tiling = enable_vae_tiling
        self._vram_gb = _detect_vram_gb()
        self._model_key = _select_model_for_vram(self._vram_gb, preferred_model)
        self._model_meta = _MODEL_CATALOGUE[self._model_key]
        self.MODEL_NAME = self._model_key
        self.MODEL_ID = self._model_meta["model_id"]

        # On ≤4GB: force SD1.5 fully on GPU (no offload) for max util.
        if self._vram_gb > 0 and self._vram_gb < 5.5:
            self.enable_cpu_offload = False
            self.enable_attention_slicing = True
            self.enable_vae_slicing = True
            self.enable_vae_tiling = True
            logger.info(
                "Low VRAM (%.1fGB) → model=%s | full GPU residency (no cpu_offload) "
                "| attention/vae slicing+tiling ON",
                self._vram_gb, self._model_key,
            )
        elif self._vram_gb > 0 and self._vram_gb < 8.0 and self._model_key.startswith("sdxl"):
            self.enable_cpu_offload = True
            self.enable_attention_slicing = True
            self.enable_vae_slicing = True
            self.enable_vae_tiling = True
            logger.info(
                "Mid VRAM (%.1fGB) → model=%s | cpu_offload + slicing",
                self._vram_gb, self._model_key,
            )
        else:
            logger.info(
                "VRAM %.1fGB → model=%s | cpu_offload=%s",
                self._vram_gb, self._model_key, self.enable_cpu_offload,
            )

        self.model_pool.register(self.MODEL_NAME, self._load_pipeline)

    def _load_pipeline(self) -> Any:
        import torch
        from diffusers import AutoPipelineForText2Image, StableDiffusionPipeline

        _free_cuda()

        torch_dtype = torch.float16 if self.dtype == "fp16" else torch.float32
        kind = self._model_meta["kind"]
        variant = self._model_meta.get("variant")

        load_kwargs: dict[str, Any] = {
            "torch_dtype": torch_dtype,
            "use_safetensors": True,
        }
        if variant:
            load_kwargs["variant"] = variant

        if kind == "sdxl":
            pipe = AutoPipelineForText2Image.from_pretrained(self.MODEL_ID, **load_kwargs)
        else:
            try:
                pipe = StableDiffusionPipeline.from_pretrained(self.MODEL_ID, **load_kwargs)
            except Exception:
                pipe = AutoPipelineForText2Image.from_pretrained(self.MODEL_ID, **load_kwargs)

        self._enable_efficient_attention(pipe)

        if self.enable_attention_slicing:
            try:
                pipe.enable_attention_slicing(slice_size="max")
            except Exception as e:
                logger.debug("attention_slicing failed: %s", e)
        if self.enable_vae_slicing:
            try:
                pipe.enable_vae_slicing()
            except Exception as e:
                logger.debug("vae_slicing failed: %s", e)
        if self.enable_vae_tiling and hasattr(pipe, "enable_vae_tiling"):
            try:
                pipe.enable_vae_tiling()
            except Exception as e:
                logger.debug("vae_tiling failed: %s", e)

        use_offload = bool(self.enable_cpu_offload and torch.cuda.is_available())
        if use_offload:
            pipe.enable_model_cpu_offload()
        elif torch.cuda.is_available():
            pipe = pipe.to(self.device)
            try:
                if hasattr(pipe, "unet") and pipe.unet is not None:
                    pipe.unet.to(memory_format=torch.channels_last)
            except Exception as e:
                logger.debug("channels_last failed: %s", e)
        else:
            pipe = pipe.to("cpu")

        pipe._pocketstudio_cpu_offload = use_offload

        try:
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
        except Exception:
            pass

        logger.info(
            "Pipeline ready | model=%s | cpu_offload=%s | dtype=%s | device=%s | vram=%.1fGB",
            self.MODEL_ID,
            use_offload,
            torch_dtype,
            self.device if not use_offload else "auto (offload-managed)",
            self._vram_gb,
        )
        return pipe

    @staticmethod
    def _enable_efficient_attention(pipe: Any) -> None:
        """Prefer xformers, fall back to PyTorch SDPA."""
        try:
            pipe.enable_xformers_memory_efficient_attention()
            logger.info("xformers memory-efficient attention enabled")
            return
        except Exception:
            pass
        try:
            import torch
            if hasattr(torch.nn.functional, "scaled_dot_product_attention"):
                logger.info("Using PyTorch SDPA attention (xformers unavailable)")
        except Exception:
            pass

    def generate(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 512,
        height: int = 768,
        num_inference_steps: int = 4,
        guidance_scale: float = 0.0,
        seed: Optional[int] = None,
        output_dir: Optional[Path] = None,
    ) -> Path:
        meta = self._model_meta
        if guidance_scale <= 0.0 and meta["guidance_scale"] > 0.0:
            guidance_scale = float(meta["guidance_scale"])
        if num_inference_steps <= 4 and meta["kind"] == "sd15":
            num_inference_steps = int(meta["default_steps"])

        width, height = _clamp_resolution_for_model(
            width, height, self._vram_gb, self._model_key,
        )

        cache_key = HashCache.make_key(
            self.MODEL_NAME, prompt, negative_prompt, width, height,
            num_inference_steps, guidance_scale, seed,
        )
        cached = self.cache.get(cache_key)
        if cached:
            logger.info("Image cache HIT: %s", cache_key[:12])
            return cached

        ladder = _resolution_ladder(width, height)
        last_error: Optional[Exception] = None

        for attempt, (w, h) in enumerate(ladder):
            try:
                path = self._generate_once(
                    prompt=prompt,
                    negative_prompt=negative_prompt,
                    width=w,
                    height=h,
                    num_inference_steps=num_inference_steps,
                    guidance_scale=guidance_scale,
                    seed=seed,
                    output_dir=output_dir,
                    cache_key=cache_key if (w, h) == (width, height) else None,
                )
                if attempt > 0:
                    logger.warning(
                        "OOM recovery succeeded at %dx%d (attempt %d/%d)",
                        w, h, attempt + 1, len(ladder),
                    )
                return path
            except _CudaOOM as oom:
                last_error = oom
                logger.error(
                    "CUDA OOM at %dx%d (attempt %d/%d) → trying lower resolution",
                    w, h, attempt + 1, len(ladder),
                )
                _free_cuda()
                try:
                    self.model_pool.force_unload(self.MODEL_NAME)
                except Exception:
                    pass
                _free_cuda()
                continue

        raise RuntimeError(
            "GPU hết bộ nhớ (CUDA Out of Memory) sau khi đã thử toàn bộ thang độ phân giải "
            f"({ladder[0][0]}x{ladder[0][1]} → {ladder[-1][0]}x{ladder[-1][1]}). "
            "Hãy giảm số cảnh, đóng ứng dụng khác đang dùng GPU, hoặc chuyển Performance Mode = weak."
        ) from last_error

    def _generate_once(
        self,
        prompt: str,
        negative_prompt: str,
        width: int,
        height: int,
        num_inference_steps: int,
        guidance_scale: float,
        seed: Optional[int],
        output_dir: Optional[Path],
        cache_key: Optional[str],
    ) -> Path:
        import torch

        pipe = self.model_pool.acquire(self.MODEL_NAME)
        released = False
        try:
            validate_pipeline_devices(pipe, expect_cpu_offload=self.enable_cpu_offload)

            generator = None
            if seed is not None:
                generator = torch.Generator(device="cpu").manual_seed(seed)

            t0 = time.time()
            try:
                with torch.inference_mode():
                    result = pipe(
                        prompt=prompt,
                        negative_prompt=negative_prompt or None,
                        width=width,
                        height=height,
                        num_inference_steps=num_inference_steps,
                        guidance_scale=guidance_scale,
                        generator=generator,
                    )
            except torch.cuda.OutOfMemoryError as oom:
                logger.error("CUDA OOM during image generation: %s", oom)
                _free_cuda()
                try:
                    self.model_pool.release(self.MODEL_NAME)
                    released = True
                except Exception:
                    pass
                try:
                    self.model_pool.force_unload(self.MODEL_NAME)
                except Exception:
                    pass
                _free_cuda()
                raise _CudaOOM(str(oom)) from oom

            image: Image.Image = result.images[0]
            del result
            elapsed = time.time() - t0
            logger.info(
                "Generated image in %.2fs | %dx%d | steps=%d | cfg=%.1f | model=%s",
                elapsed, width, height, num_inference_steps, guidance_scale, self.MODEL_NAME,
            )

            if output_dir is None:
                output_dir = Path("cache/tmp")
            output_dir.mkdir(parents=True, exist_ok=True)

            key = cache_key or HashCache.make_key(
                self.MODEL_NAME, prompt, negative_prompt, width, height,
                num_inference_steps, guidance_scale, seed,
            )
            tmp_path = output_dir / f"{key[:16]}.png"
            image.save(tmp_path, format="PNG", optimize=True)
            del image

            final_path = self.cache.put(
                key, tmp_path,
                metadata={
                    "prompt": prompt,
                    "width": width,
                    "height": height,
                    "steps": num_inference_steps,
                    "seed": seed,
                    "model": self.MODEL_NAME,
                },
            )
            tmp_path.unlink(missing_ok=True)
            return final_path
        finally:
            if not released:
                self.model_pool.release(self.MODEL_NAME)
            _free_cuda()


class _CudaOOM(Exception):
    """Internal signal used by the adaptive resolution ladder."""
