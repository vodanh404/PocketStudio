"""Model Pool with Lazy Loading, Reference Counting and a Safe Lifecycle
State Machine.

ROOT CAUSE FIXED HERE (see docs/AUTO_PIPELINE_FIX_REPORT.md for the
original incident): the previous implementation tracked `ref_count` but
never *enforced* it. `force_unload_all()` (called from MemoryManager on
its own background thread whenever RAM/VRAM crossed a threshold) moved
the pipeline back to CPU and deleted it unconditionally -- including
while a worker thread was in the middle of a `pipe(...)` forward pass.
Moving weights to CPU mid-forward-pass on a GPU pipeline is exactly how
you get "Expected all tensors to be on the same device, but found at
least two devices, cpu and cuda:0": the calling thread already has
CUDA activations on the GPU, and the next `Linear()` it hits now has
CPU weights.

Lifecycle enforced below, per model name:

    UNLOADED --acquire()--> LOADING --loader() ok--> BUSY <--acquire()/release()--> READY
       ^                       |
       |                    loader() raises
       |                       v
       +<------------------ ERROR
    READY --idle timeout / memory pressure, ref_count==0 only--> UNLOADING --> UNLOADED

Invariant, enforced entirely under `_lock`/`_cond` (never on a best
-effort basis): a model can only enter UNLOADING when `ref_count == 0`.
It is NEVER touched while `ref_count > 0` (BUSY), no matter which
thread -- janitor, MemoryManager, or a UI button -- asked for cleanup.
"""
from __future__ import annotations

import gc
import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)


class ModelState(str, Enum):
    UNLOADED = "unloaded"
    LOADING = "loading"
    READY = "ready"
    BUSY = "busy"
    UNLOADING = "unloading"
    ERROR = "error"


@dataclass
class ModelHandle:
    name: str
    instance: Any = None
    state: ModelState = ModelState.UNLOADED
    ref_count: int = 0
    last_used: float = field(default_factory=time.time)
    # True when the instance manages its own CPU<->GPU placement via
    # accelerate forward hooks (`enable_model_cpu_offload()` /
    # `device_map="auto"`). Unloading such an instance must never call
    # `.to(...)` on it manually -- see `_release_pipeline` below.
    offloaded: bool = False


def _release_pipeline(instance: Any, offloaded: bool, name: str) -> None:
    """Free a loaded model/pipeline instance. Called with NO pool lock
    held, and only ever after the pool has already transitioned the
    handle to UNLOADING (i.e. ref_count was 0 and nobody can acquire()
    it mid-release -- acquire() blocks on UNLOADING)."""
    if not offloaded and hasattr(instance, "to"):
        try:
            instance.to("cpu")
        except Exception:
            logger.debug("Non-fatal: could not move %s to cpu before unload", name)
    elif offloaded:
        logger.debug(
            "%s was loaded with cpu-offload hooks -- skipping manual .to('cpu') "
            "and dropping the reference directly to avoid disturbing the hooks",
            name,
        )
    try:
        del instance
    except Exception:
        pass
    try:
        gc.collect()
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
    except Exception:
        pass


class ModelPool:
    """Thread-safe pool. Every `pipe(...)` / `model.generate(...)` call
    MUST be bracketed by a matching `acquire(name)` / `release(name)`
    pair. Between those two calls the model is guaranteed to stay in
    BUSY state: the janitor thread and MemoryManager will not unload it,
    no matter how much memory pressure there is."""

    def __init__(self, idle_timeout: int = 120, memory_manager: Any = None) -> None:
        self._models: Dict[str, ModelHandle] = {}
        self._loaders: Dict[str, Callable[[], Any]] = {}
        self._lock = threading.RLock()
        self._cond = threading.Condition(self._lock)
        self.idle_timeout = idle_timeout
        self.memory_manager = memory_manager
        self._stop_event = threading.Event()
        self._janitor: Optional[threading.Thread] = None
        if memory_manager:
            # NOTE: this used to register `force_unload_all` directly,
            # which is what unloaded models out from under an in-flight
            # generation. `request_cleanup` is the safe, busy-aware
            # equivalent -- see below.
            memory_manager.register_unload_callback(self.request_cleanup)

    def register(self, name: str, loader: Callable[[], Any]) -> None:
        with self._lock:
            self._loaders[name] = loader
            self._models.setdefault(name, ModelHandle(name=name))
            logger.info("Model registered: %s", name)

    # ------------------------------------------------------------------
    # Acquire / release
    # ------------------------------------------------------------------
    def acquire(self, name: str, timeout: Optional[float] = None) -> Any:
        """Block until `name` is loaded and available, mark it BUSY, and
        return the instance. Raises TimeoutError if `timeout` is given
        and exceeded while waiting for a concurrent load/unload."""
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            if name not in self._loaders:
                raise KeyError(f"Model '{name}' not registered")
            handle = self._models.setdefault(name, ModelHandle(name=name))

            while handle.state in (ModelState.LOADING, ModelState.UNLOADING):
                if not self._wait(deadline):
                    raise TimeoutError(
                        f"Timed out waiting for model '{name}' (state={handle.state.value})"
                    )

            if handle.state in (ModelState.READY, ModelState.BUSY):
                handle.ref_count += 1
                handle.state = ModelState.BUSY
                handle.last_used = time.time()
                logger.debug("Model acquired: %s (busy_count=%d)", name, handle.ref_count)
                return handle.instance

            if handle.state in (ModelState.UNLOADED, ModelState.ERROR):
                handle.state = ModelState.LOADING
                self._cond.notify_all()
            else:  # pragma: no cover - defensive, should be unreachable
                raise RuntimeError(f"Unexpected state for model '{name}': {handle.state}")

        # On low-VRAM cards (≤6GB) LLM + SDXL cannot coexist on GPU.
        # Evict every other READY model before the slow loader runs so
        # peak residency stays at one heavy model at a time. BUSY peers
        # are left alone (acquire of those would have blocked us).
        self._evict_peers(except_name=name)

        # Load OUTSIDE the lock: this is slow I/O / CUDA init and must
        # not block acquire()/release() of *other* models or the janitor
        # loop for the whole duration.
        try:
            logger.info("Loading model: %s ...", name)
            t0 = time.time()
            instance = self._loaders[name]()
            elapsed = time.time() - t0
            logger.info("Model loaded: %s (%.1fs)", name, elapsed)
        except Exception:
            with self._cond:
                handle.state = ModelState.ERROR
                self._cond.notify_all()
            logger.exception("Failed to load model: %s", name)
            raise

        with self._cond:
            handle.instance = instance
            handle.offloaded = bool(getattr(instance, "_pocketstudio_cpu_offload", False))
            handle.ref_count += 1
            handle.state = ModelState.BUSY
            handle.last_used = time.time()
            self._cond.notify_all()
            logger.debug("Model acquired: %s (busy_count=%d)", name, handle.ref_count)
            return handle.instance

    def _wait(self, deadline: Optional[float]) -> bool:
        if deadline is None:
            self._cond.wait()
            return True
        remaining = deadline - time.time()
        if remaining <= 0:
            return False
        return self._cond.wait(remaining)

    def release(self, name: str) -> None:
        with self._cond:
            handle = self._models.get(name)
            if handle is None:
                return
            handle.ref_count = max(0, handle.ref_count - 1)
            handle.last_used = time.time()
            if handle.ref_count == 0 and handle.state == ModelState.BUSY:
                handle.state = ModelState.READY
            logger.debug("Model released: %s (busy_count=%d)", name, handle.ref_count)
            self._cond.notify_all()

    # ------------------------------------------------------------------
    # Unload paths -- ALL of them funnel through `_try_begin_unload`,
    # the single place that enforces "never unload while ref_count>0".
    # ------------------------------------------------------------------
    def _try_begin_unload(self, handle: ModelHandle) -> bool:
        """Must be called with `_lock` held. Flips the handle to
        UNLOADING and returns True iff it is currently safe to do so."""
        if handle.instance is None or handle.state == ModelState.UNLOADED:
            return False
        if handle.state != ModelState.READY or handle.ref_count > 0:
            logger.info(
                "Cleanup skipped for %s (state=%s, busy_count=%d) -- still in use",
                handle.name, handle.state.value, handle.ref_count,
            )
            return False
        handle.state = ModelState.UNLOADING
        self._cond.notify_all()
        return True

    def _finish_unload(self, handle: ModelHandle) -> None:
        """Heavy lifting happens OUTSIDE the lock; handle flips back to
        UNLOADED under the lock once done."""
        instance = handle.instance
        offloaded = handle.offloaded
        try:
            _release_pipeline(instance, offloaded=offloaded, name=handle.name)
        except Exception:
            logger.exception("Error unloading %s", handle.name)
        with self._cond:
            handle.instance = None
            handle.offloaded = False
            handle.state = ModelState.UNLOADED
            handle.ref_count = 0
            self._cond.notify_all()
        logger.info("Model unloaded: %s", handle.name)

    def _evict_peers(self, except_name: str) -> None:
        """Unload every other READY model so two heavy models (LLM + SDXL)
        never share a 4GB GPU. Safe: only touches handles whose
        ref_count == 0 (via `_try_begin_unload`)."""
        with self._lock:
            peers = [
                h.name for h in self._models.values()
                if h.name != except_name and h.instance is not None
            ]
        for peer in peers:
            with self._lock:
                handle = self._models.get(peer)
                if handle is None:
                    continue
                ok = self._try_begin_unload(handle)
            if ok:
                logger.info(
                    "Evicting peer model '%s' before loading '%s' (exclusive GPU residency)",
                    peer, except_name,
                )
                self._finish_unload(handle)

    def force_unload(self, name: str) -> None:
        """Unload a single model *if it is not currently in use*. Unlike
        the previous implementation, this will never rip a model out
        from under an in-flight `pipe(...)` call -- a BUSY model is left
        alone and logged as skipped."""
        with self._lock:
            handle = self._models.get(name)
            if handle is None:
                return
            if not self._try_begin_unload(handle):
                return
        self._finish_unload(handle)

    def force_unload_all(self) -> None:
        """Best-effort unload of every loaded model. Safe to call
        directly from the UI thread (e.g. the "Unload All" button):
        models currently in use are skipped, never corrupted."""
        with self._lock:
            names = list(self._models.keys())
        for name in names:
            self.force_unload(name)
        logger.info("All models unloaded (busy models, if any, were skipped)")

    def request_cleanup(self, wait_timeout: float = 5.0) -> None:
        """Safe replacement for the old `force_unload_all` callback used
        by MemoryManager under memory pressure:

            RAM cao -> kiem tra model co dang busy khong
                -> neu busy: delay cleanup, doi toi da `wait_timeout`
                -> khi ref_count == 0 (hoac het thoi gian cho): cleanup

        If a model is still busy after `wait_timeout`, it is left alone
        for this cycle -- the janitor loop / next MemoryManager tick
        will retry rather than corrupting an in-flight generation.
        """
        with self._lock:
            names = list(self._models.keys())
        for name in names:
            with self._cond:
                handle = self._models.get(name)
                if handle is None or handle.instance is None:
                    continue
                if handle.state == ModelState.BUSY:
                    logger.info(
                        "Cleanup delayed for %s -- busy, waiting up to %.1fs",
                        name, wait_timeout,
                    )
                    self._cond.wait_for(
                        lambda: handle.state != ModelState.BUSY, timeout=wait_timeout
                    )
                ok = self._try_begin_unload(handle)
            if ok:
                self._finish_unload(handle)

    def _janitor_loop(self) -> None:
        while not self._stop_event.is_set():
            now = time.time()
            with self._lock:
                idle_names = [
                    h.name for h in self._models.values()
                    if h.state == ModelState.READY and (now - h.last_used) > self.idle_timeout
                ]
            for name in idle_names:
                logger.info("Idle timeout -> unload %s", name)
                self.force_unload(name)
            self._stop_event.wait(30)

    def start_janitor(self) -> None:
        if self._janitor and self._janitor.is_alive():
            return
        self._stop_event.clear()
        self._janitor = threading.Thread(
            target=self._janitor_loop, name="ModelPoolJanitor", daemon=True
        )
        self._janitor.start()

    def stop(self) -> None:
        self._stop_event.set()
        self.force_unload_all()

    def status(self) -> dict[str, Any]:
        with self._lock:
            return {
                name: {
                    "state": h.state.value,
                    "ref_count": h.ref_count,
                    "last_used": h.last_used,
                    "idle_seconds": time.time() - h.last_used,
                }
                for name, h in self._models.items()
            }
