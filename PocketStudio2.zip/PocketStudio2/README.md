# MoneyPrinter Desktop

**Production-grade AI Short Video Generator**  
Tối ưu tuyệt đối cho máy yếu: Windows 10/11 • Python 3.11 • 8GB RAM • 4GB VRAM (GTX 1650 / RTX 2050)

> Phiên bản desktop được thiết kế lại hoàn toàn từ cảm hứng MoneyPrinterTurbo.  
> Không dùng Gradio / Streamlit / Electron.  
> Ưu tiên: **Performance > Fancy features**.

---

## Tính năng chính

- Tạo video ngắn từ **chủ đề / keyword** chỉ với vài cú click
- Pipeline đầy đủ có **checkpoint + resume**
- Local Image Generation: **SDXL Turbo** (tối ưu 4GB VRAM)
- Lightweight LLM: **Qwen2.5-0.5B** (hoặc fallback rule-based)
- Voice: **Edge TTS** (gần như 0 VRAM)
- Subtitle: **Faster-Whisper Tiny**
- Render: **FFmpeg thuần** (Ken Burns, fade, burn-in subtitle)
- UI: **Tkinter + ttkbootstrap** (Dark theme)
- Model Pool + Automatic Unload + Memory Guard
- Hash-based Cache (prompt / image)
- Performance profiles: Weak / Balanced / Quality / Ultra

---

## Yêu cầu hệ thống

| Thành phần | Tối thiểu | Khuyến nghị |
|------------|-----------|-------------|
| OS | Windows 10/11 | Windows 11 |
| Python | 3.11 | 3.11 |
| RAM | 8 GB | 16 GB |
| VRAM | 4 GB | 6 GB+ |
| Ổ cứng | SSD | SSD |
| FFmpeg | Bắt buộc | Có libass |

---

## Cài đặt nhanh (Windows)

```bat
git clone <repo> moneyprinter-desktop
cd moneyprinter-desktop
setup.bat
```

Hoặc thủ công:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
python scripts\init_project.py
```

Cài FFmpeg: `winget install ffmpeg`

---

## Chạy ứng dụng

```bat
.venv\Scripts\activate
python -m app.main
```

### Luồng sử dụng

1. **Project** → nhập chủ đề → **Tạo & Chạy Pipeline**
2. **Script** → xem / chỉnh kịch bản
3. Pipeline chạy background: Scene → Prompt → Image → Voice → Subtitle → Render
4. **Assets** → xem ảnh / audio / subtitle
5. **Video** → theo dõi progress
6. **Export** → xuất file cuối

---

## Chạy pipeline từ code

```python
from pathlib import Path
from app.core.app_context import AppContext
from app.pipelines.factory import PipelineFactory

ctx = AppContext.create()
factory = PipelineFactory(ctx)
pipeline = factory.create(Path("projects/demo_01"))

results = pipeline.run(
    topic="Tương lai năng lượng sạch",
    language="vi",
    resume=True,
    width=512, height=768, steps=4,
)
print("Video:", results.get("render"))
ctx.shutdown()
```

Hoặc: `python examples/run_pipeline.py`

---

## Performance Mode

Sửa `config.toml` hoặc Settings UI:

| Mode | Resolution | Steps | CPU Offload |
|------|------------|-------|-------------|
| weak | 720×1280 | 4 | Bật |
| balanced | 720×1280 | 6 | Bật |
| quality | 1080×1920 | 8 | Tắt |
| ultra | 1080×1920 | 12 | Tắt |

---

## Troubleshooting

**CUDA OOM** → dùng mode `weak`, bật cpu_offload.  
**FFmpeg not found** → cài và thêm vào PATH.  
**Edge TTS fail** → cần mạng lần đầu.  
**Model download chậm** → `set HF_ENDPOINT=https://hf-mirror.com`

---

## License

MIT

**Thiết kế cho máy yếu. Chạy được mới là quan trọng.**
