@echo off
chcp 65001 >nul
title MoneyPrinter Desktop - Setup

echo ============================================================
echo   MoneyPrinter Desktop - Setup (Windows)
echo ============================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python chua duoc cai hoac chua co trong PATH.
    echo Tai Python 3.11: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/4] Tao virtual environment...
python -m venv .venv
call .venv\Scripts\activate.bat

echo [2/4] Nang cap pip...
python -m pip install --upgrade pip setuptools wheel

echo [3/4] Cai PyTorch (CUDA 12.1)...
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

echo [4/4] Cai cac package con lai...
pip install -r requirements.txt

echo.
echo [+] Chay init project...
python scripts\init_project.py

echo.
echo ============================================================
echo   Setup hoan tat!
echo   Kich hoat moi truong:  .venv\Scripts\activate
echo   Chay ung dung:         python -m app.main
echo ============================================================
pause
