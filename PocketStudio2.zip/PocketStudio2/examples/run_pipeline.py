#!/usr/bin/env python3
"""Example: run full pipeline without UI."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.core.logging_setup import setup_logging
from app.core.app_context import AppContext
from app.pipelines.factory import PipelineFactory


def main() -> None:
    setup_logging()
    ctx = AppContext.create()
    factory = PipelineFactory(ctx)
    project_dir = Path("projects/example_run")
    pipeline = factory.create(project_dir)

    def on_progress(stage: str, percent: float, message: str) -> None:
        print(f"[{stage}] {percent * 100:.0f}% - {message}")

    print("Starting pipeline...")
    results = pipeline.run(
        topic="Loi ich cua viec ngu du giac",
        language="vi",
        resume=True,
        progress=on_progress,
        width=512,
        height=768,
        steps=4,
    )
    render = results.get("render")
    if render:
        print(f"\nDone! Video: {render.video_path}")
        print(f"Duration: {render.duration:.1f}s | Size: {render.file_size_mb} MB")
    else:
        print("\nPipeline finished (partial). Check checkpoints.")
    ctx.shutdown()


if __name__ == "__main__":
    main()
