#!/usr/bin/env python3
"""Initialize MoneyPrinter Desktop project structure."""
from __future__ import annotations

import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

DIRS = [
    "app", "app/core", "app/models", "app/repositories", "app/services",
    "app/workers", "app/pipelines", "app/pipelines/stages",
    "app/ui", "app/ui/pages", "app/ui/widgets", "app/plugins", "app/utils", "app/assets",
    "cache", "cache/images", "cache/audio", "cache/tmp",
    "logs", "models", "projects", "tests", "scripts", "docs", "examples",
]

CONFIG_EXAMPLE = ROOT / "config.example.toml"


def create_dirs() -> None:
    for d in DIRS:
        path = ROOT / d
        path.mkdir(parents=True, exist_ok=True)
        print(f"  ✓ {d}")


def create_config() -> None:
    real_cfg = ROOT / "config.toml"
    if not real_cfg.exists() and CONFIG_EXAMPLE.exists():
        shutil.copy(CONFIG_EXAMPLE, real_cfg)
        print("  ✓ config.toml")


def check_ffmpeg() -> bool:
    try:
        r = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            print("  ✓ FFmpeg OK")
            return True
    except Exception:
        pass
    print("  ✗ FFmpeg chua co trong PATH")
    return False


def check_python() -> bool:
    if sys.version_info < (3, 11):
        print(f"  ✗ Can Python 3.11+ (hien tai {sys.version})")
        return False
    print(f"  ✓ Python {sys.version.split()[0]}")
    return True


def main() -> None:
    print("=" * 60)
    print("  MoneyPrinter Desktop – Project Initializer")
    print("=" * 60)
    print()
    print("[1] Kiem tra moi truong")
    py_ok = check_python()
    ff_ok = check_ffmpeg()
    print()
    print("[2] Tao cau truc thu muc")
    create_dirs()
    print()
    print("[3] Tao config")
    create_config()
    print()
    if py_ok:
        print("✅ Khoi tao hoan tat.")
    else:
        print("⚠️  Con thieu thanh phan.")
    print()


if __name__ == "__main__":
    main()
