"""Lightweight LLM Service optimized for low-end hardware."""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Optional

from app.models.llm import LLMConfig
from app.utils.hash_cache import HashCache

logger = logging.getLogger(__name__)


class LightweightLLMService:
    MODEL_NAME = "llm-lightweight"

    def __init__(
        self,
        model_pool: Any,
        cache: Optional[HashCache] = None,
        config: Optional[LLMConfig] = None,
        enable_remote: bool = False,
        remote_api_base: Optional[str] = None,
        remote_api_key: Optional[str] = None,
        remote_model: str = "gpt-4o-mini",
    ) -> None:
        self.model_pool = model_pool
        self.cache = cache
        self.config = config or LLMConfig()
        self.enable_remote = enable_remote
        self.remote_api_base = remote_api_base
        self.remote_api_key = remote_api_key
        self.remote_model = remote_model
        self.model_pool.register(self.MODEL_NAME, self._load_local_model)

    def generate_script(
        self, topic: str, language: str = "vi", max_scenes: int = 6, style: str = "engaging, concise, spoken language",
    ) -> str:
        cache_key = None
        if self.cache:
            cache_key = HashCache.make_key("script", topic, language, max_scenes, style)
            cached = self.cache.get(cache_key)
            if cached:
                logger.info("Script cache HIT")
                return cached.read_text(encoding="utf-8")

        if self.enable_remote and self.remote_api_key:
            text = self._generate_remote_script(topic, language, max_scenes, style)
        else:
            try:
                text = self._generate_local_script(topic, language, max_scenes, style)
            except Exception as e:
                logger.warning("Local LLM failed (%s) → fallback rule-based", e)
                text = self._fallback_script(topic, language, max_scenes)

        if self.cache and cache_key:
            self.cache.put_bytes(cache_key, text.encode("utf-8"), ext=".txt")
        return text.strip()

    def generate_image_prompt(
        self, scene_text: str, style: str = "cinematic, highly detailed, dramatic lighting, 8k", vertical: bool = True,
    ) -> str:
        cache_key = None
        if self.cache:
            cache_key = HashCache.make_key("img_prompt", scene_text, style, vertical)
            cached = self.cache.get(cache_key)
            if cached:
                return cached.read_text(encoding="utf-8")

        if self.enable_remote and self.remote_api_key:
            prompt = self._generate_remote_image_prompt(scene_text, style, vertical)
        else:
            try:
                prompt = self._generate_local_image_prompt(scene_text, style, vertical)
            except Exception as e:
                logger.warning("Local LLM image prompt failed (%s) → fallback", e)
                prompt = self._fallback_image_prompt(scene_text, style, vertical)

        prompt = self._clean_prompt(prompt)
        if self.cache and cache_key:
            self.cache.put_bytes(cache_key, prompt.encode("utf-8"), ext=".txt")
        return prompt

    def _load_local_model(self) -> dict[str, Any]:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        model_id = self.config.model_name
        logger.info("Loading lightweight LLM: %s ...", model_id)
        tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=self.config.trust_remote_code)
        dtype = {"float16": torch.float16, "bfloat16": torch.bfloat16, "float32": torch.float32}.get(
            self.config.dtype, torch.float16
        )
        load_kwargs: dict[str, Any] = {
            "trust_remote_code": self.config.trust_remote_code,
            "low_cpu_mem_usage": True,
            "torch_dtype": dtype,
        }
        if self.config.load_in_4bit:
            try:
                from transformers import BitsAndBytesConfig
                load_kwargs["quantization_config"] = BitsAndBytesConfig(
                    load_in_4bit=True, bnb_4bit_compute_dtype=dtype, bnb_4bit_use_double_quant=True,
                )
                load_kwargs.pop("torch_dtype", None)
            except Exception as e:
                logger.warning("4-bit not available (%s), fallback fp16", e)
        if self.config.device == "auto":
            load_kwargs["device_map"] = "auto"
        else:
            load_kwargs["device_map"] = self.config.device
        model = AutoModelForCausalLM.from_pretrained(model_id, **load_kwargs)
        model.eval()
        logger.info("LLM loaded successfully")
        return {"model": model, "tokenizer": tokenizer}

    def _generate_local(self, system_prompt: str, user_prompt: str, max_new_tokens: Optional[int] = None) -> str:
        import torch
        handle = self.model_pool.acquire(self.MODEL_NAME)
        try:
            model = handle["model"]
            tokenizer = handle["tokenizer"]
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
            if hasattr(tokenizer, "apply_chat_template"):
                text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            else:
                text = f"System: {system_prompt}\nUser: {user_prompt}\nAssistant:"
            inputs = tokenizer(text, return_tensors="pt")
            inputs = {k: v.to(model.device) for k, v in inputs.items()}
            with torch.inference_mode():
                outputs = model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens or self.config.max_new_tokens,
                    temperature=self.config.temperature,
                    top_p=self.config.top_p,
                    do_sample=True,
                    pad_token_id=tokenizer.eos_token_id,
                    repetition_penalty=1.1,
                )
            generated = outputs[0][inputs["input_ids"].shape[-1]:]
            return tokenizer.decode(generated, skip_special_tokens=True).strip()
        finally:
            self.model_pool.release(self.MODEL_NAME)

    def _generate_local_script(self, topic: str, language: str, max_scenes: int, style: str) -> str:
        if language == "vi":
            system = (
                "Bạn là biên kịch video ngắn chuyên nghiệp. "
                "Viết kịch bản nói (spoken language), ngắn gọn, hấp dẫn, "
                "phù hợp voice-over. Mỗi câu một ý. Không dùng markdown."
            )
            user = (
                f"Chủ đề: {topic}\nSố phân đoạn tối đa: {max_scenes}\n"
                f"Phong cách: {style}\nNgôn ngữ: Tiếng Việt\n"
                "Viết kịch bản hoàn chỉnh, mỗi câu xuống dòng."
            )
        else:
            system = (
                "You are a professional short-form video scriptwriter. "
                "Write concise, engaging spoken-language scripts suitable for voice-over. "
                "One idea per sentence. No markdown."
            )
            user = f"Topic: {topic}\nMax segments: {max_scenes}\nStyle: {style}\nWrite the full script, one sentence per line."
        return self._generate_local(system, user, max_new_tokens=400)

    def _fallback_script(self, topic: str, language: str, max_scenes: int) -> str:
        if language == "vi":
            lines = [
                f"Hôm nay chúng ta cùng khám phá chủ đề: {topic}.",
                "Đây là một chủ đề rất đáng để tìm hiểu sâu hơn.",
                "Hãy bắt đầu với những điểm quan trọng nhất.",
                "Mỗi khía cạnh sẽ mang đến góc nhìn thú vị.",
                "Cuối cùng chúng ta rút ra bài học thực tế.",
                "Cảm ơn bạn đã theo dõi đến cuối video.",
            ]
        else:
            lines = [
                f"Today we explore the topic: {topic}.",
                "This is a subject worth understanding more deeply.",
                "Let's start with the most important points.",
                "Each aspect offers a fresh perspective.",
                "Finally we extract practical takeaways.",
                "Thank you for watching until the end.",
            ]
        return "\n".join(lines[:max_scenes])

    def _generate_local_image_prompt(self, scene_text: str, style: str, vertical: bool) -> str:
        orientation = "vertical composition, portrait orientation" if vertical else "wide cinematic shot"
        system = (
            "You are an expert Stable Diffusion prompt engineer. "
            "Create a single, concise, high-quality image prompt. "
            "Focus on visual details, lighting, mood. "
            "Do NOT include any explanation, only the prompt itself."
        )
        user = f"Scene description: {scene_text}\nRequired style: {style}, {orientation}\nOutput only the final prompt, under 40 words."
        return self._generate_local(system, user, max_new_tokens=80)

    def _fallback_image_prompt(self, scene_text: str, style: str, vertical: bool) -> str:
        orientation = "vertical composition" if vertical else "cinematic wide shot"
        keywords = " ".join(re.findall(r"\b\w{4,}\b", scene_text.lower())[:6])
        return f"{keywords}, {style}, {orientation}, highly detailed, dramatic lighting"

    def _clean_prompt(self, text: str) -> str:
        text = re.sub(r"```.*?```", "", text, flags=re.DOTALL)
        text = re.sub(r"^\s*[-*]\s*", "", text, flags=re.MULTILINE)
        text = text.replace('"', "").replace("'", "")
        lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
        if lines:
            return max(lines, key=len)[:300]
        return text.strip()[:300]

    def _generate_remote_script(self, topic: str, language: str, max_scenes: int, style: str) -> str:
        system = "You are a professional short video scriptwriter."
        user = f"Write a spoken-language script about '{topic}' in {language}. Max {max_scenes} short sentences. Style: {style}."
        return self._call_remote(system, user)

    def _generate_remote_image_prompt(self, scene_text: str, style: str, vertical: bool) -> str:
        orientation = "vertical" if vertical else "horizontal"
        system = "You are a Stable Diffusion prompt expert. Reply with only the prompt."
        user = f"Create a concise SD prompt for: {scene_text}. Style: {style}, {orientation} composition."
        return self._call_remote(system, user, max_tokens=80)

    def _call_remote(self, system: str, user: str, max_tokens: int = 400) -> str:
        import requests
        url = f"{self.remote_api_base.rstrip('/')}/chat/completions"
        headers = {"Authorization": f"Bearer {self.remote_api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.remote_model,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "max_tokens": max_tokens,
            "temperature": self.config.temperature,
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=60)
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
