"""Model Pool with Lazy Loading, Reference Counting and Automatic Unload."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)


@dataclass
class ModelHandle:
    name: str
    instance: Any
    ref_count: int = 0
    last_used: float = field(default_factory=time.time)
    device: str = "cpu"
    vram_mb: float = 0.0


class ModelPool:
    def __init__(self, idle_timeout: int = 120, memory_manager: Any = None) -> None:
        self._models: Dict[str, ModelHandle] = {}
        self._loaders: Dict[str, Callable[[], Any]] = {}
        self._lock = threading.RLock()
        self.idle_timeout = idle_timeout
        self.memory_manager = memory_manager
        self._stop_event = threading.Event()
        self._janitor: Optional[threading.Thread] = None
        if memory_manager:
            memory_manager.register_unload_callback(self.force_unload_all)

    def register(self, name: str, loader: Callable[[], Any]) -> None:
        with self._lock:
            self._loaders[name] = loader
            logger.info("Model registered: %s", name)

    def acquire(self, name: str) -> Any:
        with self._lock:
            if name not in self._loaders:
                raise KeyError(f"Model '{name}' not registered")
            if name not in self._models:
                logger.info("Loading model: %s ...", name)
                t0 = time.time()
                instance = self._loaders[name]()
                elapsed = time.time() - t0
                self._models[name] = ModelHandle(name=name, instance=instance)
                logger.info("Model %s loaded in %.1fs", name, elapsed)
            handle = self._models[name]
            handle.ref_count += 1
            handle.last_used = time.time()
            return handle.instance

    def release(self, name: str) -> None:
        with self._lock:
            if name not in self._models:
                return
            handle = self._models[name]
            handle.ref_count = max(0, handle.ref_count - 1)
            handle.last_used = time.time()
            logger.debug("Released %s (ref=%d)", name, handle.ref_count)

    def force_unload(self, name: str) -> None:
        with self._lock:
            if name not in self._models:
                return
            handle = self._models[name]
            if handle.ref_count > 0:
                logger.warning("Force unload %s while ref_count=%d", name, handle.ref_count)
            self._unload(handle)
            del self._models[name]

    def force_unload_all(self) -> None:
        with self._lock:
            names = list(self._models.keys())
            for name in names:
                self._unload(self._models[name])
                del self._models[name]
            logger.info("All models unloaded")

    def _unload(self, handle: ModelHandle) -> None:
        try:
            if hasattr(handle.instance, "to"):
                handle.instance.to("cpu")
            del handle.instance
        except Exception as e:
            logger.exception("Error unloading %s: %s", handle.name, e)
        try:
            import gc
            import torch
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
        except Exception:
            pass
        logger.info("Unloaded model: %s", handle.name)

    def _janitor_loop(self) -> None:
        while not self._stop_event.is_set():
            now = time.time()
            with self._lock:
                to_unload = [
                    name for name, handle in self._models.items()
                    if handle.ref_count == 0 and (now - handle.last_used) > self.idle_timeout
                ]
                for name in to_unload:
                    logger.info("Idle timeout → unload %s", name)
                    self._unload(self._models[name])
                    del self._models[name]
            self._stop_event.wait(30)

    def start_janitor(self) -> None:
        if self._janitor and self._janitor.is_alive():
            return
        self._stop_event.clear()
        self._janitor = threading.Thread(
            target=self._janitor_loop, name="ModelPoolJanitor", daemon=True
        )
        self._janitor.start()

    def stop(self) -> None:
        self._stop_event.set()
        self.force_unload_all()

    def status(self) -> dict[str, Any]:
        with self._lock:
            return {
                name: {
                    "ref_count": h.ref_count,
                    "last_used": h.last_used,
                    "idle_seconds": time.time() - h.last_used,
                }
                for name, h in self._models.items()
            }
