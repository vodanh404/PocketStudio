"""Image Generation Backend – SDXL Turbo optimized for 4GB VRAM."""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Optional

from PIL import Image

from app.utils.hash_cache import HashCache

logger = logging.getLogger(__name__)


class SDXLTurboBackend:
    MODEL_ID = "stabilityai/sdxl-turbo"
    MODEL_NAME = "sdxl-turbo"

    def __init__(
        self,
        model_pool: Any,
        cache: Any,
        device: str = "cuda",
        dtype: str = "fp16",
        enable_cpu_offload: bool = True,
        enable_attention_slicing: bool = True,
        enable_vae_slicing: bool = True,
    ) -> None:
        self.model_pool = model_pool
        self.cache = cache
        self.device = device
        self.dtype = dtype
        self.enable_cpu_offload = enable_cpu_offload
        self.enable_attention_slicing = enable_attention_slicing
        self.enable_vae_slicing = enable_vae_slicing
        self.model_pool.register(self.MODEL_NAME, self._load_pipeline)

    def _load_pipeline(self) -> Any:
        import torch
        from diffusers import AutoPipelineForText2Image

        torch_dtype = torch.float16 if self.dtype == "fp16" else torch.float32
        pipe = AutoPipelineForText2Image.from_pretrained(
            self.MODEL_ID,
            torch_dtype=torch_dtype,
            variant="fp16" if self.dtype == "fp16" else None,
            use_safetensors=True,
        )
        if self.enable_attention_slicing:
            pipe.enable_attention_slicing(slice_size="max")
        if self.enable_vae_slicing:
            pipe.enable_vae_slicing()
        if self.enable_cpu_offload and torch.cuda.is_available():
            pipe.enable_model_cpu_offload()
        else:
            pipe = pipe.to(self.device)
        try:
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
        except Exception:
            pass
        logger.info("SDXL Turbo pipeline ready (cpu_offload=%s)", self.enable_cpu_offload)
        return pipe

    def generate(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 512,
        height: int = 768,
        num_inference_steps: int = 4,
        guidance_scale: float = 0.0,
        seed: Optional[int] = None,
        output_dir: Optional[Path] = None,
    ) -> Path:
        cache_key = HashCache.make_key(
            self.MODEL_NAME, prompt, negative_prompt, width, height,
            num_inference_steps, guidance_scale, seed,
        )
        cached = self.cache.get(cache_key)
        if cached:
            logger.info("Image cache HIT: %s", cache_key[:12])
            return cached

        import torch
        pipe = self.model_pool.acquire(self.MODEL_NAME)
        try:
            generator = None
            if seed is not None:
                generator = torch.Generator(device="cpu").manual_seed(seed)
            t0 = time.time()
            result = pipe(
                prompt=prompt,
                negative_prompt=negative_prompt or None,
                width=width,
                height=height,
                num_inference_steps=num_inference_steps,
                guidance_scale=guidance_scale,
                generator=generator,
            )
            image: Image.Image = result.images[0]
            elapsed = time.time() - t0
            logger.info("Generated image in %.2fs | %dx%d", elapsed, width, height)

            if output_dir is None:
                output_dir = Path("cache/tmp")
            output_dir.mkdir(parents=True, exist_ok=True)
            tmp_path = output_dir / f"{cache_key[:16]}.png"
            image.save(tmp_path, format="PNG", optimize=True)
            final_path = self.cache.put(
                cache_key, tmp_path,
                metadata={"prompt": prompt, "width": width, "height": height, "steps": num_inference_steps, "seed": seed},
            )
            tmp_path.unlink(missing_ok=True)
            return final_path
        finally:
            self.model_pool.release(self.MODEL_NAME)
