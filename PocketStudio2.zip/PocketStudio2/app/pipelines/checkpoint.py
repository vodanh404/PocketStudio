"""Checkpoint manager for pipeline stages."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


class CheckpointManager:
    def __init__(self, project_dir: Path) -> None:
        self.project_dir = Path(project_dir)
        self.checkpoint_dir = self.project_dir / "checkpoints"
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def _path(self, stage: str) -> Path:
        return self.checkpoint_dir / f"{stage}.json"

    def save(self, stage: str, data: dict[str, Any]) -> None:
        path = self._path(stage)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
        logger.info("Checkpoint saved: %s", stage)

    def load(self, stage: str) -> Optional[dict[str, Any]]:
        path = self._path(stage)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.error("Failed to load checkpoint %s: %s", stage, e)
            return None

    def exists(self, stage: str) -> bool:
        return self._path(stage).exists()

    def clear(self, stage: Optional[str] = None) -> None:
        if stage:
            self._path(stage).unlink(missing_ok=True)
        else:
            for f in self.checkpoint_dir.glob("*.json"):
                f.unlink(missing_ok=True)

    def list_completed(self) -> list[str]:
        return [p.stem for p in self.checkpoint_dir.glob("*.json")]
