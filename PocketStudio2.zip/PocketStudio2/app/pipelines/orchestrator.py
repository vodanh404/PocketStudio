"""Pipeline Orchestrator with checkpoint + resume."""
from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Any, Callable, Optional

from app.models.pipeline import (
    StageName, ScriptResult, SceneSplitResult, PromptGenResult,
    ImageGenResult, VoiceResult, SubtitleResult, RenderResult,
)
from app.pipelines.checkpoint import CheckpointManager
from app.pipelines.stages.script_stage import ScriptStage
from app.pipelines.stages.scene_split_stage import SceneSplitStage
from app.pipelines.stages.prompt_gen_stage import PromptGenStage
from app.pipelines.stages.image_gen_stage import ImageGenStage
from app.pipelines.stages.voice_stage import VoiceStage
from app.pipelines.stages.subtitle_stage import SubtitleStage
from app.pipelines.stages.render_stage import RenderStage

logger = logging.getLogger(__name__)
ProgressCallback = Callable[[str, float, str], None]


class VideoPipeline:
    def __init__(
        self,
        project_dir: Path,
        script_stage: ScriptStage,
        scene_stage: SceneSplitStage,
        prompt_stage: PromptGenStage,
        image_stage: ImageGenStage,
        voice_stage: VoiceStage,
        subtitle_stage: SubtitleStage,
        render_stage: RenderStage,
    ) -> None:
        self.project_dir = Path(project_dir)
        self.checkpoint = CheckpointManager(self.project_dir)
        self.stages = {
            StageName.SCRIPT: script_stage,
            StageName.SCENE_SPLIT: scene_stage,
            StageName.PROMPT_GEN: prompt_stage,
            StageName.IMAGE_GEN: image_stage,
            StageName.VOICE: voice_stage,
            StageName.SUBTITLE: subtitle_stage,
            StageName.RENDER: render_stage,
        }
        self.cancel_event = threading.Event()

    def cancel(self) -> None:
        self.cancel_event.set()
        for stage in self.stages.values():
            stage.cancel_event = self.cancel_event

    def run(
        self,
        topic: str,
        language: str = "vi",
        resume: bool = True,
        progress: Optional[ProgressCallback] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        self.cancel_event.clear()
        results: dict[str, Any] = {}

        # 1. SCRIPT
        if resume and self.checkpoint.exists(StageName.SCRIPT.value):
            data = self.checkpoint.load(StageName.SCRIPT.value)
            results[StageName.SCRIPT.value] = ScriptResult.from_dict(data)
            logger.info("Resumed SCRIPT")
        else:
            if progress:
                progress(StageName.SCRIPT.value, 0.0, "Bắt đầu tạo kịch bản")
            stage = self.stages[StageName.SCRIPT]
            stage.cancel_event = self.cancel_event
            result = stage.run(
                {"topic": topic, "language": language},
                progress=lambda p, m: progress(StageName.SCRIPT.value, p, m) if progress else None,
            )
            self.checkpoint.save(StageName.SCRIPT.value, result.to_dict())
            results[StageName.SCRIPT.value] = result
        if self.cancel_event.is_set():
            return results

        # 2. SCENE SPLIT
        if resume and self.checkpoint.exists(StageName.SCENE_SPLIT.value):
            data = self.checkpoint.load(StageName.SCENE_SPLIT.value)
            results[StageName.SCENE_SPLIT.value] = SceneSplitResult.from_dict(data)
            logger.info("Resumed SCENE_SPLIT")
        else:
            if progress:
                progress(StageName.SCENE_SPLIT.value, 0.0, "Tách cảnh")
            stage = self.stages[StageName.SCENE_SPLIT]
            stage.cancel_event = self.cancel_event
            result = stage.run(
                results[StageName.SCRIPT.value],
                progress=lambda p, m: progress(StageName.SCENE_SPLIT.value, p, m) if progress else None,
            )
            self.checkpoint.save(StageName.SCENE_SPLIT.value, result.to_dict())
            results[StageName.SCENE_SPLIT.value] = result
        if self.cancel_event.is_set():
            return results

        # 3. PROMPT GEN
        if resume and self.checkpoint.exists(StageName.PROMPT_GEN.value):
            data = self.checkpoint.load(StageName.PROMPT_GEN.value)
            results[StageName.PROMPT_GEN.value] = PromptGenResult.from_dict(data)
            logger.info("Resumed PROMPT_GEN")
        else:
            if progress:
                progress(StageName.PROMPT_GEN.value, 0.0, "Tạo prompt")
            stage = self.stages[StageName.PROMPT_GEN]
            stage.cancel_event = self.cancel_event
            result = stage.run(
                results[StageName.SCENE_SPLIT.value],
                progress=lambda p, m: progress(StageName.PROMPT_GEN.value, p, m) if progress else None,
                **kwargs,
            )
            self.checkpoint.save(StageName.PROMPT_GEN.value, result.to_dict())
            results[StageName.PROMPT_GEN.value] = result
        if self.cancel_event.is_set():
            return results

        # 4. IMAGE GEN
        existing_images = None
        if resume and self.checkpoint.exists(StageName.IMAGE_GEN.value):
            data = self.checkpoint.load(StageName.IMAGE_GEN.value)
            existing_images = ImageGenResult.from_dict(data)
            logger.info("Resumed IMAGE_GEN (partial)")
        if progress:
            progress(StageName.IMAGE_GEN.value, 0.0, "Generating images")
        stage = self.stages[StageName.IMAGE_GEN]
        stage.cancel_event = self.cancel_event
        result = stage.run(
            results[StageName.PROMPT_GEN.value],
            existing=existing_images,
            progress=lambda p, m: progress(StageName.IMAGE_GEN.value, p, m) if progress else None,
            **kwargs,
        )
        self.checkpoint.save(StageName.IMAGE_GEN.value, result.to_dict())
        results[StageName.IMAGE_GEN.value] = result
        if self.cancel_event.is_set():
            return results

        # 5. VOICE
        existing_voice = None
        if resume and self.checkpoint.exists(StageName.VOICE.value):
            data = self.checkpoint.load(StageName.VOICE.value)
            existing_voice = VoiceResult.from_dict(data)
            logger.info("Resumed VOICE (partial)")
        if progress:
            progress(StageName.VOICE.value, 0.0, "Tạo giọng nói")
        stage = self.stages[StageName.VOICE]
        stage.cancel_event = self.cancel_event
        voice_result = stage.run(
            results[StageName.SCENE_SPLIT.value],
            existing=existing_voice,
            progress=lambda p, m: progress(StageName.VOICE.value, p, m) if progress else None,
            **kwargs,
        )
        self.checkpoint.save(StageName.VOICE.value, voice_result.to_dict())
        results[StageName.VOICE.value] = voice_result
        if self.cancel_event.is_set():
            return results

        # 6. SUBTITLE
        existing_sub = None
        if resume and self.checkpoint.exists(StageName.SUBTITLE.value):
            data = self.checkpoint.load(StageName.SUBTITLE.value)
            existing_sub = SubtitleResult.from_dict(data)
            logger.info("Resumed SUBTITLE (partial)")
        if progress:
            progress(StageName.SUBTITLE.value, 0.0, "Tạo phụ đề")
        stage = self.stages[StageName.SUBTITLE]
        stage.cancel_event = self.cancel_event
        sub_result = stage.run(
            voice_result,
            existing=existing_sub,
            language=language,
            progress=lambda p, m: progress(StageName.SUBTITLE.value, p, m) if progress else None,
            **kwargs,
        )
        self.checkpoint.save(StageName.SUBTITLE.value, sub_result.to_dict())
        results[StageName.SUBTITLE.value] = sub_result
        if self.cancel_event.is_set():
            return results

        # 7. RENDER
        if resume and self.checkpoint.exists(StageName.RENDER.value):
            data = self.checkpoint.load(StageName.RENDER.value)
            results[StageName.RENDER.value] = RenderResult.from_dict(data)
            logger.info("Resumed RENDER")
        else:
            if progress:
                progress(StageName.RENDER.value, 0.0, "Bắt đầu render video")
            stage = self.stages[StageName.RENDER]
            stage.cancel_event = self.cancel_event
            render_result = stage.run(
                images=results[StageName.IMAGE_GEN.value],
                voices=results[StageName.VOICE.value],
                subtitles=results[StageName.SUBTITLE.value],
                progress=lambda p, m: progress(StageName.RENDER.value, p, m) if progress else None,
                width=kwargs.get("width", 720),
                height=kwargs.get("height", 1280),
                output_name="final.mp4",
            )
            self.checkpoint.save(StageName.RENDER.value, render_result.to_dict())
            results[StageName.RENDER.value] = render_result

        return results
