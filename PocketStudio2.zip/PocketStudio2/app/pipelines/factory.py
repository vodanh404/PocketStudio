"""Factory to create a complete VideoPipeline for a project."""
from __future__ import annotations

from pathlib import Path
from typing import Optional, TYPE_CHECKING

from app.pipelines.orchestrator import VideoPipeline
from app.pipelines.stages.script_stage import ScriptStage
from app.pipelines.stages.scene_split_stage import SceneSplitStage
from app.pipelines.stages.prompt_gen_stage import PromptGenStage
from app.pipelines.stages.image_gen_stage import ImageGenStage
from app.pipelines.stages.voice_stage import VoiceStage
from app.pipelines.stages.subtitle_stage import SubtitleStage
from app.pipelines.stages.render_stage import RenderStage

if TYPE_CHECKING:
    from app.core.app_context import AppContext


class PipelineFactory:
    def __init__(self, ctx: "AppContext") -> None:
        self.ctx = ctx

    def create(self, project_dir: Path, voice: Optional[str] = None) -> VideoPipeline:
        project_dir = Path(project_dir)
        project_dir.mkdir(parents=True, exist_ok=True)
        images_dir = project_dir / "images"
        audio_dir = project_dir / "audio"
        subtitles_dir = project_dir / "subtitles"
        output_dir = project_dir / "output"
        for d in (images_dir, audio_dir, subtitles_dir, output_dir):
            d.mkdir(exist_ok=True)

        cfg = self.ctx.config
        script_stage = ScriptStage(llm_service=self.ctx.llm_service)
        scene_stage = SceneSplitStage()
        prompt_stage = PromptGenStage(llm_service=self.ctx.llm_service)
        image_stage = ImageGenStage(image_backend=self.ctx.image_backend, output_dir=images_dir)
        voice_stage = VoiceStage(
            output_dir=audio_dir,
            default_voice=voice or getattr(cfg, "default_voice", "vi-VN-HoaiMyNeural"),
        )
        subtitle_stage = SubtitleStage(
            model_pool=self.ctx.model_pool,
            output_dir=subtitles_dir,
            device="cpu",
            compute_type="int8",
        )
        render_stage = RenderStage(
            output_dir=output_dir,
            fps=cfg.fps,
            crf=23,
            preset="veryfast",
            use_nvenc=False,
        )
        return VideoPipeline(
            project_dir=project_dir,
            script_stage=script_stage,
            scene_stage=scene_stage,
            prompt_stage=prompt_stage,
            image_stage=image_stage,
            voice_stage=voice_stage,
            subtitle_stage=subtitle_stage,
            render_stage=render_stage,
        )
