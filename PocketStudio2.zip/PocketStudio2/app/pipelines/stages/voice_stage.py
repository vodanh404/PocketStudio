from __future__ import annotations

import asyncio
import logging
import subprocess
from pathlib import Path
from typing import Any, Optional

from app.models.pipeline import SceneVoice, VoiceResult, SceneSplitResult
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class VoiceStage(BaseStage):
    name = "voice"

    def __init__(
        self,
        output_dir: Path,
        default_voice: str = "vi-VN-HoaiMyNeural",
        rate: str = "+0%",
        volume: str = "+0%",
        cache: Any = None,
    ) -> None:
        super().__init__()
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.default_voice = default_voice
        self.rate = rate
        self.volume = volume
        self.cache = cache

    def run(
        self,
        input_data: SceneSplitResult,
        progress: Optional[ProgressCallback] = None,
        existing: Optional[VoiceResult] = None,
        **kwargs: Any,
    ) -> VoiceResult:
        voice = kwargs.get("voice", self.default_voice)
        existing_map = {v.scene_index: v for v in (existing.voices if existing else [])}
        voices: list[SceneVoice] = []
        total = len(input_data.scenes)
        for i, scene in enumerate(input_data.scenes):
            if self.is_cancelled():
                raise RuntimeError("Cancelled")
            if scene.index in existing_map:
                voices.append(existing_map[scene.index])
                if progress:
                    progress((i + 1) / total, f"Bỏ qua voice cảnh {scene.index}")
                continue
            if progress:
                progress(i / total, f"Tạo voice cảnh {scene.index + 1}/{total}")
            audio_path = self.output_dir / f"scene_{scene.index:03d}.mp3"
            duration = self._synthesize(scene.text, audio_path, voice)
            voices.append(SceneVoice(
                scene_index=scene.index, audio_path=str(audio_path), duration=duration, voice=voice,
            ))
        total_duration = sum(v.duration for v in voices)
        if progress:
            progress(1.0, f"Voice xong – tổng {total_duration:.1f}s")
        return VoiceResult(voices=voices, total_duration=total_duration)

    def _synthesize(self, text: str, output_path: Path, voice: str) -> float:
        try:
            import edge_tts
        except ImportError as e:
            raise RuntimeError("Need edge-tts: pip install edge-tts") from e

        async def _run():
            communicate = edge_tts.Communicate(text=text, voice=voice, rate=self.rate, volume=self.volume)
            await communicate.save(str(output_path))

        asyncio.run(_run())
        return self._get_audio_duration(output_path)

    @staticmethod
    def _get_audio_duration(path: Path) -> float:
        try:
            result = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
                capture_output=True, text=True, check=True,
            )
            return float(result.stdout.strip())
        except Exception:
            return max(2.0, len(path.read_bytes()) / 16000)
