from __future__ import annotations

import logging
from typing import Any, Optional

from app.models.pipeline import ScenePrompt, PromptGenResult, SceneSplitResult
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class PromptGenStage(BaseStage):
    name = "prompt_gen"

    def __init__(self, llm_service: Any = None) -> None:
        super().__init__()
        self.llm = llm_service

    def run(self, input_data: SceneSplitResult, progress: Optional[ProgressCallback] = None, **kwargs: Any) -> PromptGenResult:
        style = kwargs.get("style", "cinematic, highly detailed, 8k, dramatic lighting")
        prompts: list[ScenePrompt] = []
        total = len(input_data.scenes)
        for i, scene in enumerate(input_data.scenes):
            if self.is_cancelled():
                raise RuntimeError("Cancelled")
            if progress:
                progress(i / max(total, 1), f"Tạo prompt cảnh {i + 1}/{total}")
            if self.llm:
                prompt_text = self.llm.generate_image_prompt(scene.text, style=style)
            else:
                prompt_text = self._fallback_prompt(scene, style)
            prompts.append(ScenePrompt(
                scene_index=scene.index,
                prompt=prompt_text,
                negative_prompt="blurry, low quality, distorted, text, watermark, ugly, deformed",
                seed=kwargs.get("base_seed", 42) + scene.index,
            ))
        if progress:
            progress(1.0, "Prompt generation hoàn tất")
        return PromptGenResult(prompts=prompts)

    def _fallback_prompt(self, scene, style: str) -> str:
        keywords = ", ".join(scene.keywords) if scene.keywords else scene.text[:60]
        return f"{keywords}, {style}, vertical composition, high quality"
