from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from app.models.pipeline import SubtitleResult, SceneSubtitle, SubtitleCue, VoiceResult
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class SubtitleStage(BaseStage):
    name = "subtitle"
    MODEL_NAME = "whisper-tiny"

    def __init__(
        self,
        model_pool: Any,
        output_dir: Path,
        device: str = "cpu",
        compute_type: str = "int8",
    ) -> None:
        super().__init__()
        self.model_pool = model_pool
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.device = device
        self.compute_type = compute_type
        self.model_pool.register(self.MODEL_NAME, self._load_model)

    def _load_model(self):
        from faster_whisper import WhisperModel
        logger.info("Loading Faster-Whisper tiny (%s, %s)...", self.device, self.compute_type)
        return WhisperModel("tiny", device=self.device, compute_type=self.compute_type)

    def run(
        self,
        input_data: VoiceResult,
        progress: Optional[ProgressCallback] = None,
        existing: Optional[SubtitleResult] = None,
        language: str = "vi",
        **kwargs: Any,
    ) -> SubtitleResult:
        existing_map = {s.scene_index: s for s in (existing.subtitles if existing else [])}
        subtitles: list[SceneSubtitle] = []
        total = len(input_data.voices)
        model = self.model_pool.acquire(self.MODEL_NAME)
        try:
            for i, voice in enumerate(input_data.voices):
                if self.is_cancelled():
                    raise RuntimeError("Cancelled")
                if voice.scene_index in existing_map:
                    subtitles.append(existing_map[voice.scene_index])
                    if progress:
                        progress((i + 1) / total, f"Bỏ qua subtitle cảnh {voice.scene_index}")
                    continue
                if progress:
                    progress(i / total, f"Whisper cảnh {voice.scene_index + 1}/{total}")
                cues = self._transcribe(model, voice.audio_path, language)
                srt_path = self.output_dir / f"scene_{voice.scene_index:03d}.srt"
                self._write_srt(cues, srt_path)
                subtitles.append(SceneSubtitle(
                    scene_index=voice.scene_index, srt_path=str(srt_path), cues=cues,
                ))
        finally:
            self.model_pool.release(self.MODEL_NAME)
        if progress:
            progress(1.0, "Subtitle hoàn tất")
        return SubtitleResult(subtitles=subtitles)

    def _transcribe(self, model, audio_path: str, language: str) -> list[SubtitleCue]:
        segments, _ = model.transcribe(
            audio_path, language=language, beam_size=1, vad_filter=True, word_timestamps=False,
        )
        cues = []
        for idx, seg in enumerate(segments):
            cues.append(SubtitleCue(index=idx, start=seg.start, end=seg.end, text=seg.text.strip()))
        return cues

    @staticmethod
    def _write_srt(cues: list[SubtitleCue], path: Path) -> None:
        def fmt(t: float) -> str:
            h = int(t // 3600)
            m = int((t % 3600) // 60)
            s = int(t % 60)
            ms = int((t % 1) * 1000)
            return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
        lines = []
        for i, cue in enumerate(cues, 1):
            lines.append(str(i))
            lines.append(f"{fmt(cue.start)} --> {fmt(cue.end)}")
            lines.append(cue.text)
            lines.append("")
        path.write_text("\n".join(lines), encoding="utf-8")
