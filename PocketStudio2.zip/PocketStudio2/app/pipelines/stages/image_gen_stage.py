from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from app.models.pipeline import ImageGenResult, PromptGenResult, SceneImage
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class ImageGenStage(BaseStage):
    name = "image_gen"

    def __init__(self, image_backend: Any, output_dir: Path) -> None:
        super().__init__()
        self.backend = image_backend
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def run(
        self,
        input_data: PromptGenResult,
        progress: Optional[ProgressCallback] = None,
        existing: Optional[ImageGenResult] = None,
        **kwargs: Any,
    ) -> ImageGenResult:
        width = kwargs.get("width", 512)
        height = kwargs.get("height", 768)
        steps = kwargs.get("steps", 4)
        guidance = kwargs.get("guidance_scale", 0.0)
        existing_map = {img.scene_index: img for img in (existing.images if existing else [])}
        images: list[SceneImage] = []
        total = len(input_data.prompts)
        for i, sp in enumerate(input_data.prompts):
            if self.is_cancelled():
                raise RuntimeError("Cancelled")
            if sp.scene_index in existing_map:
                images.append(existing_map[sp.scene_index])
                if progress:
                    progress((i + 1) / total, f"Bỏ qua cảnh {sp.scene_index} (đã có)")
                continue
            if progress:
                progress(i / total, f"Generating cảnh {sp.scene_index + 1}/{total}")
            path = self.backend.generate(
                prompt=sp.prompt,
                negative_prompt=sp.negative_prompt,
                width=width,
                height=height,
                num_inference_steps=steps,
                guidance_scale=guidance,
                seed=sp.seed,
                output_dir=self.output_dir,
            )
            images.append(SceneImage(
                scene_index=sp.scene_index,
                image_path=str(path),
                width=width,
                height=height,
                seed=sp.seed,
            ))
            if progress:
                progress((i + 1) / total, f"Đã xong cảnh {sp.scene_index + 1}")
        return ImageGenResult(images=images)
