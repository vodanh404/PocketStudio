from __future__ import annotations

import logging
import re
from typing import Any, Optional

from app.models.pipeline import Scene, SceneSplitResult
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class SceneSplitStage(BaseStage):
    name = "scene_split"

    def run(self, input_data: Any, progress: Optional[ProgressCallback] = None, **kwargs: Any) -> SceneSplitResult:
        script: str = input_data.full_script
        if progress:
            progress(0.1, "Đang tách cảnh...")
        raw_sentences = re.split(r"(?<=[.!?…\n])\s+", script.strip())
        sentences = [s.strip() for s in raw_sentences if s.strip()]
        scenes: list[Scene] = []
        for idx, text in enumerate(sentences):
            if self.is_cancelled():
                raise RuntimeError("Cancelled")
            word_count = len(text.split())
            duration = max(2.0, min(6.0, word_count * 0.35))
            keywords = self._extract_keywords(text)
            scenes.append(Scene(index=idx, text=text, duration_hint=duration, keywords=keywords))
            if progress:
                progress(0.1 + 0.8 * (idx + 1) / max(len(sentences), 1), f"Cảnh {idx + 1}")
        total = sum(s.duration_hint for s in scenes)
        if progress:
            progress(1.0, f"Tách xong {len(scenes)} cảnh")
        return SceneSplitResult(scenes=scenes, total_duration_estimate=total)

    def _extract_keywords(self, text: str) -> list[str]:
        words = re.findall(r"\b\w{4,}\b", text.lower())
        return list(dict.fromkeys(words))[:5]
