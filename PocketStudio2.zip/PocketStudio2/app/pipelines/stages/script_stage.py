from __future__ import annotations

import logging
from typing import Any, Optional

from app.models.pipeline import ScriptResult
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class ScriptStage(BaseStage):
    name = "script"

    def __init__(self, llm_service: Any = None) -> None:
        super().__init__()
        self.llm = llm_service

    def run(self, input_data: dict[str, Any], progress: Optional[ProgressCallback] = None, **kwargs: Any) -> ScriptResult:
        topic = input_data["topic"]
        language = input_data.get("language", "vi")
        max_scenes = input_data.get("max_scenes", 6)
        if progress:
            progress(0.1, "Đang tạo kịch bản...")
        if self.is_cancelled():
            raise RuntimeError("Cancelled")
        if self.llm:
            script = self.llm.generate_script(topic, language=language, max_scenes=max_scenes)
        else:
            script = self._fallback_script(topic, language, max_scenes)
        if progress:
            progress(1.0, "Kịch bản hoàn tất")
        return ScriptResult(topic=topic, full_script=script, language=language)

    def _fallback_script(self, topic: str, language: str, max_scenes: int) -> str:
        if language == "vi":
            return (
                f"Hôm nay chúng ta sẽ khám phá chủ đề: {topic}.\n"
                f"Đây là một chủ đề rất thú vị và đáng để tìm hiểu.\n"
                f"Hãy cùng điểm qua những khía cạnh quan trọng nhất.\n"
                f"Mỗi phần sẽ mang đến góc nhìn mới mẻ.\n"
                f"Cuối cùng, chúng ta rút ra bài học thực tế.\n"
                f"Cảm ơn bạn đã theo dõi!"
            )
        return (
            f"Today we explore: {topic}.\n"
            f"This topic is fascinating and worth understanding.\n"
            f"Let's break down the key aspects.\n"
            f"Each part offers a fresh perspective.\n"
            f"Finally, we extract practical lessons.\n"
            f"Thank you for watching!"
        )
