"""FFmpeg-based renderer – no Python frame-by-frame rendering."""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional

from app.models.pipeline import ImageGenResult, VoiceResult, SubtitleResult, RenderResult
from app.pipelines.stages.base import BaseStage, ProgressCallback

logger = logging.getLogger(__name__)


class RenderStage(BaseStage):
    name = "render"

    def __init__(
        self,
        output_dir: Path,
        fps: int = 24,
        crf: int = 23,
        preset: str = "veryfast",
        use_nvenc: bool = False,
    ) -> None:
        super().__init__()
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.fps = fps
        self.crf = crf
        self.preset = preset
        self.use_nvenc = use_nvenc and self._has_nvenc()

    def run(
        self,
        images: ImageGenResult,
        voices: VoiceResult,
        subtitles: SubtitleResult,
        progress: Optional[ProgressCallback] = None,
        **kwargs: Any,
    ) -> RenderResult:
        if self.is_cancelled():
            raise RuntimeError("Cancelled")
        width = kwargs.get("width", 720)
        height = kwargs.get("height", 1280)
        output_name = kwargs.get("output_name", "final.mp4")
        final_path = self.output_dir / output_name
        if progress:
            progress(0.05, "Chuẩn bị timeline...")

        img_map = {i.scene_index: i for i in images.images}
        voice_map = {v.scene_index: v for v in voices.voices}
        sub_map = {s.scene_index: s for s in subtitles.subtitles}
        scene_indices = sorted(img_map.keys())
        if not scene_indices:
            raise ValueError("No scenes to render")

        with tempfile.TemporaryDirectory(prefix="mpt_render_") as tmp:
            tmp_path = Path(tmp)
            clip_paths: list[Path] = []
            audio_list_file = tmp_path / "audio_list.txt"
            audio_lines: list[str] = []
            total = len(scene_indices)

            for idx, scene_idx in enumerate(scene_indices):
                if self.is_cancelled():
                    raise RuntimeError("Cancelled")
                if progress:
                    progress(0.05 + 0.55 * (idx / total), f"Tạo clip cảnh {scene_idx + 1}/{total}")
                img = img_map[scene_idx]
                voice = voice_map.get(scene_idx)
                duration = voice.duration if voice else 3.5
                clip_path = tmp_path / f"clip_{scene_idx:03d}.mp4"
                self._create_kenburns_clip(Path(img.image_path), clip_path, duration, width, height)
                clip_paths.append(clip_path)
                if voice:
                    audio_lines.append(f"file '{Path(voice.audio_path).absolute()}'")

            audio_list_file.write_text("\n".join(audio_lines), encoding="utf-8")
            if progress:
                progress(0.65, "Nối video + audio + subtitle...")
            self._concat_and_mux(
                clip_paths, audio_list_file, subtitles, scene_indices, sub_map,
                final_path, width, height, progress,
            )

        duration = self._get_duration(final_path)
        size_mb = final_path.stat().st_size / (1024 * 1024)
        if progress:
            progress(1.0, f"Render xong: {final_path.name} ({size_mb:.1f} MB)")
        return RenderResult(
            video_path=str(final_path), duration=duration, width=width, height=height,
            fps=self.fps, file_size_mb=round(size_mb, 2),
        )

    def _create_kenburns_clip(self, image_path: Path, output_path: Path, duration: float, width: int, height: int) -> None:
        frames = max(int(duration * self.fps), 1)
        filter_complex = (
            f"scale={width}:{height}:force_original_aspect_ratio=increase,"
            f"crop={width}:{height},"
            f"zoompan=z='min(zoom+0.0015,1.15)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            f"d={frames}:s={width}x{height}:fps={self.fps},fps={self.fps}"
        )
        cmd = [
            "ffmpeg", "-y", "-loop", "1", "-i", str(image_path),
            "-vf", filter_complex, "-t", f"{duration:.3f}",
            "-c:v", self._video_encoder(), "-pix_fmt", "yuv420p", "-an", str(output_path),
        ]
        if self.use_nvenc:
            cmd.extend(["-preset", "p4", "-rc", "vbr", "-cq", str(self.crf)])
        else:
            cmd.extend(["-preset", self.preset, "-crf", str(self.crf)])
        self._run_ffmpeg(cmd, "KenBurns clip")

    def _concat_and_mux(
        self, clip_paths, audio_list, subtitles, scene_indices, sub_map, output_path, width, height, progress,
    ) -> None:
        with tempfile.TemporaryDirectory(prefix="mpt_concat_") as tmp:
            tmp_path = Path(tmp)
            video_list = tmp_path / "video_list.txt"
            video_list.write_text("\n".join(f"file '{p.absolute()}'" for p in clip_paths), encoding="utf-8")
            silent_video = tmp_path / "silent.mp4"
            self._run_ffmpeg(
                ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(video_list), "-c", "copy", str(silent_video)],
                "Concat video",
            )
            full_audio = tmp_path / "full_audio.mp3"
            if audio_list.stat().st_size > 0:
                self._run_ffmpeg(
                    ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(audio_list), "-c", "copy", str(full_audio)],
                    "Concat audio",
                )
            else:
                dur = self._get_duration(silent_video)
                self._run_ffmpeg(
                    ["ffmpeg", "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo",
                     "-t", f"{dur:.3f}", "-q:a", "9", str(full_audio)],
                    "Silent audio",
                )
            merged = tmp_path / "merged.mp4"
            self._run_ffmpeg(
                ["ffmpeg", "-y", "-i", str(silent_video), "-i", str(full_audio),
                 "-c:v", "copy", "-c:a", "aac", "-b:a", "128k", "-shortest", str(merged)],
                "Merge A/V",
            )
            final_srt = tmp_path / "final.srt"
            self._build_global_srt(sub_map, scene_indices, final_srt)
            if final_srt.exists() and final_srt.stat().st_size > 10:
                vf = f"subtitles='{final_srt.as_posix()}':force_style='FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=2,Shadow=1'"
                cmd_sub = [
                    "ffmpeg", "-y", "-i", str(merged), "-vf", vf, "-c:a", "copy",
                    "-c:v", self._video_encoder(), "-pix_fmt", "yuv420p",
                ]
                if self.use_nvenc:
                    cmd_sub.extend(["-preset", "p4", "-rc", "vbr", "-cq", str(self.crf)])
                else:
                    cmd_sub.extend(["-preset", self.preset, "-crf", str(self.crf)])
                cmd_sub.append(str(output_path))
                self._run_ffmpeg(cmd_sub, "Burn subtitles")
            else:
                shutil.copy2(merged, output_path)

    def _build_global_srt(self, sub_map, scene_indices, output: Path) -> None:
        offset = 0.0
        lines: list[str] = []
        cue_idx = 1
        for scene_idx in scene_indices:
            sub = sub_map.get(scene_idx)
            if not sub:
                continue
            srt_path = Path(sub.srt_path)
            if not srt_path.exists():
                continue
            content = srt_path.read_text(encoding="utf-8")
            blocks = re.split(r"\n\s*\n", content.strip())
            scene_end = 0.0
            for block in blocks:
                parts = block.strip().split("\n")
                if len(parts) < 3:
                    continue
                timing = parts[1]
                m = re.match(
                    r"(\d+):(\d+):(\d+),(\d+)\s*-->\s*(\d+):(\d+):(\d+),(\d+)", timing,
                )
                if not m:
                    continue
                sh, sm, ss, sms, eh, em, es, ems = map(int, m.groups())
                start = sh * 3600 + sm * 60 + ss + sms / 1000.0
                end = eh * 3600 + em * 60 + es + ems / 1000.0
                scene_end = max(scene_end, end)
                text = "\n".join(parts[2:])
                lines.append(str(cue_idx))
                lines.append(f"{self._fmt_ts(offset + start)} --> {self._fmt_ts(offset + end)}")
                lines.append(text)
                lines.append("")
                cue_idx += 1
            offset += scene_end + 0.05
        output.write_text("\n".join(lines), encoding="utf-8")

    @staticmethod
    def _fmt_ts(t: float) -> str:
        h = int(t // 3600)
        m = int((t % 3600) // 60)
        s = int(t % 60)
        ms = int((t % 1) * 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    def _video_encoder(self) -> str:
        return "h264_nvenc" if self.use_nvenc else "libx264"

    def _has_nvenc(self) -> bool:
        try:
            r = subprocess.run(["ffmpeg", "-encoders"], capture_output=True, text=True, timeout=5)
            return "h264_nvenc" in r.stdout
        except Exception:
            return False

    def _run_ffmpeg(self, cmd: list[str], step: str) -> None:
        logger.debug("FFmpeg %s: %s", step, " ".join(cmd))
        try:
            subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=600)
        except subprocess.CalledProcessError as e:
            logger.error("FFmpeg failed (%s):\n%s", step, (e.stderr or "")[-2000:])
            raise RuntimeError(f"FFmpeg error at {step}") from e
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"FFmpeg timeout at {step}")

    @staticmethod
    def _get_duration(path: Path) -> float:
        try:
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration",
                 "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
                capture_output=True, text=True, check=True,
            )
            return float(r.stdout.strip())
        except Exception:
            return 0.0
