"""Domain models for the video generation pipeline."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Optional
import time


class StageName(str, Enum):
    SCRIPT = "script"
    SCENE_SPLIT = "scene_split"
    PROMPT_GEN = "prompt_gen"
    IMAGE_GEN = "image_gen"
    VOICE = "voice"
    SUBTITLE = "subtitle"
    RENDER = "render"


@dataclass
class ScriptResult:
    topic: str
    full_script: str
    language: str = "vi"
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "ScriptResult":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Scene:
    index: int
    text: str
    duration_hint: float = 3.0
    keywords: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Scene":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class SceneSplitResult:
    scenes: list[Scene]
    total_duration_estimate: float = 0.0

    def to_dict(self) -> dict:
        return {
            "scenes": [s.to_dict() for s in self.scenes],
            "total_duration_estimate": self.total_duration_estimate,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SceneSplitResult":
        scenes = [Scene.from_dict(s) for s in data["scenes"]]
        return cls(scenes=scenes, total_duration_estimate=data.get("total_duration_estimate", 0.0))


@dataclass
class ScenePrompt:
    scene_index: int
    prompt: str
    negative_prompt: str = "blurry, low quality, distorted, text, watermark"
    seed: Optional[int] = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "ScenePrompt":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class PromptGenResult:
    prompts: list[ScenePrompt]

    def to_dict(self) -> dict:
        return {"prompts": [p.to_dict() for p in self.prompts]}

    @classmethod
    def from_dict(cls, data: dict) -> "PromptGenResult":
        return cls(prompts=[ScenePrompt.from_dict(p) for p in data["prompts"]])


@dataclass
class SceneImage:
    scene_index: int
    image_path: str
    width: int
    height: int
    seed: Optional[int] = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "SceneImage":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ImageGenResult:
    images: list[SceneImage]

    def to_dict(self) -> dict:
        return {"images": [i.to_dict() for i in self.images]}

    @classmethod
    def from_dict(cls, data: dict) -> "ImageGenResult":
        return cls(images=[SceneImage.from_dict(i) for i in data["images"]])


@dataclass
class SceneVoice:
    scene_index: int
    audio_path: str
    duration: float
    voice: str = "vi-VN-HoaiMyNeural"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "SceneVoice":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class VoiceResult:
    voices: list[SceneVoice]
    total_duration: float = 0.0

    def to_dict(self) -> dict:
        return {
            "voices": [v.to_dict() for v in self.voices],
            "total_duration": self.total_duration,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "VoiceResult":
        return cls(
            voices=[SceneVoice.from_dict(v) for v in data["voices"]],
            total_duration=data.get("total_duration", 0.0),
        )


@dataclass
class SubtitleCue:
    index: int
    start: float
    end: float
    text: str

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "SubtitleCue":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class SceneSubtitle:
    scene_index: int
    srt_path: str
    cues: list[SubtitleCue] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "scene_index": self.scene_index,
            "srt_path": self.srt_path,
            "cues": [c.to_dict() for c in self.cues],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SceneSubtitle":
        return cls(
            scene_index=data["scene_index"],
            srt_path=data["srt_path"],
            cues=[SubtitleCue.from_dict(c) for c in data.get("cues", [])],
        )


@dataclass
class SubtitleResult:
    subtitles: list[SceneSubtitle]

    def to_dict(self) -> dict:
        return {"subtitles": [s.to_dict() for s in self.subtitles]}

    @classmethod
    def from_dict(cls, data: dict) -> "SubtitleResult":
        return cls(subtitles=[SceneSubtitle.from_dict(s) for s in data["subtitles"]])


@dataclass
class RenderResult:
    video_path: str
    duration: float
    width: int
    height: int
    fps: int
    file_size_mb: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "RenderResult":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
