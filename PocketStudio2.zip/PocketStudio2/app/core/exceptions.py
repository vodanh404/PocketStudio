"""Custom exceptions."""
from __future__ import annotations


class AppError(Exception):
    """Base application error."""


class PipelineError(AppError):
    """Pipeline execution error."""


class ModelLoadError(AppError):
    """Model loading failed."""


class RenderError(AppError):
    """FFmpeg render error."""


class CancelledError(AppError):
    """Task was cancelled."""
