"""Lightweight Dependency Injection Container."""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Type, TypeVar

logger = logging.getLogger(__name__)
T = TypeVar("T")


class DIContainer:
    def __init__(self) -> None:
        self._singletons: Dict[Type, Any] = {}
        self._factories: Dict[Type, Callable[["DIContainer"], Any]] = {}
        self._transients: Dict[Type, Callable[["DIContainer"], Any]] = {}

    def register_singleton(self, interface: Type[T], instance: T) -> None:
        self._singletons[interface] = instance
        logger.debug("Singleton registered: %s", interface.__name__)

    def register_factory(
        self, interface: Type[T], factory: Callable[["DIContainer"], T]
    ) -> None:
        self._factories[interface] = factory
        logger.debug("Factory registered: %s", interface.__name__)

    def register_transient(
        self, interface: Type[T], factory: Callable[["DIContainer"], T]
    ) -> None:
        self._transients[interface] = factory
        logger.debug("Transient registered: %s", interface.__name__)

    def resolve(self, interface: Type[T]) -> T:
        if interface in self._singletons:
            return self._singletons[interface]
        if interface in self._factories:
            return self._factories[interface](self)
        if interface in self._transients:
            return self._transients[interface](self)
        raise KeyError(f"No registration for {interface.__name__}")

    def has(self, interface: Type) -> bool:
        return (
            interface in self._singletons
            or interface in self._factories
            or interface in self._transients
        )

    def clear(self) -> None:
        self._singletons.clear()
        self._factories.clear()
        self._transients.clear()
