"""Configuration system with Performance Profiles."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from functools import lru_cache
from pathlib import Path
from typing import Any


class PerformanceMode(str, Enum):
    WEAK = "weak"
    BALANCED = "balanced"
    QUALITY = "quality"
    ULTRA = "ultra"


@dataclass
class AppConfig:
    base_dir: Path = field(default_factory=lambda: Path.cwd())
    projects_dir: Path = field(default_factory=lambda: Path("projects"))
    cache_dir: Path = field(default_factory=lambda: Path("cache"))
    models_dir: Path = field(default_factory=lambda: Path("models"))
    logs_dir: Path = field(default_factory=lambda: Path("logs"))

    mode: PerformanceMode = PerformanceMode.WEAK

    resolution: tuple[int, int] = (720, 1280)
    fps: int = 24
    batch_size: int = 1
    steps: int = 4
    guidance_scale: float = 0.0
    precision: str = "fp16"
    enable_attention_slicing: bool = True
    enable_vae_slicing: bool = True
    enable_cpu_offload: bool = True
    enable_xformers: bool = True

    image_model_priority: list[str] = field(default_factory=lambda: [
        "sdxl-turbo", "sdxl-lightning", "flux-schnell", "sd1.5",
    ])
    default_image_model: str = "sdxl-turbo"

    llm_model_priority: list[str] = field(default_factory=lambda: [
        "Qwen/Qwen2.5-0.5B-Instruct", "SmolLM2-360M", "TinyLlama-1.1B",
    ])
    default_llm_model: str = "Qwen/Qwen2.5-0.5B-Instruct"

    tts_engine: str = "edge"
    whisper_model: str = "tiny"
    default_voice: str = "vi-VN-HoaiMyNeural"

    ram_warning_percent: float = 70.0
    ram_critical_percent: float = 85.0
    vram_warning_percent: float = 75.0
    model_idle_unload_seconds: int = 120

    enable_prompt_cache: bool = True
    enable_image_cache: bool = True
    max_cache_size_gb: float = 8.0

    theme: str = "darkly"
    language: str = "vi"

    def apply_mode(self, mode: PerformanceMode) -> None:
        self.mode = mode
        if mode == PerformanceMode.WEAK:
            self.resolution = (720, 1280)
            self.fps = 24
            self.batch_size = 1
            self.steps = 4
            self.precision = "fp16"
            self.enable_attention_slicing = True
            self.enable_vae_slicing = True
            self.enable_cpu_offload = True
            self.default_image_model = "sdxl-turbo"
            self.whisper_model = "tiny"
        elif mode == PerformanceMode.BALANCED:
            self.resolution = (720, 1280)
            self.fps = 30
            self.batch_size = 1
            self.steps = 6
            self.enable_cpu_offload = True
        elif mode == PerformanceMode.QUALITY:
            self.resolution = (1080, 1920)
            self.fps = 30
            self.batch_size = 1
            self.steps = 8
            self.enable_cpu_offload = False
        elif mode == PerformanceMode.ULTRA:
            self.resolution = (1080, 1920)
            self.fps = 30
            self.batch_size = 2
            self.steps = 12
            self.enable_cpu_offload = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode.value,
            "resolution": list(self.resolution),
            "fps": self.fps,
            "batch_size": self.batch_size,
            "steps": self.steps,
            "precision": self.precision,
            "default_image_model": self.default_image_model,
            "default_llm_model": self.default_llm_model,
            "tts_engine": self.tts_engine,
            "whisper_model": self.whisper_model,
            "theme": self.theme,
        }


@lru_cache(maxsize=1)
def get_config() -> AppConfig:
    return AppConfig()
