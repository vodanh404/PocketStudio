"""Application context holding global services."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from app.core.config import AppConfig, get_config
from app.core.di import DIContainer
from app.services.model_pool import ModelPool
from app.utils.memory import MemoryManager
from app.utils.hash_cache import HashCache
from app.workers.task_queue import TaskQueue
from app.services.llm_service import LightweightLLMService
from app.services.image_generator import SDXLTurboBackend
from app.models.llm import LLMConfig


@dataclass
class AppContext:
    config: AppConfig
    container: DIContainer
    memory_manager: MemoryManager
    model_pool: ModelPool
    task_queue: TaskQueue
    image_cache: HashCache
    llm_cache: HashCache
    llm_service: LightweightLLMService
    image_backend: SDXLTurboBackend

    @classmethod
    def create(cls, config: Optional[AppConfig] = None) -> "AppContext":
        cfg = config or get_config()
        container = DIContainer()

        mm = MemoryManager(
            ram_warning=cfg.ram_warning_percent,
            ram_critical=cfg.ram_critical_percent,
            vram_warning=cfg.vram_warning_percent,
        )
        mm.start()

        pool = ModelPool(idle_timeout=cfg.model_idle_unload_seconds, memory_manager=mm)
        pool.start_janitor()

        image_cache = HashCache(Path(cfg.cache_dir), max_size_gb=cfg.max_cache_size_gb, namespace="images")
        llm_cache = HashCache(Path(cfg.cache_dir), max_size_gb=2.0, namespace="llm")

        llm_cfg = LLMConfig(
            model_name=cfg.default_llm_model,
            device="auto",
            dtype="float16",
            max_new_tokens=400,
        )
        llm_service = LightweightLLMService(model_pool=pool, cache=llm_cache, config=llm_cfg, enable_remote=False)

        image_backend = SDXLTurboBackend(
            model_pool=pool,
            cache=image_cache,
            enable_cpu_offload=cfg.enable_cpu_offload,
            enable_attention_slicing=cfg.enable_attention_slicing,
            enable_vae_slicing=cfg.enable_vae_slicing,
        )

        task_queue = TaskQueue(max_workers=1)
        task_queue.start()

        container.register_singleton(AppConfig, cfg)
        container.register_singleton(MemoryManager, mm)
        container.register_singleton(ModelPool, pool)
        container.register_singleton(TaskQueue, task_queue)
        container.register_singleton(LightweightLLMService, llm_service)
        container.register_singleton(SDXLTurboBackend, image_backend)

        return cls(
            config=cfg,
            container=container,
            memory_manager=mm,
            model_pool=pool,
            task_queue=task_queue,
            image_cache=image_cache,
            llm_cache=llm_cache,
            llm_service=llm_service,
            image_backend=image_backend,
        )

    def shutdown(self) -> None:
        self.task_queue.stop()
        self.model_pool.stop()
        self.memory_manager.stop()
