"""Cancelable Task Queue – low concurrency for limited GPU."""
from __future__ import annotations

import logging
import queue
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Optional

from app.core.events import event_bus

logger = logging.getLogger(__name__)


class TaskState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Task:
    id: str
    name: str
    func: Callable[..., Any]
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    priority: int = 0
    state: TaskState = TaskState.PENDING
    progress: float = 0.0
    result: Any = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    cancel_event: threading.Event = field(default_factory=threading.Event)

    def cancel(self) -> None:
        self.cancel_event.set()
        if self.state in (TaskState.PENDING, TaskState.RUNNING):
            self.state = TaskState.CANCELLED
            event_bus.publish("task.cancelled", {"task_id": self.id})


class TaskQueue:
    def __init__(self, max_workers: int = 1) -> None:
        self.max_workers = max_workers
        self._queue: queue.PriorityQueue = queue.PriorityQueue()
        self._tasks: Dict[str, Task] = {}
        self._lock = threading.RLock()
        self._workers: list[threading.Thread] = []
        self._stop_event = threading.Event()
        self._seq = 0

    def start(self) -> None:
        for i in range(self.max_workers):
            t = threading.Thread(
                target=self._worker_loop, name=f"TaskWorker-{i}", daemon=True
            )
            t.start()
            self._workers.append(t)
        logger.info("TaskQueue started with %d workers", self.max_workers)

    def stop(self, wait: bool = True) -> None:
        self._stop_event.set()
        if wait:
            for t in self._workers:
                t.join(timeout=5.0)

    def submit(
        self,
        name: str,
        func: Callable[..., Any],
        *args: Any,
        priority: int = 10,
        **kwargs: Any,
    ) -> str:
        task_id = str(uuid.uuid4())
        task = Task(id=task_id, name=name, func=func, args=args, kwargs=kwargs, priority=priority)
        with self._lock:
            self._tasks[task_id] = task
            self._seq += 1
            self._queue.put((priority, self._seq, task))
        event_bus.publish("task.submitted", {"task_id": task_id, "name": name})
        return task_id

    def cancel(self, task_id: str) -> bool:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False
            task.cancel()
            return True

    def get_task(self, task_id: str) -> Optional[Task]:
        with self._lock:
            return self._tasks.get(task_id)

    def _worker_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                priority, seq, task = self._queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if task.cancel_event.is_set():
                task.state = TaskState.CANCELLED
                event_bus.publish("task.cancelled", {"task_id": task.id})
                self._queue.task_done()
                continue
            task.state = TaskState.RUNNING
            task.started_at = time.time()
            event_bus.publish("task.started", {"task_id": task.id, "name": task.name})
            try:
                if "cancel_event" in getattr(task.func, "__code__", type("", (), {"co_varnames": ()})()).co_varnames:
                    task.kwargs["cancel_event"] = task.cancel_event
                result = task.func(*task.args, **task.kwargs)
                if task.cancel_event.is_set():
                    task.state = TaskState.CANCELLED
                else:
                    task.state = TaskState.COMPLETED
                    task.result = result
            except Exception as e:
                task.state = TaskState.FAILED
                task.error = traceback.format_exc()
                logger.exception("Task %s failed: %s", task.id, e)
                event_bus.publish("task.failed", {"task_id": task.id, "error": str(e)})
            finally:
                task.finished_at = time.time()
                event_bus.publish("task.finished", {
                    "task_id": task.id,
                    "state": task.state.value,
                    "duration": (task.finished_at or 0) - (task.started_at or 0),
                })
                self._queue.task_done()
