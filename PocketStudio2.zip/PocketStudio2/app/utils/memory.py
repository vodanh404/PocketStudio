"""Memory & VRAM monitor + automatic cleanup."""
from __future__ import annotations

import gc
import logging
import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional

import psutil

logger = logging.getLogger(__name__)

try:
    import pynvml
    pynvml.nvmlInit()
    _NVML_AVAILABLE = True
except Exception:
    _NVML_AVAILABLE = False


@dataclass
class MemorySnapshot:
    ram_used_percent: float
    ram_used_gb: float
    ram_total_gb: float
    vram_used_percent: float
    vram_used_gb: float
    vram_total_gb: float
    timestamp: float


class MemoryManager:
    def __init__(
        self,
        ram_warning: float = 70.0,
        ram_critical: float = 85.0,
        vram_warning: float = 75.0,
        check_interval: float = 5.0,
    ) -> None:
        self.ram_warning = ram_warning
        self.ram_critical = ram_critical
        self.vram_warning = vram_warning
        self.check_interval = check_interval
        self._unload_callbacks: list[Callable[[], None]] = []
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()

    def register_unload_callback(self, callback: Callable[[], None]) -> None:
        with self._lock:
            self._unload_callbacks.append(callback)

    def get_snapshot(self) -> MemorySnapshot:
        mem = psutil.virtual_memory()
        ram_used_gb = mem.used / (1024 ** 3)
        ram_total_gb = mem.total / (1024 ** 3)
        vram_used = 0.0
        vram_total = 0.0
        vram_percent = 0.0

        if _NVML_AVAILABLE:
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                vram_used = info.used / (1024 ** 3)
                vram_total = info.total / (1024 ** 3)
                vram_percent = (info.used / info.total) * 100 if info.total else 0.0
            except Exception as e:
                logger.debug("NVML read failed: %s", e)

        return MemorySnapshot(
            ram_used_percent=mem.percent,
            ram_used_gb=ram_used_gb,
            ram_total_gb=ram_total_gb,
            vram_used_percent=vram_percent,
            vram_used_gb=vram_used,
            vram_total_gb=vram_total,
            timestamp=time.time(),
        )

    def force_cleanup(self) -> None:
        logger.info("Force memory cleanup triggered")
        with self._lock:
            for cb in self._unload_callbacks:
                try:
                    cb()
                except Exception as e:
                    logger.exception("Unload callback failed: %s", e)
        gc.collect()
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
        except Exception:
            pass

    def _monitor_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                snap = self.get_snapshot()
                if snap.ram_used_percent >= self.ram_critical or snap.vram_used_percent >= 90.0:
                    logger.warning(
                        "Critical memory: RAM %.1f%% | VRAM %.1f%% → force cleanup",
                        snap.ram_used_percent, snap.vram_used_percent,
                    )
                    self.force_cleanup()
                elif snap.ram_used_percent >= self.ram_warning or snap.vram_used_percent >= self.vram_warning:
                    logger.info(
                        "Memory warning: RAM %.1f%% | VRAM %.1f%%",
                        snap.ram_used_percent, snap.vram_used_percent,
                    )
            except Exception as e:
                logger.exception("Memory monitor error: %s", e)
            self._stop_event.wait(self.check_interval)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._monitor_loop, name="MemoryMonitor", daemon=True
        )
        self._thread.start()
        logger.info("MemoryManager started")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=3.0)
