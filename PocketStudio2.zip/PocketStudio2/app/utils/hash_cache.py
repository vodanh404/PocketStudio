"""Hash-based disk cache for prompt / image / audio / video."""
from __future__ import annotations

import hashlib
import json
import logging
import shutil
import threading
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


class HashCache:
    def __init__(
        self,
        cache_dir: Path,
        max_size_gb: float = 8.0,
        namespace: str = "default",
    ) -> None:
        self.cache_dir = Path(cache_dir) / namespace
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.max_size_bytes = int(max_size_gb * 1024 ** 3)
        self._lock = threading.RLock()
        self._index_file = self.cache_dir / "index.json"
        self._index: dict[str, dict[str, Any]] = self._load_index()

    def _load_index(self) -> dict[str, dict[str, Any]]:
        if self._index_file.exists():
            try:
                return json.loads(self._index_file.read_text(encoding="utf-8"))
            except Exception:
                logger.warning("Corrupt cache index, recreating")
        return {}

    def _save_index(self) -> None:
        self._index_file.write_text(
            json.dumps(self._index, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    @staticmethod
    def make_key(*parts: Any) -> str:
        raw = "|".join(str(p) for p in parts)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def get(self, key: str) -> Optional[Path]:
        with self._lock:
            entry = self._index.get(key)
            if not entry:
                return None
            path = self.cache_dir / entry["filename"]
            if not path.exists():
                del self._index[key]
                self._save_index()
                return None
            entry["last_access"] = time.time()
            self._save_index()
            return path

    def put(self, key: str, source_path: Path, metadata: Optional[dict] = None) -> Path:
        with self._lock:
            ext = source_path.suffix or ".bin"
            filename = f"{key}{ext}"
            dest = self.cache_dir / filename
            if dest.exists():
                self._index[key] = {
                    "filename": filename,
                    "size": dest.stat().st_size,
                    "created": self._index.get(key, {}).get("created", time.time()),
                    "last_access": time.time(),
                    "metadata": metadata or {},
                }
                self._save_index()
                return dest
            shutil.copy2(source_path, dest)
            size = dest.stat().st_size
            self._index[key] = {
                "filename": filename,
                "size": size,
                "created": time.time(),
                "last_access": time.time(),
                "metadata": metadata or {},
            }
            self._save_index()
            self._evict_if_needed()
            return dest

    def put_bytes(self, key: str, data: bytes, ext: str = ".bin", metadata: Optional[dict] = None) -> Path:
        with self._lock:
            filename = f"{key}{ext}"
            dest = self.cache_dir / filename
            dest.write_bytes(data)
            self._index[key] = {
                "filename": filename,
                "size": len(data),
                "created": time.time(),
                "last_access": time.time(),
                "metadata": metadata or {},
            }
            self._save_index()
            self._evict_if_needed()
            return dest

    def _evict_if_needed(self) -> None:
        total = sum(e["size"] for e in self._index.values())
        if total <= self.max_size_bytes:
            return
        items = sorted(self._index.items(), key=lambda x: x[1]["last_access"])
        for key, entry in items:
            if total <= self.max_size_bytes * 0.8:
                break
            path = self.cache_dir / entry["filename"]
            if path.exists():
                path.unlink(missing_ok=True)
            total -= entry["size"]
            del self._index[key]
            logger.info("Cache evicted: %s", key[:12])
        self._save_index()

    def clear(self) -> None:
        with self._lock:
            shutil.rmtree(self.cache_dir, ignore_errors=True)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            self._index.clear()
            self._save_index()

    def stats(self) -> dict[str, Any]:
        with self._lock:
            total_size = sum(e["size"] for e in self._index.values())
            return {
                "entries": len(self._index),
                "size_mb": round(total_size / (1024 ** 2), 2),
                "max_size_gb": self.max_size_bytes / (1024 ** 3),
            }
