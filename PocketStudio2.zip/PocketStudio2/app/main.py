"""Entry point for MoneyPrinter Desktop."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.core.logging_setup import setup_logging
from app.core.app_context import AppContext
from app.pipelines.factory import PipelineFactory
from app.ui.app import MainApp


def main() -> None:
    setup_logging()
    ctx = AppContext.create()
    pipeline_factory = PipelineFactory(ctx)
    app = MainApp()
    app.set_context(ctx, pipeline_factory)
    try:
        app.run()
    finally:
        ctx.shutdown()


if __name__ == "__main__":
    main()
