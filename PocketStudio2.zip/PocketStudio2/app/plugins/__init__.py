"""Plugin system (future: ComfyUI, ControlNet, Upscaler...)."""
