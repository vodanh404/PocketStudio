"""Theme helpers for ttkbootstrap."""
from __future__ import annotations
import ttkbootstrap as ttk


def apply_app_style(app: ttk.Window) -> None:
    style = app.style
    style.configure("Sidebar.TFrame", background="#1a1d21")
    style.configure("Content.TFrame", background="#212529")
    style.configure("Card.TFrame", background="#2b3035", relief="flat")
    style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"))
    style.configure("Subtitle.TLabel", font=("Segoe UI", 10), foreground="#adb5bd")
