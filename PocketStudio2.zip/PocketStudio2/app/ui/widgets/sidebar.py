from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from typing import Callable, Dict


class Sidebar(ttk.Frame):
    def __init__(self, master, on_navigate: Callable[[str], None], **kwargs) -> None:
        super().__init__(master, style="Sidebar.TFrame", width=220, **kwargs)
        self.on_navigate = on_navigate
        self.buttons: Dict[str, ttk.Button] = {}
        self._build()

    def _build(self) -> None:
        self.pack_propagate(False)
        title = ttk.Label(
            self, text="MoneyPrinter\nDesktop", font=("Segoe UI", 13, "bold"),
            bootstyle="inverse-dark", anchor=CENTER, justify=CENTER,
        )
        title.pack(pady=(20, 30), padx=10, fill=X)
        items = [
            ("home", "🏠  Home"), ("project", "📁  Project"), ("script", "📝  Script"),
            ("assets", "🖼️  Assets"), ("video", "🎬  Video"), ("export", "📦  Export"),
            ("models", "🧠  Models"), ("settings", "⚙️  Settings"), ("logs", "📋  Logs"),
        ]
        for key, label in items:
            btn = ttk.Button(self, text=label, bootstyle="secondary-link",
                             command=lambda k=key: self.on_navigate(k), width=20)
            btn.pack(fill=X, padx=12, pady=3)
            self.buttons[key] = btn
        ttk.Frame(self, style="Sidebar.TFrame").pack(fill=BOTH, expand=True)
        ver = ttk.Label(self, text="v0.1.0 • Weak Mode", font=("Segoe UI", 8),
                        bootstyle="secondary", anchor=CENTER)
        ver.pack(pady=15)

    def set_active(self, key: str) -> None:
        for k, btn in self.buttons.items():
            btn.configure(bootstyle="primary" if k == key else "secondary-link")
