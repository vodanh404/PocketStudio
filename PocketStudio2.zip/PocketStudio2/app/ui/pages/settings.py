from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage
from app.core.config import PerformanceMode


class SettingsPage(BasePage):
    title = "Settings"

    def _build(self) -> None:
        ttk.Label(self, text="Settings", style="Title.TLabel").pack(pady=(20, 10), padx=30, anchor=W)
        perf = ttk.Labelframe(self, text="Performance Mode", padding=15)
        perf.pack(fill=X, padx=30, pady=10)
        self.mode_var = ttk.StringVar(value="weak")
        for mode in PerformanceMode:
            ttk.Radiobutton(perf, text=mode.value.capitalize(), variable=self.mode_var,
                            value=mode.value, command=self._on_mode_change).pack(anchor=W, pady=3)
        ttk.Label(self, text="Thay đổi mode sẽ tự động điều chỉnh resolution, steps, model, offload...",
                  style="Subtitle.TLabel").pack(padx=30, anchor=W)

    def _on_mode_change(self) -> None:
        mode = self.mode_var.get()
        self.app.status_bar.set_status(f"Performance mode → {mode}")
        if hasattr(self.app, "ctx") and self.app.ctx:
            from app.core.config import PerformanceMode as PM
            self.app.ctx.config.apply_mode(PM(mode))
