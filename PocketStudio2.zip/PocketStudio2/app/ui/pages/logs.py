from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage


class LogsPage(BasePage):
    title = "Logs"

    def _build(self) -> None:
        ttk.Label(self, text="Logs & Progress", style="Title.TLabel").pack(pady=(20, 10), padx=30, anchor=W)
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=X, padx=30, pady=5)
        ttk.Button(toolbar, text="Clear", bootstyle="secondary-outline", command=self.clear).pack(side=LEFT)
        self.text = ttk.Text(self, height=25, wrap=WORD, font=("Consolas", 10))
        self.text.pack(fill=BOTH, expand=True, padx=30, pady=10)
        scroll = ttk.Scrollbar(self.text, command=self.text.yview)
        scroll.pack(side=RIGHT, fill=Y)
        self.text.configure(yscrollcommand=scroll.set)

    def append(self, message: str) -> None:
        self.text.insert(END, message + "\n")
        self.text.see(END)

    def clear(self) -> None:
        self.text.delete("1.0", END)
