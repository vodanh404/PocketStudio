from __future__ import annotations
from pathlib import Path
import shutil
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from tkinter import filedialog, messagebox
from app.ui.base_page import BasePage


class ExportPage(BasePage):
    title = "Export"

    def _build(self) -> None:
        ttk.Label(self, text="Export", style="Title.TLabel").pack(pady=(20, 5), padx=30, anchor=W)
        form = ttk.Labelframe(self, text="Tùy chọn xuất", padding=20)
        form.pack(fill=X, padx=30, pady=15)
        ttk.Label(form, text="Định dạng:").grid(row=0, column=0, sticky=W, pady=8)
        self.format_var = ttk.StringVar(value="mp4")
        ttk.Combobox(form, textvariable=self.format_var, values=["mp4", "mov", "gif"],
                     width=12, state="readonly").grid(row=0, column=1, sticky=W, padx=10)
        ttk.Label(form, text="Tỉ lệ:").grid(row=1, column=0, sticky=W, pady=8)
        self.ratio_var = ttk.StringVar(value="9:16")
        ttk.Combobox(form, textvariable=self.ratio_var,
                     values=["9:16 (Vertical)", "16:9 (Horizontal)", "1:1 (Square)"],
                     width=20, state="readonly").grid(row=1, column=1, sticky=W, padx=10)
        ttk.Label(form, text="Tên file:").grid(row=2, column=0, sticky=W, pady=8)
        self.entry_name = ttk.Entry(form, width=30)
        self.entry_name.insert(0, "final_video")
        self.entry_name.grid(row=2, column=1, sticky=W, padx=10)
        ttk.Button(form, text="📤 Export Video", bootstyle="success", width=20,
                   command=self._export).grid(row=3, column=1, sticky=E, pady=20)
        self.lbl_info = ttk.Label(self, text="", style="Subtitle.TLabel")
        self.lbl_info.pack(padx=30, anchor=W)

    def _export(self) -> None:
        project = getattr(self.app, "current_project", None)
        if not project:
            messagebox.showwarning("Export", "Chưa có project nào.")
            return
        src = Path(project.dir) / "output" / "final.mp4"
        if not src.exists():
            src = Path(project.dir) / "final.mp4"
        if not src.exists():
            messagebox.showwarning("Export", "Chưa có file video. Hãy Render trước.")
            return
        dest_dir = filedialog.askdirectory(title="Chọn thư mục xuất")
        if not dest_dir:
            return
        name = self.entry_name.get().strip() or "final_video"
        dest = Path(dest_dir) / f"{name}.mp4"
        try:
            shutil.copy2(src, dest)
            self.lbl_info.configure(text=f"Đã xuất: {dest}")
            self.app.status_bar.set_status(f"Exported → {dest.name}")
            messagebox.showinfo("Export", f"Thành công!\n{dest}")
        except Exception as e:
            messagebox.showerror("Export", str(e))
