from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage


class HomePage(BasePage):
    title = "Home"

    def _build(self) -> None:
        header = ttk.Label(self, text="MoneyPrinter Desktop", style="Title.TLabel")
        header.pack(pady=(30, 5), padx=30, anchor=W)
        sub = ttk.Label(self, text="AI Short Video Generator – Tối ưu cho máy yếu", style="Subtitle.TLabel")
        sub.pack(padx=30, anchor=W)
        card = ttk.Frame(self, style="Card.TFrame", padding=20)
        card.pack(fill=X, padx=30, pady=30)
        ttk.Label(card, text="Bắt đầu nhanh", font=("Segoe UI", 12, "bold")).pack(anchor=W)
        btn_row = ttk.Frame(card)
        btn_row.pack(fill=X, pady=15)
        ttk.Button(btn_row, text="＋ New Project", bootstyle="success", width=18,
                   command=lambda: self.app.navigate("project")).pack(side=LEFT, padx=(0, 10))
        ttk.Button(btn_row, text="📂 Open Project", bootstyle="info-outline", width=18,
                   command=lambda: self.app.navigate("project")).pack(side=LEFT)
