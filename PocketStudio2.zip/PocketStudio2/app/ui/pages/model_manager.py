from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage


class ModelManagerPage(BasePage):
    title = "Model Manager"

    def _build(self) -> None:
        ttk.Label(self, text="Model Manager", style="Title.TLabel").pack(pady=(20, 10), padx=30, anchor=W)
        info = ttk.Labelframe(self, text="Models đã đăng ký", padding=10)
        info.pack(fill=BOTH, expand=True, padx=30, pady=10)
        self.tree = ttk.Treeview(info, columns=("name", "status", "ref", "idle"), show="headings", height=12)
        self.tree.heading("name", text="Model")
        self.tree.heading("status", text="Status")
        self.tree.heading("ref", text="Ref Count")
        self.tree.heading("idle", text="Idle (s)")
        self.tree.pack(fill=BOTH, expand=True)
        btn_row = ttk.Frame(self)
        btn_row.pack(fill=X, padx=30, pady=10)
        ttk.Button(btn_row, text="Refresh", bootstyle="info", command=self.refresh).pack(side=LEFT)
        ttk.Button(btn_row, text="Unload All", bootstyle="danger-outline",
                   command=self.unload_all).pack(side=LEFT, padx=8)

    def refresh(self) -> None:
        for i in self.tree.get_children():
            self.tree.delete(i)
        pool = getattr(self.app, "model_pool", None)
        if not pool:
            return
        for name, info in pool.status().items():
            self.tree.insert("", END, values=(
                name, "loaded", info["ref_count"], f"{info['idle_seconds']:.0f}",
            ))

    def unload_all(self) -> None:
        pool = getattr(self.app, "model_pool", None)
        if pool:
            pool.force_unload_all()
            self.app.status_bar.set_status("Đã unload toàn bộ model")
            self.refresh()
