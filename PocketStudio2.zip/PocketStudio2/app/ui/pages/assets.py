from __future__ import annotations
import tkinter as tk
from pathlib import Path
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


class AssetsPage(BasePage):
    title = "Assets"

    def _build(self) -> None:
        ttk.Label(self, text="Assets Browser", style="Title.TLabel").pack(pady=(20, 5), padx=30, anchor=W)
        self.notebook = ttk.Notebook(self, bootstyle="dark")
        self.notebook.pack(fill=BOTH, expand=True, padx=30, pady=15)
        self.img_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.img_frame, text="  Images  ")
        self.img_list = ttk.Treeview(self.img_frame, columns=("file", "size"), show="headings", height=12)
        self.img_list.heading("file", text="File")
        self.img_list.heading("size", text="Size")
        self.img_list.pack(fill=BOTH, expand=True, padx=5, pady=5)
        self.audio_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.audio_frame, text="  Audio  ")
        self.audio_list = ttk.Treeview(self.audio_frame, columns=("scene", "path"), show="headings", height=12)
        self.audio_list.heading("scene", text="Scene")
        self.audio_list.heading("path", text="File")
        self.audio_list.pack(fill=BOTH, expand=True, padx=5, pady=5)
        self.sub_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.sub_frame, text="  Subtitles  ")
        self.sub_list = ttk.Treeview(self.sub_frame, columns=("scene", "path"), show="headings", height=12)
        self.sub_list.heading("scene", text="Scene")
        self.sub_list.heading("path", text="File")
        self.sub_list.pack(fill=BOTH, expand=True, padx=5, pady=5)
        bar = ttk.Frame(self)
        bar.pack(fill=X, padx=30, pady=5)
        ttk.Button(bar, text="↻ Refresh", bootstyle="info-outline", command=self.refresh).pack(side=LEFT)

    def on_show(self) -> None:
        self.refresh()

    def refresh(self) -> None:
        for tree in (self.img_list, self.audio_list, self.sub_list):
            for i in tree.get_children():
                tree.delete(i)
        project = getattr(self.app, "current_project", None)
        if not project:
            return
        base = Path(project.dir)
        for f in sorted((base / "images").glob("*")) if (base / "images").exists() else []:
            self.img_list.insert("", END, values=(f.name, f"{f.stat().st_size // 1024} KB"))
        for f in sorted((base / "audio").glob("*.mp3")) if (base / "audio").exists() else []:
            self.audio_list.insert("", END, values=(f.stem, str(f)))
        for f in sorted((base / "subtitles").glob("*.srt")) if (base / "subtitles").exists() else []:
            self.sub_list.insert("", END, values=(f.stem, str(f)))
