from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage


class ScriptPage(BasePage):
    title = "Script"

    def _build(self) -> None:
        ttk.Label(self, text="Script Editor", style="Title.TLabel").pack(pady=(20, 5), padx=30, anchor=W)
        ttk.Label(self, text="Kịch bản được tạo tự động. Bạn có thể chỉnh sửa trước khi tiếp tục.",
                  style="Subtitle.TLabel").pack(padx=30, anchor=W)
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=X, padx=30, pady=10)
        ttk.Button(toolbar, text="↻ Generate Script", bootstyle="success",
                   command=self._generate_script).pack(side=LEFT)
        ttk.Button(toolbar, text="💾 Save", bootstyle="info-outline",
                   command=self._save_script).pack(side=LEFT, padx=8)
        ttk.Button(toolbar, text="➡ Continue Pipeline", bootstyle="primary",
                   command=self._continue_pipeline).pack(side=RIGHT)
        self.text = ttk.Text(self, height=22, wrap=WORD, font=("Segoe UI", 11))
        self.text.pack(fill=BOTH, expand=True, padx=30, pady=(0, 20))
        scroll = ttk.Scrollbar(self.text, command=self.text.yview)
        scroll.pack(side=RIGHT, fill=Y)
        self.text.configure(yscrollcommand=scroll.set)

    def on_show(self) -> None:
        project = getattr(self.app, "current_project", None)
        if project and getattr(project, "script", None):
            self.text.delete("1.0", END)
            self.text.insert("1.0", project.script or "")

    def _generate_script(self) -> None:
        if not getattr(self.app, "current_topic", None):
            self.app.status_bar.set_status("Chưa có topic. Hãy tạo Project trước.")
            return
        self.app.start_pipeline_stage("script")

    def _save_script(self) -> None:
        content = self.text.get("1.0", END).strip()
        if getattr(self.app, "current_project", None):
            self.app.current_project.script = content
            self.app.status_bar.set_status("Đã lưu script")

    def _continue_pipeline(self) -> None:
        self.app.start_pipeline_stage("full")
