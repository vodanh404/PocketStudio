from __future__ import annotations
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from app.ui.base_page import BasePage


class ProjectPage(BasePage):
    title = "Project"

    def _build(self) -> None:
        ttk.Label(self, text="Project Manager", style="Title.TLabel").pack(pady=(20, 10), padx=30, anchor=W)
        form = ttk.Labelframe(self, text="Tạo Project mới", padding=15)
        form.pack(fill=X, padx=30, pady=10)
        ttk.Label(form, text="Chủ đề / Topic:").grid(row=0, column=0, sticky=W, pady=5)
        self.entry_topic = ttk.Entry(form, width=50)
        self.entry_topic.grid(row=0, column=1, sticky=EW, padx=10, pady=5)
        ttk.Label(form, text="Ngôn ngữ:").grid(row=1, column=0, sticky=W, pady=5)
        self.combo_lang = ttk.Combobox(form, values=["vi", "en"], width=10)
        self.combo_lang.set("vi")
        self.combo_lang.grid(row=1, column=1, sticky=W, padx=10, pady=5)
        ttk.Button(form, text="Tạo & Chạy Pipeline", bootstyle="success", command=self._on_create).grid(
            row=2, column=1, sticky=E, pady=15
        )
        form.columnconfigure(1, weight=1)
        list_frame = ttk.Labelframe(self, text="Projects gần đây", padding=10)
        list_frame.pack(fill=BOTH, expand=True, padx=30, pady=10)
        self.tree = ttk.Treeview(list_frame, columns=("name", "status", "updated"), show="headings", height=10)
        self.tree.heading("name", text="Tên")
        self.tree.heading("status", text="Trạng thái")
        self.tree.heading("updated", text="Cập nhật")
        self.tree.column("name", width=250)
        self.tree.column("status", width=120)
        self.tree.column("updated", width=150)
        self.tree.pack(fill=BOTH, expand=True)

    def _on_create(self) -> None:
        topic = self.entry_topic.get().strip()
        if not topic:
            return
        lang = self.combo_lang.get()
        self.app.create_project_and_pipeline(topic, lang)
        self.app.navigate("script")
        self.app.start_pipeline_stage("script")
