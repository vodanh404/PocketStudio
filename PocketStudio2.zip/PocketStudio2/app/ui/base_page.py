from __future__ import annotations
import ttkbootstrap as ttk
from abc import ABC, abstractmethod
from typing import Any


class BasePage(ttk.Frame, ABC):
    title: str = "Page"
    icon: str = ""

    def __init__(self, master: Any, app: Any, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self.app = app
        self._build()

    @abstractmethod
    def _build(self) -> None:
        ...

    def on_show(self) -> None:
        pass

    def on_hide(self) -> None:
        pass
