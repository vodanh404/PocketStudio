"""UI package – Tkinter + ttkbootstrap."""
