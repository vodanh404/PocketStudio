"""Main application window."""
from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Dict, Optional, Type, TYPE_CHECKING

import ttkbootstrap as ttk
from ttkbootstrap.constants import *

from app.ui.theme import apply_app_style
from app.ui.base_page import BasePage
from app.ui.widgets.sidebar import Sidebar
from app.ui.widgets.status_bar import StatusBar
from app.ui.pages.home import HomePage
from app.ui.pages.project import ProjectPage
from app.ui.pages.script import ScriptPage
from app.ui.pages.assets import AssetsPage
from app.ui.pages.video import VideoPage
from app.ui.pages.export import ExportPage
from app.ui.pages.logs import LogsPage
from app.ui.pages.settings import SettingsPage
from app.ui.pages.model_manager import ModelManagerPage
from app.core.events import event_bus

if TYPE_CHECKING:
    from app.core.app_context import AppContext
    from app.pipelines.factory import PipelineFactory

logger = logging.getLogger(__name__)


class MainApp(ttk.Window):
    def __init__(self, **kwargs) -> None:
        super().__init__(title="MoneyPrinter Desktop", themename="darkly",
                         size=(1280, 800), minsize=(1024, 640), **kwargs)
        apply_app_style(self)
        self.pages: Dict[str, BasePage] = {}
        self.current_page: Optional[str] = None
        self.ctx = None
        self.pipeline_factory = None
        self.task_queue = None
        self.memory_manager = None
        self.model_pool = None
        self.pipeline = None
        self.current_project = None
        self.current_topic = None
        self.current_language = "vi"
        self.current_task_id = None
        self._build_layout()
        self._register_pages()
        self._bind_events()
        self.navigate("home")
        self.after(3000, self._poll_memory)

    def _build_layout(self) -> None:
        self.sidebar = Sidebar(self, on_navigate=self.navigate)
        self.sidebar.pack(side=LEFT, fill=Y)
        right = ttk.Frame(self, style="Content.TFrame")
        right.pack(side=LEFT, fill=BOTH, expand=True)
        self.content = ttk.Frame(right, style="Content.TFrame")
        self.content.pack(fill=BOTH, expand=True)
        self.status_bar = StatusBar(right)
        self.status_bar.pack(side=BOTTOM, fill=X)

    def _register_pages(self) -> None:
        page_classes: Dict[str, Type[BasePage]] = {
            "home": HomePage, "project": ProjectPage, "script": ScriptPage,
            "assets": AssetsPage, "video": VideoPage, "export": ExportPage,
            "logs": LogsPage, "settings": SettingsPage, "models": ModelManagerPage,
        }
        for key, cls in page_classes.items():
            page = cls(self.content, app=self)
            self.pages[key] = page
            page.place(relx=0, rely=0, relwidth=1, relheight=1)
            page.lower()

    def navigate(self, key: str) -> None:
        if key not in self.pages:
            logger.warning("Page not found: %s", key)
            return
        if self.current_page:
            self.pages[self.current_page].on_hide()
            self.pages[self.current_page].lower()
        self.current_page = key
        page = self.pages[key]
        page.lift()
        page.on_show()
        self.sidebar.set_active(key)
        self.status_bar.set_status(f"Page: {page.title}")

    def set_context(self, ctx: "AppContext", pipeline_factory: "PipelineFactory") -> None:
        self.ctx = ctx
        self.pipeline_factory = pipeline_factory
        self.task_queue = ctx.task_queue
        self.memory_manager = ctx.memory_manager
        self.model_pool = ctx.model_pool

    def create_project_and_pipeline(self, topic: str, language: str = "vi") -> None:
        name = f"proj_{int(time.time())}"
        projects_dir = Path(self.ctx.config.projects_dir) if self.ctx else Path("projects")
        project_dir = projects_dir / name
        project_dir.mkdir(parents=True, exist_ok=True)
        pipeline = self.pipeline_factory.create(project_dir) if self.pipeline_factory else None
        self.current_topic = topic
        self.current_language = language
        self.current_project = type("Project", (), {
            "dir": project_dir, "name": name, "topic": topic, "script": "",
        })()
        self.pipeline = pipeline
        self.status_bar.set_status(f"Project sẵn sàng: {name}")

    def start_pipeline_stage(self, stage: str = "full") -> None:
        if not self.pipeline or not self.task_queue:
            self.status_bar.set_status("Pipeline chưa được khởi tạo")
            return
        if not self.current_topic:
            self.status_bar.set_status("Chưa có topic")
            return

        def _job():
            return self.pipeline.run(
                topic=self.current_topic,
                language=self.current_language,
                resume=True,
                progress=self._pipeline_progress,
                width=getattr(self.ctx.config, "resolution", (720, 1280))[0] if self.ctx else 512,
                height=getattr(self.ctx.config, "resolution", (720, 1280))[1] if self.ctx else 768,
                steps=getattr(self.ctx.config, "steps", 4) if self.ctx else 4,
            )

        self.current_task_id = self.task_queue.submit(f"pipeline_{stage}", _job, priority=5)
        self.status_bar.set_status(f"Pipeline started ({stage})")
        self.navigate("video")

    def cancel_pipeline(self) -> None:
        if self.pipeline:
            self.pipeline.cancel()
        if self.current_task_id and self.task_queue:
            self.task_queue.cancel(self.current_task_id)
        self.status_bar.set_status("Đã gửi lệnh Cancel")

    def _pipeline_progress(self, stage: str, percent: float, message: str) -> None:
        def _update():
            self.status_bar.set_progress(percent)
            self.status_bar.set_status(f"[{stage}] {message}")
            if "video" in self.pages and hasattr(self.pages["video"], "update_progress"):
                self.pages["video"].update_progress(stage, percent, message)
            if "logs" in self.pages:
                self.pages["logs"].append(f"[{stage}] {percent*100:.0f}% - {message}")
        self.after(0, _update)

    def _bind_events(self) -> None:
        event_bus.subscribe("task.started", lambda d: self.after(0, lambda: self.status_bar.set_status(f"Running: {d.get('name', '')}")))
        event_bus.subscribe("task.finished", lambda d: self.after(0, lambda: (self.status_bar.set_status("Hoàn tất task"), self.status_bar.set_progress(0))))
        event_bus.subscribe("task.failed", lambda d: self.after(0, lambda: self.status_bar.set_status(f"Lỗi: {str(d.get('error', ''))[:60]}")))

    def _poll_memory(self) -> None:
        if self.memory_manager:
            try:
                snap = self.memory_manager.get_snapshot()
                self.status_bar.set_memory(f"{snap.ram_used_gb:.1f}G", f"{snap.vram_used_gb:.1f}G")
            except Exception:
                pass
        self.after(3000, self._poll_memory)

    def run(self) -> None:
        self.mainloop()
