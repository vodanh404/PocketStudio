"""Repository layer (persistence)."""
