#!/usr/bin/env bash
set -e

echo "============================================================"
echo "  MoneyPrinter Desktop - Setup"
echo "============================================================"
echo

python3 --version

echo "[1/4] Tao virtual environment..."
python3 -m venv .venv
source .venv/bin/activate

echo "[2/4] Nang cap pip..."
pip install --upgrade pip setuptools wheel

echo "[3/4] Cai PyTorch (CUDA 12.1)..."
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

echo "[4/4] Cai cac package con lai..."
pip install -r requirements.txt

echo
echo "[+] Chay init project..."
python scripts/init_project.py

echo
echo "============================================================"
echo "  Setup hoan tat!"
echo "  Kich hoat: source .venv/bin/activate"
echo "  Chay:      python -m app.main"
echo "============================================================"
